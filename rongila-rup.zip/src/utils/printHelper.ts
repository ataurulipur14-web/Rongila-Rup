/**
 * Print & Invoice Utility for Rongila Rup
 * Supports iframe-safe printing, opening printable view in a fresh new tab,
 * and downloading stand-alone HTML invoices that print cleanly on any printer.
 */

function generateInvoiceHtml(innerContent: string, invoiceTitle: string = 'Rongila Rup Invoice'): string {
  return `<!DOCTYPE html>
<html lang="bn">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>${invoiceTitle}</title>
  <style>
    @page {
      margin: 8mm;
      size: A4 portrait;
    }
    *, *::before, *::after {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }
    body {
      background-color: #f8fafc;
      color: #0f172a;
      font-family: ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
      padding: 20px;
      display: flex;
      flex-direction: column;
      align-items: center;
    }
    .print-controls {
      width: 100%;
      max-width: 650px;
      margin-bottom: 16px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      background: #831843;
      color: #fef08a;
      padding: 12px 18px;
      border-radius: 12px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    }
    .print-btn {
      background: #fef08a;
      color: #831843;
      border: none;
      padding: 8px 18px;
      font-weight: 800;
      font-size: 14px;
      border-radius: 8px;
      cursor: pointer;
      display: flex;
      align-items: center;
      gap: 6px;
    }
    .print-btn:hover {
      background: #fef9c3;
    }
    .invoice-card {
      background: #ffffff;
      width: 100%;
      max-width: 650px;
      border: 1px solid #e2e8f0;
      border-radius: 16px;
      padding: 24px;
      box-shadow: 0 2px 10px rgba(0,0,0,0.05);
    }
    /* Hide unwanted elements */
    button, [role="button"], .no-print, .print-hidden {
      display: none !important;
    }
    /* Table styling */
    table {
      width: 100%;
      border-collapse: collapse;
      margin: 12px 0;
    }
    th, td {
      padding: 8px 10px;
      text-align: left;
    }
    th {
      border-bottom: 2px solid #cbd5e1;
      font-size: 11px;
      color: #64748b;
    }
    td {
      border-bottom: 1px solid #f1f5f9;
      font-size: 12px;
    }
    @media print {
      body {
        background: transparent !important;
        padding: 0 !important;
      }
      .print-controls {
        display: none !important;
      }
      .invoice-card {
        border: none !important;
        box-shadow: none !important;
        max-width: 100% !important;
        padding: 0 !important;
      }
    }
  </style>
</head>
<body>
  <div class="print-controls">
    <div style="font-weight: bold; font-size: 14px;">রঙিলা রূপ কিডস - অফিসিয়াল মেমো ও ইনভয়েস</div>
    <button class="print-btn" onclick="window.print()">🖨️ প্রিন্ট / PDF সেভ করুন</button>
  </div>
  <div class="invoice-card" id="invoice-body">
    ${innerContent}
  </div>
  <script>
    // Automatically open print dialog when loaded in new window
    window.addEventListener('load', () => {
      setTimeout(() => {
        try { window.print(); } catch(e) {}
      }, 350);
    });
  </script>
</body>
</html>`;
}

/**
 * Standard print function: handles iframe constraints by injecting print CSS
 * and triggering window.print(), falling back to a clean new window.
 */
export function printInvoiceElement(elementId: string = 'printable-area') {
  const elem = document.getElementById(elementId);
  if (!elem) {
    window.print();
    return;
  }

  // Ensure a dedicated style element exists for printing only #elementId
  let printStyle = document.getElementById('dynamic-print-style');
  if (!printStyle) {
    printStyle = document.createElement('style');
    printStyle.id = 'dynamic-print-style';
    document.head.appendChild(printStyle);
  }

  printStyle.innerHTML = `
    @media print {
      body > * {
        display: none !important;
      }
      #${elementId}, #${elementId} * {
        visibility: visible !important;
      }
      #${elementId} {
        display: block !important;
        position: absolute !important;
        left: 0 !important;
        top: 0 !important;
        width: 100% !important;
        max-width: 100% !important;
        background: white !important;
        color: black !important;
        border: none !important;
        margin: 0 !important;
        padding: 12mm !important;
        z-index: 999999 !important;
        box-shadow: none !important;
      }
      .no-print, .print-hidden, button, [role="button"] {
        display: none !important;
        visibility: hidden !important;
      }
    }
  `;

  // First attempt: direct window.print() with our scoped print style
  try {
    window.print();
  } catch (e) {
    console.warn('Direct print failed, opening in clean new window:', e);
    openInvoiceInNewTab(elementId);
  }
}

/**
 * Opens invoice in a pristine new browser tab where window.print() is 100% unrestricted.
 */
export function openInvoiceInNewTab(elementId: string = 'printable-area', title: string = 'Rongila-Rup-Invoice') {
  const elem = document.getElementById(elementId);
  if (!elem) return;

  const html = generateInvoiceHtml(elem.innerHTML, title);
  const blob = new Blob([html], { type: 'text/html;charset=utf-8' });
  const blobUrl = URL.createObjectURL(blob);

  const newWin = window.open(blobUrl, '_blank');
  if (!newWin) {
    // If popup was blocked by browser, trigger download or link
    const a = document.createElement('a');
    a.href = blobUrl;
    a.target = '_blank';
    a.rel = 'noopener noreferrer';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  }
}

/**
 * Downloads the full invoice as a standalone, printable HTML document.
 */
export function downloadInvoiceHtml(elementId: string = 'printable-area', invoiceNumber: string = 'order') {
  const elem = document.getElementById(elementId);
  if (!elem) return;

  const html = generateInvoiceHtml(elem.innerHTML, `Invoice #${invoiceNumber} - Rongila Rup`);
  const blob = new Blob([html], { type: 'text/html;charset=utf-8' });
  const blobUrl = URL.createObjectURL(blob);

  const a = document.createElement('a');
  a.href = blobUrl;
  a.download = `Rongila-Rup-Invoice-${invoiceNumber}.html`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(blobUrl), 2000);
}
