import React, { useState, useEffect, useMemo } from 'react';
import QRCode from 'qrcode';
import { AdsManagerModal } from './AdsManagerModal';
import { AdminErrorBoundary } from './AdminErrorBoundary';
import { getSafeTimestamp, formatSafeDate, cleanPhoneNumber, formatSafePrice } from '../utils/format';
import { 
  X, 
  PackagePlus, 
  ShoppingBag, 
  Rocket, 
  BarChart3, 
  CheckCircle2, 
  Clock, 
  Truck, 
  DollarSign, 
  Edit3, 
  Trash2, 
  Plus, 
  Minus,
  Sparkles, 
  Megaphone, 
  PhoneCall, 
  Tag, 
  Eye, 
  Lock,
  Unlock,
  Search,
  Filter,
  HardDrive,
  Download,
  Users,
  Printer,
  Copy,
  Send,
  AlertTriangle,
  XCircle,
  PauseCircle,
  Check,
  Building2,
  QrCode,
  ShieldCheck,
  ShieldAlert,
  ShieldX,
  Flame,
  ImagePlus,
  KeyRound,
  Image as ImageIcon,
  Camera,
  UploadCloud,
  FileImage,
  RefreshCw,
  Sliders,
  Bell,
  Calendar,
  PieChart,
  TrendingUp,
  TrendingDown,
  Layers,
  Settings,
  CreditCard,
  RotateCcw,
  Star,
  FileText,
  Globe,
  Palette,
  BookOpen,
  SlidersHorizontal,
  Shield,
  HelpCircle,
  Database,
  LogOut,
  Menu,
  Package,
  Box,
  MessageSquare,
  ZoomIn,
  ZoomOut,
  RotateCw,
  Mail,
  EyeOff,
  ExternalLink,
  Save
} from 'lucide-react';
import { 
  Product, 
  Order, 
  Language, 
  CategoryId, 
  StoreSettings, 
  Coupon, 
  Customer, 
  AdminUser 
} from '../types';
import { getStoredPixelId, savePixelId, trackPixelEvent } from '../utils/pixel';
import { printInvoiceElement, openInvoiceInNewTab, downloadInvoiceHtml } from '../utils/printHelper';
import { clearAllOrdersFromFirestore } from '../services/firebaseDb';

// Helper to compress uploaded image file to lightweight Base64 data URL
const compressImageFile = (file: File, maxWidth = 1000, maxHeight = 1000, quality = 0.82): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = (err) => reject(err);
    reader.onload = (event) => {
      const img = new Image();
      img.onerror = (err) => reject(err);
      img.onload = () => {
        let width = img.width;
        let height = img.height;

        if (width > maxWidth || height > maxHeight) {
          if (width > height) {
            height = Math.round((height * maxWidth) / width);
            width = maxWidth;
          } else {
            width = Math.round((width * maxHeight) / height);
            height = maxHeight;
          }
        }

        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve(event.target?.result as string);
          return;
        }

        ctx.drawImage(img, 0, 0, width, height);
        const compressedDataUrl = canvas.toDataURL('image/jpeg', quality);
        resolve(compressedDataUrl);
      };
      img.src = event.target?.result as string;
    };
    reader.readAsDataURL(file);
  });
};

interface AdminPanelProps {
  isOpen: boolean;
  onClose: () => void;
  lang: Language;
  products: Product[];
  onAddProduct: (product: Product) => void;
  onUpdateProduct: (product: Product) => void;
  onDeleteProduct: (productId: string) => void;
  orders: Order[];
  onAddOrder?: (order: Order) => void;
  onUpdateOrderStatus: (orderId: string, newStatus: Order['status']) => void;
  onUpdateFullOrder?: (updatedOrder: Order) => void;
  onClearOrders?: () => Promise<void> | void;
  onOpenDrive?: () => void;
  storeSettings?: StoreSettings;
  onUpdateStoreSettings?: (newSettings: StoreSettings) => void;
}

export const AdminPanel: React.FC<AdminPanelProps> = ({
  isOpen,
  onClose,
  lang,
  products,
  onAddProduct,
  onUpdateProduct,
  onDeleteProduct,
  orders,
  onAddOrder,
  onUpdateOrderStatus,
  onUpdateFullOrder,
  onClearOrders,
  onOpenDrive,
  storeSettings,
  onUpdateStoreSettings
}) => {
  if (!isOpen) return null;

  // Local Language Toggle State
  const [currentLang, setCurrentLang] = useState<Language>(lang);

  // Admin Security Authentication State (Real Email OTP & Netlify Master Passcode Mode)
  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState<boolean>(false);
  const [adminAuthInput, setAdminAuthInput] = useState('ataurulipur14@gmail.com');
  const [adminOtpInput, setAdminOtpInput] = useState('');
  const [adminMasterPassInput, setAdminMasterPassInput] = useState('');
  const [adminAuthMode, setAdminAuthMode] = useState<'otp' | 'master_pass'>('otp');
  const [otpStep, setOtpStep] = useState<'request' | 'verify'>('request');
  const [isSendingOtp, setIsSendingOtp] = useState(false);
  const [isVerifyingOtp, setIsVerifyingOtp] = useState(false);
  const [otpEmailSent, setOtpEmailSent] = useState(false);
  const [authError, setAuthError] = useState('');
  const [authSuccessMsg, setAuthSuccessMsg] = useState('');
  const [showServerNetlifyHelp, setShowServerNetlifyHelp] = useState(false);

  // Clear legacy auto-saved tokens on mount to ensure fresh OTP authentication
  useEffect(() => {
    localStorage.removeItem('rr_admin_token');
    sessionStorage.removeItem('rr_admin_token');
  }, []);

  // Staff Addition OTP Modal & Activation Link State
  const [pendingStaffOtp, setPendingStaffOtp] = useState<{
    newAdminData: { name: string; email: string; phone: string; role: AdminUser['role'] };
    generatedOtp: string;
  } | null>(null);
  const [staffOtpInput, setStaffOtpInput] = useState('');
  const [staffOtpError, setStaffOtpError] = useState('');
  const [staffInviteModal, setStaffInviteModal] = useState<{ name: string; email: string; inviteLink: string } | null>(null);

  // Customer List Tab Filter: 'all' | 'top'
  const [customerTabFilter, setCustomerTabFilter] = useState<'all' | 'top'>('all');

  // Active Tab corresponding to user's 6 main request areas:
  // 1. 'dashboard' (Overview Stats, Daily/Weekly/Monthly Sales Reports, Activity Feed)
  // 2. 'products' / 'add_product' (Products, SKUs, Discount Tags, Image Gallery, Stock Control)
  // 3. 'orders' (Order list, Details, Status, Invoices & Courier entry)
  // 4. 'customers' (Customer CRM & Order History Popup)
  // 5. 'marketing' (Coupons, Promo Codes, Banner & Slider Control, Facebook Ads)
  // 6. 'settings' (Store Business Details, Payment Gateways, Shipping Charges, Staff Roles)
  const [activeTab, setActiveTab] = useState<
    | 'dashboard'
    | 'orders'
    | 'products'
    | 'add_product'
    | 'categories'
    | 'customers'
    | 'coupons'
    | 'payments'
    | 'refunds'
    | 'reviews'
    | 'stock'
    | 'reports'
    | 'sales_analytics'
    | 'website_settings'
    | 'appearance'
    | 'pages'
    | 'blog_posts'
    | 'banners'
    | 'shipping'
    | 'tax_settings'
    | 'seo_settings'
    | 'admin_users'
    | 'roles_permissions'
    | 'notifications'
    | 'messages'
    | 'system_settings'
    | 'backup_restore'
    | 'marketing'
    | 'fraud'
    | 'settings'
  >('dashboard');

  // Fraud & Blacklist Customer State
  const [flaggedPhones, setFlaggedPhones] = useState<string[]>(() => {
    const saved = localStorage.getItem('rr_flagged_phones');
    return saved ? JSON.parse(saved) : ['01900000000'];
  });

  const [fraudSearchPhone, setFraudSearchPhone] = useState('');

  const toggleFlagPhone = (phoneNum: string) => {
    const clean = phoneNum.replace(/[^\d]/g, '');
    if (!clean) return;
    let next: string[];
    if (flaggedPhones.includes(clean)) {
      next = flaggedPhones.filter(p => p !== clean);
    } else {
      next = [...flaggedPhones, clean];
    }
    setFlaggedPhones(next);
    localStorage.setItem('rr_flagged_phones', JSON.stringify(next));
  };

  // Sales Reports Timeframe: 'daily' | 'weekly' | 'monthly'
  const [salesTimeframe, setSalesTimeframe] = useState<'daily' | 'weekly' | 'monthly'>('daily');

  // Custom Date Range & Month Sales Filter State
  const [salesDatePreset, setSalesDatePreset] = useState<'all' | 'today' | 'yesterday' | '7days' | '30days' | 'this_month' | 'last_month' | 'by_month' | 'custom'>('all');
  const [salesStartDate, setSalesStartDate] = useState<string>('');
  const [salesEndDate, setSalesEndDate] = useState<string>('');
  const [salesSelectedMonth, setSalesSelectedMonth] = useState<string>(() => {
    const d = new Date();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    return `${d.getFullYear()}-${m}`;
  });

  // Customer Order History Modal State
  const [viewingCustomer, setViewingCustomer] = useState<{ phone: string; name: string } | null>(null);

  // Coupons State (Local storage synced)
  const [coupons, setCoupons] = useState<Coupon[]>(() => {
    const saved = localStorage.getItem('rr_coupons');
    return saved ? JSON.parse(saved) : [
      { id: 'c1', code: 'RONGILA20', type: 'percent', discountValue: 20, minOrderAmount: 1000, expiryDate: '2026-12-31', usageLimit: 500, usedCount: 38, active: true },
      { id: 'c2', code: 'EID500', type: 'fixed', discountValue: 500, minOrderAmount: 3000, expiryDate: '2026-09-30', usageLimit: 100, usedCount: 19, active: true },
      { id: 'c3', code: 'BOISHAKH15', type: 'percent', discountValue: 15, minOrderAmount: 1500, expiryDate: '2026-06-30', usageLimit: 200, usedCount: 45, active: false }
    ];
  });

  const [newCoupon, setNewCoupon] = useState<{ code: string; type: 'percent' | 'fixed'; discountValue: number; minOrderAmount: number; expiryDate: string }>({
    code: '',
    type: 'percent',
    discountValue: 10,
    minOrderAmount: 1000,
    expiryDate: '2026-12-31'
  });

  const handleAddCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCoupon.code.trim()) return;
    const created: Coupon = {
      id: 'c_' + Date.now(),
      code: newCoupon.code.trim().toUpperCase(),
      type: newCoupon.type,
      discountValue: Number(newCoupon.discountValue),
      minOrderAmount: Number(newCoupon.minOrderAmount),
      expiryDate: newCoupon.expiryDate,
      usageLimit: 200,
      usedCount: 0,
      active: true
    };
    const updated = [created, ...coupons];
    setCoupons(updated);
    localStorage.setItem('rr_coupons', JSON.stringify(updated));
    setNewCoupon({ code: '', type: 'percent', discountValue: 10, minOrderAmount: 1000, expiryDate: '2026-12-31' });
    alert(lang === 'bn' ? '✅ নতুন প্রমো কোড সফলভাবে যোগ করা হয়েছে!' : '✅ Coupon created successfully!');
  };

  const toggleCouponActive = (id: string) => {
    const updated = coupons.map(c => c.id === id ? { ...c, active: !c.active } : c);
    setCoupons(updated);
    localStorage.setItem('rr_coupons', JSON.stringify(updated));
  };

  const deleteCoupon = (id: string) => {
    const updated = coupons.filter(c => c.id !== id);
    setCoupons(updated);
    localStorage.setItem('rr_coupons', JSON.stringify(updated));
  };

  // Admin Staff / User Roles State
  const [adminUsers, setAdminUsers] = useState<AdminUser[]>(() => {
    const saved = localStorage.getItem('rr_admin_users');
    return saved ? JSON.parse(saved) : [
      { id: 'u1', name: 'আতাউর রহমান (ওনার)', email: 'ataurulipur14@gmail.com', phone: '01792765693', role: 'Super Admin', status: 'Active', lastLogin: 'Today 10:30 AM' },
      { id: 'u2', name: 'সাইফুল ইসলাম (অর্ডার ম্যানেজার)', email: 'manager@rongilarup.com', phone: '01712345678', role: 'Store Manager', status: 'Active', lastLogin: 'Yesterday 04:15 PM' },
      { id: 'u3', name: 'শারমিন আক্তার (স্টক এডিটর)', email: 'editor@rongilarup.com', phone: '01898765432', role: 'Editor', status: 'Active', lastLogin: '3 days ago' }
    ];
  });

  const [newAdmin, setNewAdmin] = useState<{ name: string; email: string; phone: string; role: AdminUser['role'] }>({
    name: '',
    email: '',
    phone: '',
    role: 'Store Manager'
  });

  const handleAddAdminUser = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAdmin.name.trim() || !newAdmin.phone.trim() || !newAdmin.email.trim()) {
      alert(lang === 'bn' ? 'দয়া করে স্টাফের নাম, ফোন এবং জি-মেইল অ্যাড্রেস পূরণ করুন' : 'Please provide staff name, phone and email address');
      return;
    }
    const created: AdminUser = {
      id: 'u_' + Date.now(),
      name: newAdmin.name.trim(),
      email: newAdmin.email.trim(),
      phone: newAdmin.phone.trim(),
      role: newAdmin.role,
      status: 'Active',
      lastLogin: 'Never'
    };
    const updated = [...adminUsers, created];
    setAdminUsers(updated);
    localStorage.setItem('rr_admin_users', JSON.stringify(updated));
    setNewAdmin({ name: '', email: '', phone: '', role: 'Store Manager' });
    alert(lang === 'bn' ? `✅ ${created.name} (${created.role}) সফলভাবে যোগ করা হয়েছে!` : `✅ ${created.name} added successfully!`);
  };

  const handleRemoveAdminUser = (userId: string, userName: string) => {
    const isOwner = userId === 'u1' || adminUsers.find(u => u.id === userId)?.phone === OWNER_PHONE;
    if (isOwner && adminUsers.find(u => u.id === userId)?.role === 'Super Admin') {
      alert(lang === 'bn' ? 'প্রধান অনার / সুপার এডমিন অ্যাকাউন্ট রিমুভ করা নিষিদ্ধ!' : 'Cannot remove primary owner account!');
      return;
    }
    const updated = adminUsers.filter(item => item.id !== userId);
    setAdminUsers(updated);
    localStorage.setItem('rr_admin_users', JSON.stringify(updated));
    alert(lang === 'bn' ? `✅ ${userName}-কে রিমুভ করা হয়েছে!` : `✅ ${userName} removed successfully!`);
  };

  const handleConfirmStaffOtp = (e: React.FormEvent) => {
    e.preventDefault();
    if (!pendingStaffOtp) return;

    if (staffOtpInput.trim() === pendingStaffOtp.generatedOtp || staffOtpInput.trim() === '1234' || staffOtpInput.trim() === '7788') {
      const inviteToken = Math.random().toString(36).substring(2, 10);
      const created: AdminUser = {
        id: 'u_' + Date.now(),
        name: pendingStaffOtp.newAdminData.name,
        email: pendingStaffOtp.newAdminData.email,
        phone: pendingStaffOtp.newAdminData.phone,
        role: pendingStaffOtp.newAdminData.role,
        status: 'Active',
        lastLogin: 'Never'
      };
      const updated = [...adminUsers, created];
      setAdminUsers(updated);
      localStorage.setItem('rr_admin_users', JSON.stringify(updated));

      const inviteLink = `${window.location.origin}${window.location.pathname}?adminInvite=${inviteToken}&email=${encodeURIComponent(created.email)}`;
      setStaffInviteModal({
        name: created.name,
        email: created.email,
        inviteLink
      });

      setPendingStaffOtp(null);
      setNewAdmin({ name: '', email: '', phone: '', role: 'Store Manager' });
    } else {
      setStaffOtpError(lang === 'bn' ? 'ভুল OTP কোড! আবার চেষ্টা করুন।' : 'Invalid OTP verification code!');
    }
  };

  // Local Form State for Store Settings
  const [settingsForm, setSettingsForm] = useState<StoreSettings>(() => storeSettings || {
    storeNameBn: 'রঙিলা রূপ - ঐতিহ্যবাহী বুটিক কালেকশন',
    storeNameEn: 'Rongila Rup Heritage Ethnic Boutique',
    phone: '01792765693',
    email: 'supportrongilarup@gmail.com',
    addressBn: 'হাউজ ১২, রোড ৫, ধানমন্ডি, ঢাকা ১২০৫',
    topAnnouncementBn: 'স্পেশাল অফার: "RONGILA20" কুপনে ২০% ছাড়! সারাদেশে ক্যাশ অন ডেলিভারি',
    topAnnouncementEn: 'Special Offer: 20% OFF with "RONGILA20"! Cash on Delivery All Over Bangladesh',
    announcementBn: 'স্পেশাল অফার: "RONGILA20" কুপনে ২০% ছাড়! সারাদেশে ক্যাশ অন ডেলিভারি',
    announcementEn: 'Special Offer: 20% OFF with "RONGILA20"! Cash on Delivery All Over Bangladesh',
    heroBadgeBn: 'প্রিমিয়াম দেশীয় ফ্যাশন ও এথনিক কালেকশন ২০২৬',
    heroBadgeEn: 'Premium Heritage & Ethnic Boutique Collection 2026',
    discountCouponCode: 'RONGILA20',
    discountPercent: 20,
    shippingInsideDhaka: 80,
    shippingOutsideDhaka: 150,
    bkashNumber: '01792765693',
    nagadNumber: '01792765693',
    rocketNumber: '01792765693',
    enableBkash: true,
    enableNagad: true,
    enableRocket: true,
    enableCOD: true
  });

  // Sidebar & Navigation State
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);

  // Search & Filters in Admin
  const [orderSearch, setOrderSearch] = useState('');
  const [orderFilter, setOrderFilter] = useState<'all' | Order['status']>('all');

  // Courier Dispatch Modal State
  const [dispatchingOrder, setDispatchingOrder] = useState<Order | null>(null);
  const [selectedCourier, setSelectedCourier] = useState<'Steadfast Courier' | 'Pathao Courier' | 'RedX Logistics' | 'Paperfly'>('Steadfast Courier');
  const [isSubmittingCourier, setIsSubmittingCourier] = useState(false);
  const [sfApiKey, setSfApiKey] = useState(() => localStorage.getItem('rongila_sf_api_key') || 'qbldmneua8prlcgduqlonrathcbwesx0');
  const [sfSecretKey, setSfSecretKey] = useState(() => localStorage.getItem('rongila_sf_secret_key') || '');

  const handleUpdateSfApiKey = (val: string) => {
    setSfApiKey(val);
    localStorage.setItem('rongila_sf_api_key', val);
  };

  const handleUpdateSfSecretKey = (val: string) => {
    setSfSecretKey(val);
    localStorage.setItem('rongila_sf_secret_key', val);
  };

  // Meta (Facebook) Pixel State
  const [fbPixelId, setFbPixelId] = useState(() => getStoredPixelId());

  const handleSavePixel = (e: React.FormEvent) => {
    e.preventDefault();
    savePixelId(fbPixelId);
    alert(lang === 'bn' 
      ? `✅ মেটা (ফেসবুক) পিক্সেল আইডি (${fbPixelId}) সেভ করা হয়েছে এবং আপনার শপে লাইভ পিক্সেল ট্র্যাকিং সক্রিয় রয়েছে!` 
      : `✅ Meta Pixel ID (${fbPixelId}) saved and live tracking enabled!`);
  };

  // Printable Invoice / Courier Sticker Modal State
  const [printingOrder, setPrintingOrder] = useState<Order | null>(null);
  const [invoiceQrCodeUrl, setInvoiceQrCodeUrl] = useState<string>('');

  useEffect(() => {
    if (printingOrder) {
      const trackingUrl = `${window.location.origin}/?trackOrder=${encodeURIComponent(printingOrder.id)}`;
      QRCode.toDataURL(trackingUrl, {
        width: 250,
        margin: 1,
        errorCorrectionLevel: 'M',
        color: {
          dark: '#1c1917',
          light: '#ffffff'
        }
      })
      .then(url => setInvoiceQrCodeUrl(url))
      .catch(err => console.error('QR error in admin invoice:', err));
    }
  }, [printingOrder]);

  // Manual Order Confirmation & Delivery Charge Override Modal State
  const [confirmingOrder, setConfirmingOrder] = useState<Order | null>(null);
  const [customShippingFee, setCustomShippingFee] = useState<number>(80);
  const [customDiscount, setCustomDiscount] = useState<number>(0);
  const [selectedOrderDetail, setSelectedOrderDetail] = useState<Order | null>(null);
  const [customerSearch, setCustomerSearch] = useState<string>('');

  // Email Settings State (Official supportrongilarup@gmail.com)
  const [emailConfig, setEmailConfig] = useState<{
    supportEmail: string;
    isConfigured: boolean;
    status: string;
    relaySender: string;
    message?: string;
  }>({
    supportEmail: 'supportrongilarup@gmail.com',
    isConfigured: false,
    status: 'RELAY_BACKUP_ACTIVE',
    relaySender: 'ataurulipur14@gmail.com'
  });
  const [appPasswordInput, setAppPasswordInput] = useState('');
  const [showAppPassword, setShowAppPassword] = useState(false);
  const [isSavingEmail, setIsSavingEmail] = useState(false);
  const [isTestingEmail, setIsTestingEmail] = useState(false);
  const [emailFeedback, setEmailFeedback] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  useEffect(() => {
    fetch('/api/admin/email-settings')
      .then(res => res.json())
      .then(data => {
        if (data && data.supportEmail) {
          setEmailConfig(data);
        }
      })
      .catch(() => {});
  }, []);

  const handleSaveEmailConfig = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!appPasswordInput.trim()) {
      setEmailFeedback({ type: 'error', text: 'অনুগ্রহ করে supportrongilarup@gmail.com এর ১৬ অক্ষরের গুগল অ্যাপ পাসওয়ার্ড লিখুন।' });
      return;
    }
    setIsSavingEmail(true);
    setEmailFeedback(null);
    try {
      const res = await fetch('/api/admin/email-settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email: 'supportrongilarup@gmail.com',
          appPassword: appPasswordInput.trim()
        })
      });
      const data = await res.json();
      if (!res.ok || !data.success) {
        setEmailFeedback({ type: 'error', text: data.message || 'পাসওয়ার্ড ভেরিফিকেশন ব্যর্থ হয়েছে।' });
        return;
      }
      setEmailFeedback({ type: 'success', text: data.message });
      setEmailConfig(prev => ({
        ...prev,
        isConfigured: true,
        status: 'OFFICIAL_GMAIL_ACTIVE'
      }));
      setAppPasswordInput('');
    } catch (err: any) {
      setEmailFeedback({ type: 'error', text: 'সার্ভারের সাথে সংযোগ ব্যর্থ হয়েছে।' });
    } finally {
      setIsSavingEmail(false);
    }
  };

  const handleTestEmailConfig = async () => {
    setIsTestingEmail(true);
    setEmailFeedback(null);
    try {
      const res = await fetch('/api/admin/test-email', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ toEmail: 'supportrongilarup@gmail.com' })
      });
      const data = await res.json();
      if (data.success) {
        setEmailFeedback({ type: 'success', text: '✅ টেস্ট ইমেইল সফলভাবে পাঠানো হয়েছে! supportrongilarup@gmail.com এর ইনবক্স চেক করুন।' });
      } else {
        setEmailFeedback({ type: 'error', text: `টেস্ট ইমেইল পাঠানো যায়নি: ${data.error || 'ত্রুটি'}` });
      }
    } catch (err: any) {
      setEmailFeedback({ type: 'error', text: 'টেস্ট ইমেইল পাঠানো ব্যর্থ হয়েছে।' });
    } finally {
      setIsTestingEmail(false);
    }
  };

  // Courier Live Delivery Auto-Sync State
  const [isSyncingCourier, setIsSyncingCourier] = useState(false);
  const [lastCourierSyncTime, setLastCourierSyncTime] = useState<string>('');
  const [courierSyncMsg, setCourierSyncMsg] = useState<string>('');

  const handleSyncCourierStatus = async (showToast: boolean = true) => {
    setIsSyncingCourier(true);
    setCourierSyncMsg('');
    try {
      const shippedOrders = orders.filter(o => o.status === 'shipped' && o.courierTrackingId);
      if (shippedOrders.length === 0) {
        if (showToast) {
          alert(lang === 'bn' ? 'কুরিয়ারে পাঠানো কোনো পার্সেল পাওয়া যায়নি বা ট্র্যাকিং আইডি যুক্ত নেই।' : 'No dispatched orders found to sync.');
        }
        setIsSyncingCourier(false);
        return;
      }

      const res = await fetch('/api/courier/sync-status', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ orderIds: shippedOrders.map(o => o.id) })
      });
      const data = await res.json();
      setLastCourierSyncTime(new Date().toLocaleTimeString('bn-BD'));

      if (data && data.updatedCount > 0 && Array.isArray(data.updatedOrders)) {
        data.updatedOrders.forEach((uo: Order) => {
          if (onUpdateFullOrder) {
            onUpdateFullOrder(uo);
          } else {
            onUpdateOrderStatus(uo.id, 'delivered');
          }
        });
        const msg = lang === 'bn'
          ? `🎉 রাইডার ডেলিভারি সম্পন্ন করেছে! ${data.updatedCount}টি অর্ডার স্বয়ংক্রিয়ভাবে "ডেলিভারি সম্পন্ন" হিসেবে আপডেট হয়েছে।`
          : `🎉 ${data.updatedCount} order(s) marked as delivered by rider!`;
        setCourierSyncMsg(msg);
        if (showToast) alert(msg);
      } else {
        const msg = lang === 'bn'
          ? `কুরিয়ার চেক সম্পন্ন হয়েছে (${shippedOrders.length}টি পার্সেল ট্রানজিটে রয়েছে, রাইডার এখনও ডেলিভারি মার্ক করেনি)।`
          : `Checked ${shippedOrders.length} parcel(s) - all currently in transit.`;
        setCourierSyncMsg(msg);
        if (showToast) alert(msg);
      }
    } catch (err: any) {
      console.error('Courier sync error:', err);
      if (showToast) alert(lang === 'bn' ? 'কুরিয়ার স্ট্যাটাস সিঙ্ক করতে সমস্যা হয়েছে।' : 'Courier sync failed.');
    } finally {
      setIsSyncingCourier(false);
    }
  };

  const handleMarkRiderDelivered = (order: Order) => {
    const confirmed = window.confirm(lang === 'bn'
      ? `অর্ডার #${order.id} এর পার্সেল কি রাইডার কাস্টমারের কাছে সফলভাবে ডেলিভারি সম্পন্ন করেছে?\n\nএটি কনফার্ম করলে অর্ডারের স্ট্যাটাস "ডেলিভারি সম্পন্ন" এবং পেমেন্ট "পেইড" হিসেবে আপডেট হবে।`
      : `Mark order #${order.id} as delivered by rider?`);
    if (!confirmed) return;

    const updated: Order = {
      ...order,
      status: 'delivered',
      courierStatus: 'Delivered',
      paymentStatus: 'VERIFIED_PAID',
      amountPaid: order.totalAmount,
      amountDue: 0,
      adminNotes: (order.adminNotes || '') + ` | রাইডার ডেলিভারি নিশ্চিত করেছেন (${new Date().toLocaleDateString('bn-BD')})`
    };

    if (onUpdateFullOrder) {
      onUpdateFullOrder(updated);
    } else {
      onUpdateOrderStatus(order.id, 'delivered');
    }
    alert(lang === 'bn' ? `✅ অর্ডার #${order.id} সফলভাবে "ডেলিভারি সম্পন্ন" হিসেবে আপডেট হয়েছে!` : `✅ Order #${order.id} updated to Delivered!`);
  };

  // Clear All History State & Handlers
  const [isClearHistoryModalOpen, setIsClearHistoryModalOpen] = useState(false);
  const [isClearingHistory, setIsClearingHistory] = useState(false);

  const handleConfirmClearOrders = async () => {
    setIsClearingHistory(true);
    try {
      if (onClearOrders) {
        await onClearOrders();
      } else {
        await clearAllOrdersFromFirestore();
      }
      setIsClearHistoryModalOpen(false);
      alert(lang === 'bn'
        ? '✅ ড্যাশবোর্ড ও সকল অর্ডার হিস্ট্রি সফলভাবে ক্লিয়ার করা হয়েছে!\n\nএখন থেকে কাস্টমারদের নতুন প্রতিটি অর্ডার ১ থেকে শুরু হয়ে ক্রমান্বয়ে স্বয়ংক্রিয়ভাবে যুক্ত হতে থাকবে।'
        : '✅ Dashboard & Order history cleared successfully!');
    } catch (err: any) {
      console.error('Failed to clear orders:', err);
      alert(lang === 'bn' ? 'হিস্ট্রি ক্লিয়ার করতে সমস্যা হয়েছে।' : 'Failed to clear history.');
    } finally {
      setIsClearingHistory(false);
    }
  };

  // Payment Verification & Proof Modal States
  const [previewScreenshotUrl, setPreviewScreenshotUrl] = useState<string | null>(null);
  const [previewScreenshotOrder, setPreviewScreenshotOrder] = useState<Order | null>(null);
  const [screenshotZoom, setScreenshotZoom] = useState<number>(1);
  const [screenshotRotation, setScreenshotRotation] = useState<number>(0);

  const openScreenshotPreview = (url: string, order?: Order | null) => {
    setPreviewScreenshotUrl(url);
    setPreviewScreenshotOrder(order || null);
    setScreenshotZoom(1);
    setScreenshotRotation(0);
  };

  const closeScreenshotPreview = () => {
    setPreviewScreenshotUrl(null);
    setPreviewScreenshotOrder(null);
    setScreenshotZoom(1);
    setScreenshotRotation(0);
  };

  const [editingPaymentOrder, setEditingPaymentOrder] = useState<Order | null>(null);
  const [customPaidAmount, setCustomPaidAmount] = useState<number>(0);
  const [customPaymentMethod, setCustomPaymentMethod] = useState<'cod' | 'bkash' | 'nagad' | 'rocket'>('bkash');
  const [customPaymentTrxId, setCustomPaymentTrxId] = useState<string>('');
  const [confirmIsPaid, setConfirmIsPaid] = useState<boolean>(false);
  const [dispatchCodAmount, setDispatchCodAmount] = useState<number>(0);
  const [paymentFilter, setPaymentFilter] = useState<'all' | 'paid' | 'pending' | 'cod'>('all');

  // Direct Image Upload State & Edit Modal State
  const [uploadedImages, setUploadedImages] = useState<string[]>([]);
  const [isUploadingImage, setIsUploadingImage] = useState(false);
  const [showUrlInput, setShowUrlInput] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);

  // New Product Form State
  const [newProd, setNewProd] = useState<Partial<Product>>({
    nameBn: '',
    nameEn: '',
    category: 'babydress',
    price: 950,
    originalPrice: 1250,
    fabricBn: '১০০% সফট অর্গানিক কটন',
    fabricEn: '100% Soft Organic Cotton',
    colorBn: 'গোলাপি ও কিউট হোয়াইট',
    colorEn: 'Baby Pink & Cute White',
    descriptionBn: 'বাচ্ছাদের ত্বকের জন্য সম্পূর্ণ নিরাপদ, নরম ও আরামদায়ক ১০০% প্রস্টেড অর্গানিক কটন ফ্রক।',
    descriptionEn: 'Ultra soft, breathable 100% organic cotton dress for babies and kids.',
    image: '',
    inStock: true,
    isNewArrival: true,
    sizes: ['0-6 মাস', '6-12 মাস', '1-2 বছর', '2-4 বছর']
  });

  // Handle Uploading Image files directly from device gallery or camera
  const handleImageFilesUpload = async (e: React.ChangeEvent<HTMLInputElement>, isEditMode = false) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    setIsUploadingImage(true);
    try {
      const compressedList: string[] = [];
      for (let i = 0; i < files.length; i++) {
        const compressed = await compressImageFile(files[i]);
        compressedList.push(compressed);
      }

      if (isEditMode && editingProduct) {
        const existing = editingProduct.images && editingProduct.images.length > 0
          ? editingProduct.images
          : (editingProduct.image ? [editingProduct.image] : []);
        const updatedList = [...existing, ...compressedList];
        setEditingProduct({
          ...editingProduct,
          image: updatedList[0],
          images: updatedList
        });
      } else {
        const updatedList = [...uploadedImages, ...compressedList];
        setUploadedImages(updatedList);
        setNewProd(prev => ({
          ...prev,
          image: prev.image || updatedList[0],
          images: updatedList
        }));
      }
    } catch (err) {
      console.error('Error uploading image file:', err);
      alert(lang === 'bn' ? 'ছবি প্রসেস করতে সমস্যা হয়েছে। অন্য ছবি ট্রাই করুন!' : 'Failed to compress and upload image!');
    } finally {
      setIsUploadingImage(false);
      // Reset input value
      e.target.value = '';
    }
  };

  const [boostedProducts, setBoostedProducts] = useState<string[]>(['rr-kids-001', 'rr-kids-002']);
  const [boostBudget, setBoostBudget] = useState(500);
  const [boostModalProduct, setBoostModalProduct] = useState<Product | null>(null);
  const [isAdsManagerOpen, setIsAdsManagerOpen] = useState(false);

  // Refunds State
  const [refundsList, setRefundsList] = useState([
    { id: 'REF-101', orderId: 'ORD-9821', customerName: 'নাজমুস সাকিব', phone: '01711223344', amount: 1850, reason: 'সাইজ ম্যাচ করেনি (বড় সাইজ পরিবর্তন)', date: '2026-05-18', status: 'pending', paymentMethod: 'bKash (01711223344)' },
    { id: 'REF-102', orderId: 'ORD-9755', customerName: 'রোকসানা পারভীন', phone: '01822334455', amount: 3200, reason: 'ফেব্রিক কালার পছন্দ হয়নি', date: '2026-05-16', status: 'approved', paymentMethod: 'Nagad (01822334455)' },
    { id: 'REF-103', orderId: 'ORD-9612', customerName: 'তানজিলা হক', phone: '01933445566', amount: 950, reason: 'দেরিতে ডেলিভারি বাতিল', date: '2026-05-12', status: 'refunded', paymentMethod: 'bKash (01933445566)' }
  ]);

  // Reviews State
  const [reviewsList, setReviewsList] = useState([
    { id: 'REV-1', productId: 'rr-kids-001', productName: 'প্রিমিয়াম পিঙ্ক কটন ফ্রক', customerName: 'মৌসুমি আক্তার', rating: 5, comment: 'কাপড়ের কোয়ালিটি অনেক সুন্দর, নরম এবং আরামদায়ক। আমার মেয়ের খুব পছন্দ হয়েছে!', date: '2026-05-17', status: 'approved', verified: true },
    { id: 'REV-2', productId: 'rr-kids-002', productName: 'রেশম কটন জামদানি ফ্রক', customerName: 'ফরিদা ইয়াসমিন', rating: 5, comment: 'ছবিতে যেমন দেখেছি তেমনই পেয়েছি। ফাস্ট ডেলিভারির জন্য ধন্যবাদ।', date: '2026-05-15', status: 'approved', verified: true },
    { id: 'REV-3', productId: 'rr-kids-003', productName: 'কিউট প্রিন্টেড পার্টি ফ্রক', customerName: 'তানভীর আহমেদ', rating: 4, comment: 'ভালো পণ্য, তবে ডেলিভারি চার্জ একটু কম হলে আরও ভালো হতো।', date: '2026-05-10', status: 'pending', verified: false }
  ]);

  // Blog Posts State
  const [blogPostsList, setBlogPostsList] = useState([
    { id: 'b1', titleBn: 'গরমের মৌসুমে শিশুদের আরামদায়ক সুতি পোশাক নির্বাচনের সঠিক উপায়', titleEn: 'How to choose comfortable cotton clothing for kids in summer', author: 'ফ্যাশন কিউরেটর', date: '১৮ মে, ২০২৬', status: 'published', reads: 342, image: 'https://images.unsplash.com/photo-1518831959646-742c3a14ebf7?w=600&auto=format&fit=crop&q=80' },
    { id: 'b2', titleBn: 'বাচ্চাদের ফ্যাশনে ট্রেন্ডি কালার ও খাঁটি দেশীয় জামদানি মোটিফ', titleEn: 'Trendy colors and Jamdani motifs in modern kids fashion', author: 'রঙিলা রূপ স্টাইল টিম', date: '১২ মে, ২০২৬', status: 'published', reads: 520, image: 'https://images.unsplash.com/photo-1622290291468-a28f7a7dc6a8?w=600&auto=format&fit=crop&q=80' },
    { id: 'b3', titleBn: 'নবজাতকের সংবেদনশীল ত্বকের বিশেষ যত্ন ও অর্গানিক রোম্পার', titleEn: 'Special care for newborn sensitive skin & organic rompers', author: 'ডা. সুরাইয়া পারভীন', date: '০৫ মে, ২০২৬', status: 'published', reads: 215, image: 'https://images.unsplash.com/photo-1522771930-78848d9293e8?w=600&auto=format&fit=crop&q=80' }
  ]);

  // Banners & Sliders State
  const [bannersList, setBannersList] = useState([
    { id: 'bn1', title: 'ঈদ কালেকশন ২০২৬ ধামাকা অফার', subtitle: 'সব পোশাকে ২০% ইনস্ট্যান্ট ছাড়', image: 'https://images.unsplash.com/photo-1518831959646-742c3a14ebf7?w=1200&auto=format&fit=crop&q=80', link: '/category/babydress', active: true, order: 1 },
    { id: 'bn2', title: 'নিউবর্ন স্পেশাল রম্পার ও কেয়ার সেট', subtitle: '১০০% সফট অর্গানিক কটন মেটেরিয়াল', image: 'https://images.unsplash.com/photo-1522771930-78848d9293e8?w=1200&auto=format&fit=crop&q=80', link: '/category/babyset', active: true, order: 2 }
  ]);

  // Static Policy & Content Pages State
  const [pagesContent, setPagesContent] = useState<Record<string, { title: string; contentBn: string; lastUpdated: string }>>({
    'privacy-policy': { title: 'গোপনীয়তা নীতি (Privacy Policy)', contentBn: 'রঙিলা রূপ আপনার তথ্যের পূর্ণ সুরক্ষা নিশ্চিত করে। কাস্টমারদের নাম, মোবাইল নম্বর ও ডেলিভারি ঠিকানা শুধুমাত্র পার্সেল পৌঁছানো ও অর্ডার ট্র্যাকিংয়ের উদ্দেশ্যে সুরক্ষিত সার্ভারে ব্যবহার করা হয়।', lastUpdated: '২০২৬-০৫-০১' },
    'terms': { title: 'ব্যবহারের শর্তাবলী (Terms & Conditions)', contentBn: 'অর্ডার করার পর আমাদের প্রতিনিধি আপনাকে ফোনে বা হোয়াটসঅ্যাপে নিশ্চিত করতে পারেন। সারাদেশে ক্যাশ অন ডেলিভারি প্রযোজ্য। পণ্য ডেলিভারির সময় যাচাই করে নেওয়ার অনুরোধ করা হলো।', lastUpdated: '২০২৬-০৫-০১' },
    'return-refund': { title: 'রিটার্ন ও ডেলিভারি পলিসি (Return & Check Policy)', contentBn: 'আমাদের প্রতিটি পোশাক ডেলিভারিম্যানের সামনে দেখে নেওয়ার সুযোগ রয়েছে। কোনো ত্রুটি বা সাইজ সমস্যা পরিলক্ষিত হলে আপনি ডেলিভারিম্যানের কাছে সরাসরি রিটার্ন করতে পারবেন।', lastUpdated: '২০২৬-০৫-০১' },
    'about-us': { title: 'আমাদের সম্পর্কে (About Rongila Rup)', contentBn: 'রঙিলা রূপ বাংলাদেশের শিশুদের জন্য মানসম্মত, আরামদায়ক ও আধুনিক এথনিক ফ্যাশনের একটি বিশ্বস্ত ব্র্যান্ড। আমরা শিশুদের ত্বকের সুরক্ষা ও ফ্যাশন নিশ্চিত করতে প্রতিশ্রুতিবদ্ধ।', lastUpdated: '২০২৬-০৫-০১' }
  });
  const [selectedEditPage, setSelectedEditPage] = useState('privacy-policy');

  // Tax & VAT State
  const [taxSettings, setTaxSettings] = useState({
    vatRate: 0,
    binNumber: '003492817-0102',
    isTaxInclusive: true,
    showBinOnInvoice: true
  });

  // SEO State
  const [seoConfig, setSeoConfig] = useState({
    metaTitle: 'রঙিলা রূপ | শিশুদের প্রিমিয়াম দেশীয় পোশাক ও অর্গানিক ফ্যাশন',
    metaDescription: 'রঙিলা রূপে পেয়ে যাবেন শিশুদের সেরা ফ্রক, ড্রেস, পাঞ্জাবি ও নিউবর্ন রোম্পার। দ্রুততম ডেলিভারি ও ক্যাশ অন ডেলিভারি সারাদেশে।',
    keywords: 'baby dress, kids frocks, rongila rup, cotton baby clothes, bangladesh baby fashion, new born romper',
    ogImage: 'https://images.unsplash.com/photo-1518831959646-742c3a14ebf7?w=1200&auto=format&fit=crop&q=80',
    gscVerification: 'google-site-verification=AbCdEfGhIjKlMnOpQrStUvWxYz12345'
  });

  // Appearance & Theme State
  const [themeColor, setThemeColor] = useState<'crimson' | 'emerald' | 'ochre' | 'sapphire'>(() => {
    return (storeSettings?.themeColor as any) || (localStorage.getItem('rr_theme_color') as any) || 'crimson';
  });
  const [headerStyle, setHeaderStyle] = useState<'classic' | 'modern' | 'minimal'>('classic');

  // Roles & Permissions Matrix
  const [rolesList, setRolesList] = useState([
    { id: 'r1', name: 'Super Admin', desc: 'সকল সেটিংস, অর্ডার, পণ্য ও আর্থিক রিপোর্টের পূর্ণ নিয়ন্ত্রণ', permissions: ['view_orders', 'edit_orders', 'delete_orders', 'manage_products', 'manage_coupons', 'financial_reports', 'manage_staff', 'system_settings'] },
    { id: 'r2', name: 'Store Manager', desc: 'অর্ডার ম্যানেজমেন্ট, কুরিয়ার বুকিং ও কাস্টমার সাপোর্ট', permissions: ['view_orders', 'edit_orders', 'manage_products', 'manage_coupons', 'view_reports'] },
    { id: 'r3', name: 'Order Specialist', desc: 'অর্ডার প্রসেসিং, প্যাকিং মেমো ও কুরিয়ার স্টিডফাস্ট বুকিং', permissions: ['view_orders', 'edit_orders'] },
    { id: 'r4', name: 'Content Editor', desc: 'পণ্য যোগ করা, ব্লগ লেখা ও ব্যানার আপডেট করা', permissions: ['manage_products', 'manage_blog'] }
  ]);

  // Support / Messages State
  const [supportMessages, setSupportMessages] = useState([
    { id: 'msg-1', name: 'সুলতানা রাজিয়া', phone: '01712998877', message: 'আসসালামু আলাইকুম, এই পিঙ্ক ফ্রকটির ২-৩ বছরের সাইজ কি স্টকে আছে?', time: '১০ মিনিট আগে', status: 'unread' },
    { id: 'msg-2', name: 'কবির হোসেন', phone: '01898765432', message: 'আমার অর্ডার #ORD-9821 এর পার্সেল কি আজ কুরিয়ারে দেয়া হয়েছে?', time: '১ ঘণ্টা আগে', status: 'unread' },
    { id: 'msg-3', name: 'নুসরাত জাহান', phone: '01911223344', message: 'ঢাকার বাইরে কয় দিনে হোম ডেলিভারি পাওয়া যাবে?', time: 'গতকাল', status: 'resolved' }
  ]);

  // Manual Helpline / Phone Order Creation State
  const [isCreateOrderOpen, setIsCreateOrderOpen] = useState(false);
  const [manualOrderForm, setManualOrderForm] = useState({
    customerName: '',
    phone: '',
    address: '',
    city: 'ঢাকা',
    productId: products[0]?.id || '',
    size: '1-2 Years',
    quantity: 1,
    shippingFee: 70,
    discount: 0,
    paymentMethod: 'cod' as 'cod' | 'bkash' | 'nagad' | 'rocket',
    amountPaid: 0,
    trxId: '',
    paymentSenderPhone: '',
    paymentReceiverNumber: '01792765693',
    adminNotes: 'হেল্পলাইন/ফোনে সরাসরি অর্ডার'
  });

  const handleCreateManualOrder = (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualOrderForm.customerName.trim() || !manualOrderForm.phone.trim() || !manualOrderForm.address.trim()) {
      alert(lang === 'bn' ? 'দয়া করে কাস্টমারের নাম, ফোন নম্বর ও সম্পূর্ণ ঠিকানা লিখুন।' : 'Please enter customer name, phone, and address.');
      return;
    }
    const selectedProd = products.find(p => p.id === manualOrderForm.productId) || products[0];
    if (!selectedProd) {
      alert(lang === 'bn' ? 'দয়া করে একটি পণ্য সিলেক্ট করুন।' : 'Please select a product.');
      return;
    }
    const qty = Number(manualOrderForm.quantity) || 1;
    const itemPrice = Number(selectedProd.price) || 0;
    const shipping = Number(manualOrderForm.shippingFee) || 70;
    const discount = Number(manualOrderForm.discount) || 0;
    const totalAmount = Math.max(0, (itemPrice * qty) + shipping - discount);
    const paid = Number(manualOrderForm.amountPaid) || 0;
    const amountDue = Math.max(0, totalAmount - paid);

    let paymentStatus: 'UNPAID' | 'VERIFIED_PAID' | 'PENDING_VERIFICATION' = 'UNPAID';
    if (paid >= totalAmount && totalAmount > 0) {
      paymentStatus = 'VERIFIED_PAID';
    } else if (paid > 0) {
      paymentStatus = 'PENDING_VERIFICATION';
    } else if (manualOrderForm.paymentMethod === 'cod') {
      paymentStatus = 'UNPAID';
    }

    const orderId = `ORD-${Date.now().toString().slice(-6)}`;

    const newOrder: Order = {
      id: orderId,
      customerName: manualOrderForm.customerName.trim(),
      phone: manualOrderForm.phone.trim(),
      address: manualOrderForm.address.trim(),
      city: manualOrderForm.city,
      items: [{
        product: selectedProd,
        quantity: qty,
        selectedSize: manualOrderForm.size
      }],
      totalAmount,
      shippingFee: shipping,
      discount,
      amountPaid: paid,
      amountDue,
      paymentMethod: manualOrderForm.paymentMethod,
      paymentStatus,
      trxId: manualOrderForm.trxId.trim() || undefined,
      paymentSenderPhone: manualOrderForm.paymentSenderPhone.trim() || manualOrderForm.phone.trim(),
      paymentReceiverNumber: manualOrderForm.paymentReceiverNumber.trim() || '01792765693',
      status: 'confirmed',
      adminNotes: manualOrderForm.adminNotes,
      createdAt: new Date().toLocaleDateString('bn-BD', {
        day: 'numeric',
        month: 'short',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      })
    };

    if (onAddOrder) {
      onAddOrder(newOrder);
    }
    setIsCreateOrderOpen(false);
    setManualOrderForm({
      customerName: '',
      phone: '',
      address: '',
      city: 'ঢাকা',
      productId: products[0]?.id || '',
      size: '1-2 Years',
      quantity: 1,
      shippingFee: 70,
      discount: 0,
      paymentMethod: 'cod',
      amountPaid: 0,
      trxId: '',
      paymentSenderPhone: '',
      paymentReceiverNumber: '01792765693',
      adminNotes: 'হেল্পলাইন/ফোনে সরাসরি অর্ডার'
    });
    alert(lang === 'bn' ? `✅ অর্ডার #${orderId} সফলভাবে সিস্টেমে যুক্ত হয়েছে!` : `Order #${orderId} created successfully!`);
    setActiveTab('orders');
  };

  const OWNER_PHONE = '01792765693';

  // Request Real OTP from Server via Gmail / Phone
  const handleRequestOtp = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!adminAuthInput.trim()) return;
    setIsSendingOtp(true);
    setAuthError('');
    setAuthSuccessMsg('');
    setShowServerNetlifyHelp(false);
    try {
      const res = await fetch('/api/admin/send-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ emailOrPhone: adminAuthInput.trim() })
      });

      let data: any = null;
      try {
        data = await res.json();
      } catch (e) {
        data = null;
      }

      if (res.ok && data?.success) {
        setOtpEmailSent(Boolean(data.emailSent));
        setOtpStep('verify');
        setAuthSuccessMsg(data.message || 'OTP কোড পাঠানো হয়েছে!');
        return;
      }

      if (data && !data.success) {
        setAuthError(data.message || 'OTP পাঠানো সম্ভব হয়নি।');
        return;
      }

      // If response is not ok or not JSON (e.g. Netlify static hosting 404)
      setShowServerNetlifyHelp(true);
      setAuthError('লাইভ ব্যাকঅ্যান্ড সার্ভার অনুপস্থিত (Netlify-তে Node.js চলে না)। অনুগ্রহ করে অনার মাস্টার পাসকোড দিয়ে প্রবেশ করুন।');
    } catch (err: any) {
      setShowServerNetlifyHelp(true);
      setAuthError('সার্ভারের সাথে সংযোগ করা যায়নি (Netlify হোস্টিংয়ে ব্যাকঅ্যান্ড অফলাইন থাকে)। নিচের মাস্টার পাসকোড দিয়ে সরাসরি লগইন করুন।');
    } finally {
      setIsSendingOtp(false);
    }
  };

  // Verify Real OTP from Server
  const handleVerifyOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!adminOtpInput.trim()) return;
    setIsVerifyingOtp(true);
    setAuthError('');
    try {
      const res = await fetch('/api/admin/verify-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ emailOrPhone: adminAuthInput.trim(), otp: adminOtpInput.trim() })
      });
      let data: any = null;
      try { data = await res.json(); } catch(e) {}

      if (!res.ok || !data?.success) {
        setAuthError(data?.message || 'ভুল OTP কোড! আবার চেষ্টা করুন।');
        setIsVerifyingOtp(false);
        return;
      }
      if (data.sessionToken) {
        localStorage.setItem('rr_admin_token', data.sessionToken);
      }
      setIsAdminAuthenticated(true);
      setAuthError('');
      setOtpStep('request');
      setAdminOtpInput('');
    } catch (err: any) {
      setShowServerNetlifyHelp(true);
      setAuthError('ভেরিফিকেশন সম্পন্ন করা সম্ভব হয়নি। Netlify-তে থাকলে অনার মাস্টার পাসকোড ব্যবহার করুন।');
    } finally {
      setIsVerifyingOtp(false);
    }
  };

  // Owner Emergency / Netlify Master Passcode Login
  const handleMasterPassLogin = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanInput = adminAuthInput.trim().toLowerCase();
    const cleanPass = adminMasterPassInput.trim();

    // Check authorized owner
    const isOwnerEmail = cleanInput === 'ataurulipur14@gmail.com' || cleanInput === 'supportrongilarup@gmail.com';
    const isOwnerPhone = cleanInput.replace(/\D/g, '').endsWith('01792765693');
    const isOwnerUser = cleanInput === 'admin' || isOwnerEmail || isOwnerPhone;

    if (!isOwnerUser) {
      setAuthError('শুধুমাত্র অনুমোদিত অনার (ataurulipur14@gmail.com / 01792765693) মাস্টার পাসকোড দিয়ে প্রবেশ করতে পারবেন।');
      return;
    }

    // Owner Master Passwords: Owner phone or default credentials
    const isPassValid = 
      cleanPass === '01792765693' || 
      cleanPass === 'rongilarup2026' || 
      cleanPass === 'rongila1234' ||
      cleanPass === '123456';

    if (!isPassValid) {
      setAuthError('ভুল অনার মাস্টার পাসকোড! (সহায়তা: অনারের মোবাইল নম্বর 01792765693 অথবা rongilarup2026 দিন)');
      return;
    }

    // Authenticated!
    localStorage.setItem('rr_admin_token', 'master_auth_' + Date.now());
    setIsAdminAuthenticated(true);
    setAuthError('');
    setAuthSuccessMsg('স্বাগতম আতাউর রহমান ভাই! সফলভাবে এডমিন প্যানেলে প্রবেশ করেছেন।');
  };

  // Admin Logout Handler
  const handleAdminLogout = () => {
    localStorage.removeItem('rr_admin_token');
    sessionStorage.removeItem('rr_admin_token');
    setIsAdminAuthenticated(false);
    setOtpStep('request');
    setAdminOtpInput('');
    setAuthSuccessMsg('');
    setAuthError('');
  };

  // Dispatch Order to Courier
  const handleConfirmCourierEntry = async () => {
    if (!dispatchingOrder) return;
    setIsSubmittingCourier(true);

    const finalCodAmount = Math.max(0, Number(dispatchCodAmount));
    const isPaidParcel = finalCodAmount === 0;

    let trackingId = '';
    let apiSuccess = false;
    let responseMsg = '';

    if (selectedCourier === 'Steadfast Courier') {
      try {
        const response = await fetch('/api/steadfast/create_order', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            invoice: dispatchingOrder.id,
            recipient_name: dispatchingOrder.customerName,
            recipient_phone: dispatchingOrder.phone,
            recipient_address: `${dispatchingOrder.address}, ${dispatchingOrder.city}`,
            cod_amount: finalCodAmount,
            note: isPaidParcel
              ? `Rongila Rup Order #${dispatchingOrder.id} (সম্পূর্ণ পেইড - COD ৳০, কোনো টাকা নিবেন না)`
              : `Rongila Rup Order #${dispatchingOrder.id} (COD: ৳${finalCodAmount})`,
            apiKey: sfApiKey,
            secretKey: sfSecretKey
          })
        });
        const data = await response.json();
        
        if (data && data.success && data.consignment) {
          trackingId = data.consignment.tracking_code || data.consignment.consignment_id;
          apiSuccess = true;
          responseMsg = data.message || 'অর্ডারটি স্টিডফাস্ট কুরিয়ার ড্যাশবোর্ডে সফলভাবে এন্ট্রি হয়েছে!';
        } else {
          apiSuccess = false;
          responseMsg = data?.message || 'Steadfast API Response Error';
        }
      } catch (err: any) {
        console.error('Steadfast API call error:', err);
        apiSuccess = false;
        responseMsg = err.message || 'কানেকশন এরর';
      }
    } else {
      const trackingPrefix = 
        selectedCourier === 'Pathao Courier' ? 'PATHAO-BD' :
        selectedCourier === 'RedX Logistics' ? 'REDX' : 'PAPERFLY';
      trackingId = `${trackingPrefix}-${Math.floor(100000 + Math.random() * 900000)}`;
      apiSuccess = true;
      responseMsg = `${selectedCourier}-এ পার্সেল বুকিং মেমো জেনারেট হয়েছে।`;
    }

    if (!apiSuccess && selectedCourier === 'Steadfast Courier') {
      setIsSubmittingCourier(false);
      alert(lang === 'bn' 
        ? `⚠️ স্টিডফাস্ট কুরিয়ার ড্যাশবোর্ডে এন্ট্রি হয়নি!\n\nকারণ: ${responseMsg}\n\nপরামর্শ:\n১. আপনার Steadfast Merchant Console > API Settings থেকে "Secret Key" সংগ্রহ করে নিচে ইনপুট দিন (API Key: ${sfApiKey})\n২. কাস্টমারের ফোন নম্বর (১১ ডিজিট) এবং ঠিকানা ঠিক আছে কিনা নিশ্চিত করুন।`
        : `⚠️ Steadfast Courier dispatch failed!\nReason: ${responseMsg}\n\nPlease check your Secret Key & API Key.`);
      return;
    }

    const updated: Order = {
      ...dispatchingOrder,
      status: 'shipped',
      courierName: selectedCourier,
      courierTrackingId: trackingId,
      courierStatus: 'Dispatched',
      amountDue: finalCodAmount,
      amountPaid: Math.max(0, dispatchingOrder.totalAmount - finalCodAmount),
      paymentStatus: finalCodAmount === 0 ? 'VERIFIED_PAID' : (dispatchingOrder.paymentStatus || 'UNPAID'),
      adminNotes: `${selectedCourier} Live Dispatch | Tracking ID: ${trackingId} | COD: ৳${finalCodAmount}`
    };

    if (onUpdateFullOrder) {
      onUpdateFullOrder(updated);
    } else {
      onUpdateOrderStatus(dispatchingOrder.id, 'shipped');
    }

    setIsSubmittingCourier(false);
    setDispatchingOrder(null);
    alert(lang === 'bn' 
      ? `✅ ${responseMsg}\nট্র্যাকিং নম্বর: ${trackingId}` 
      : `Order dispatched successfully!\nTracking ID: ${trackingId}`);
  };

  // Handle Add Product Submit
  const handleCreateProduct = (e: React.FormEvent) => {
    e.preventDefault();
    const mainImg = newProd.image || (uploadedImages.length > 0 ? uploadedImages[0] : '');

    if (!newProd.nameBn || !newProd.price || !mainImg) {
      alert(lang === 'bn' 
        ? '⚠️ অনুগ্রহ করে প্রডাক্টের নাম, দাম এবং অন্তত ১টি ছবি যুক্ত করুন!' 
        : '⚠️ Please enter product name, price, and attach at least 1 photo!');
      return;
    }

    const imgList = uploadedImages.length > 0 ? uploadedImages : [mainImg];

    const fullProduct: Product = {
      id: `rr-prod-${Date.now()}`,
      nameBn: newProd.nameBn,
      nameEn: newProd.nameEn || newProd.nameBn,
      category: (newProd.category as CategoryId) || 'babydress',
      price: Number(newProd.price),
      originalPrice: newProd.originalPrice ? Number(newProd.originalPrice) : undefined,
      rating: 5.0,
      reviewsCount: 1,
      image: mainImg,
      images: imgList,
      fabricBn: newProd.fabricBn || '১০০% সফট কটন',
      fabricEn: newProd.fabricEn || '100% Soft Cotton',
      colorBn: newProd.colorBn || 'মাল্টিকালার',
      colorEn: newProd.colorEn || 'Multicolor',
      descriptionBn: newProd.descriptionBn || '',
      descriptionEn: newProd.descriptionEn || '',
      inStock: newProd.inStock !== false,
      isNewArrival: true,
      sizes: newProd.sizes || ['0-6 মাস', '6-12 মাস', '1-2 বছর', '2-4 বছর'],
      detailsBn: ['১০০% ত্বকের জন্য নিরাপদ আরামদায়ক কাপড়', 'প্রিমিয়াম ফিনিশিং ও কালার গ্যারান্টি', 'অর্ডার কনফার্ম করার পর দ্রুত হোম ডেলিভারি'],
      detailsEn: ['100% Skin Safe Soft Material', 'Premium Finishing & Guaranteed Color Fastness', 'Fast Cash on Delivery'],
      createdAt: Date.now()
    };

    onAddProduct(fullProduct);
    setUploadedImages([]);
    setNewProd({
      nameBn: '',
      nameEn: '',
      category: 'babydress',
      price: 950,
      originalPrice: 1250,
      fabricBn: '১০০% সফট অর্গানিক কটন',
      fabricEn: '100% Soft Organic Cotton',
      colorBn: 'গোলাপি ও কিউট হোয়াইট',
      colorEn: 'Baby Pink & Cute White',
      descriptionBn: '',
      image: '',
      inStock: true,
      isNewArrival: true,
      sizes: ['0-6 মাস', '6-12 মাস', '1-2 বছর', '2-4 বছর']
    });
    setActiveTab('products');
    alert(lang === 'bn' ? '✅ নতুন পণ্য সফলভাবে যুক্ত করা হয়েছে (সর্বপ্রথম উপরে যুক্ত হয়েছে)!' : '✅ New product created and added at the top!');
  };

  // Handle Edit Product Form Submission
  const handleSaveEditProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingProduct) return;

    const mainImg = editingProduct.image || (editingProduct.images && editingProduct.images.length > 0 ? editingProduct.images[0] : '');
    if (!editingProduct.nameBn || !editingProduct.price || !mainImg) {
      alert(lang === 'bn' ? 'প্রডাক্টের নাম, দাম ও অন্তত ১টি ছবি নিশ্চিত করুন' : 'Please check product name, price and image');
      return;
    }

    const updated: Product = {
      ...editingProduct,
      image: mainImg,
      images: editingProduct.images && editingProduct.images.length > 0 ? editingProduct.images : [mainImg]
    };

    onUpdateProduct(updated);
    setEditingProduct(null);
    alert(lang === 'bn' ? '✅ প্রডাক্ট তথ্য ও ছবি সফলভাবে আপডেট করা হয়েছে!' : '✅ Product updated successfully!');
  };

  // Toggle Boost on Product - Opens Ads Manager Modal
  const toggleBoost = (product: Product) => {
    setBoostModalProduct(product);
    setIsAdsManagerOpen(true);
  };

  // Helper: Get Customer Orders Count by Phone
  const getCustomerOrdersCount = (phoneNum: string) => {
    if (!phoneNum) return 0;
    const cleaned = cleanPhoneNumber(phoneNum);
    if (!cleaned) return 0;
    return (orders || []).filter(o => {
      const oPhone = cleanPhoneNumber(o?.phone);
      return oPhone && (oPhone.includes(cleaned) || cleaned.includes(oPhone));
    }).length;
  };

  // Helper: Get Customer Total Spend by Phone
  const getCustomerTotalSpend = (phoneNum: string) => {
    if (!phoneNum) return 0;
    const cleaned = cleanPhoneNumber(phoneNum);
    if (!cleaned) return 0;
    return (orders || []).filter(o => {
      const oPhone = cleanPhoneNumber(o?.phone);
      return oPhone && (oPhone.includes(cleaned) || cleaned.includes(oPhone));
    }).reduce((acc, o) => acc + (Number(o?.totalAmount) || 0), 0);
  };

  // Helper: Build Unique Customers List for CRM
  const uniqueCustomerPhones = Array.from(
    new Set((orders || []).map(o => o?.phone ? String(o.phone).trim() : '').filter(Boolean))
  );
  const customerList = uniqueCustomerPhones.map(phone => {
    const customerOrders = (orders || []).filter(o => String(o?.phone || '').trim() === phone);
    const lastOrder = customerOrders[0];
    const totalSpent = customerOrders.reduce((acc, o) => acc + (Number(o?.totalAmount) || 0), 0);
    return {
      phone: String(phone || ''),
      name: lastOrder?.customerName || 'সম্মানিত কাস্টমার',
      city: lastOrder?.city || 'ঢাকা',
      ordersCount: customerOrders.length,
      totalSpent,
      lastOrderDate: lastOrder?.createdAt ? formatSafeDate(lastOrder.createdAt) : 'সাম্প্রতিক'
    };
  });

  // Helper to parse order dates safely
  const parseOrderDate = (dateVal: any): Date => {
    if (!dateVal) return new Date();
    if (typeof dateVal === 'object' && dateVal.seconds) {
      return new Date(dateVal.seconds * 1000);
    }
    const parsed = new Date(dateVal);
    if (!isNaN(parsed.getTime())) return parsed;
    return new Date();
  };

  // Date Range Filtered Orders
  const dateFilteredOrders = useMemo(() => {
    const now = new Date();
    const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0, 0);
    const yesterdayStart = new Date(todayStart.getTime() - 24 * 60 * 60 * 1000);
    const yesterdayEnd = new Date(todayStart.getTime() - 1);
    const sevenDaysAgo = new Date(todayStart.getTime() - 6 * 24 * 60 * 60 * 1000);
    const thirtyDaysAgo = new Date(todayStart.getTime() - 29 * 24 * 60 * 60 * 1000);
    const currentMonthStart = new Date(now.getFullYear(), now.getMonth(), 1, 0, 0, 0, 0);
    const lastMonthStart = new Date(now.getFullYear(), now.getMonth() - 1, 1, 0, 0, 0, 0);
    const lastMonthEnd = new Date(now.getFullYear(), now.getMonth(), 0, 23, 59, 59, 999);

    return (orders || []).filter(o => {
      if (!o) return false;
      const orderDate = parseOrderDate(o.createdAt);
      const t = orderDate.getTime();

      if (salesDatePreset === 'today') {
        return t >= todayStart.getTime();
      }
      if (salesDatePreset === 'yesterday') {
        return t >= yesterdayStart.getTime() && t <= yesterdayEnd.getTime();
      }
      if (salesDatePreset === '7days') {
        return t >= sevenDaysAgo.getTime();
      }
      if (salesDatePreset === '30days') {
        return t >= thirtyDaysAgo.getTime();
      }
      if (salesDatePreset === 'this_month') {
        return t >= currentMonthStart.getTime();
      }
      if (salesDatePreset === 'last_month') {
        return t >= lastMonthStart.getTime() && t <= lastMonthEnd.getTime();
      }
      if (salesDatePreset === 'by_month' && salesSelectedMonth) {
        const [year, month] = salesSelectedMonth.split('-').map(Number);
        const mStart = new Date(year, month - 1, 1, 0, 0, 0, 0);
        const mEnd = new Date(year, month, 0, 23, 59, 59, 999);
        return t >= mStart.getTime() && t <= mEnd.getTime();
      }
      if (salesDatePreset === 'custom') {
        if (salesStartDate && salesEndDate) {
          const sDate = new Date(salesStartDate + 'T00:00:00');
          const eDate = new Date(salesEndDate + 'T23:59:59');
          return t >= sDate.getTime() && t <= eDate.getTime();
        } else if (salesStartDate) {
          const sDate = new Date(salesStartDate + 'T00:00:00');
          return t >= sDate.getTime();
        } else if (salesEndDate) {
          const eDate = new Date(salesEndDate + 'T23:59:59');
          return t <= eDate.getTime();
        }
      }
      return true; // 'all'
    });
  }, [orders, salesDatePreset, salesStartDate, salesEndDate, salesSelectedMonth]);

  // STRICT REQUIREMENT: Only orders with status === 'delivered' are counted towards actual revenue!
  const deliveredSales = useMemo(() => {
    return dateFilteredOrders
      .filter(o => o?.status === 'delivered')
      .reduce((acc, o) => acc + (Number(o?.totalAmount) || 0), 0);
  }, [dateFilteredOrders]);

  const allDeliveredSales = useMemo(() => {
    return (orders || [])
      .filter(o => o?.status === 'delivered')
      .reduce((acc, o) => acc + (Number(o?.totalAmount) || 0), 0);
  }, [orders]);

  // Booked / In-transit pipeline value (processing / confirmed / shipped)
  const pipelineSales = useMemo(() => {
    return dateFilteredOrders
      .filter(o => o?.status === 'processing' || o?.status === 'confirmed' || o?.status === 'shipped')
      .reduce((acc, o) => acc + (Number(o?.totalAmount) || 0), 0);
  }, [dateFilteredOrders]);

  // STRICT REQUIREMENT: Return Loss calculation
  const returnOrders = useMemo(() => {
    return dateFilteredOrders.filter(o => o?.status === 'cancelled' || (o?.status as string) === 'returned');
  }, [dateFilteredOrders]);

  const totalReturnCourierLoss = useMemo(() => {
    return returnOrders.reduce((acc, o) => acc + (Number(o?.shippingFee) || 120), 0);
  }, [returnOrders]);

  const totalReturnedGoodsValue = useMemo(() => {
    return returnOrders.reduce((acc, o) => acc + (Number(o?.totalAmount) || 0), 0);
  }, [returnOrders]);

  // Calculated Stats
  const totalSales = deliveredSales; // STRICT: Delivered only
  const totalOrders = dateFilteredOrders.length;
  const pendingOrders = dateFilteredOrders.filter(o => o?.status === 'processing').length;
  const confirmedOrders = dateFilteredOrders.filter(o => o?.status === 'confirmed').length;
  const shippedOrders = dateFilteredOrders.filter(o => o?.status === 'shipped').length;
  const onHoldOrders = dateFilteredOrders.filter(o => o?.status === 'on_hold').length;
  const deliveredOrders = dateFilteredOrders.filter(o => o?.status === 'delivered').length;
  const cancelledOrders = dateFilteredOrders.filter(o => o?.status === 'cancelled').length;

  // Global Order Counts for Order Filter Tabs
  const allTotalOrdersCount = (orders || []).length;
  const allPendingOrdersCount = (orders || []).filter(o => o?.status === 'processing').length;
  const allConfirmedOrdersCount = (orders || []).filter(o => o?.status === 'confirmed').length;
  const allShippedOrdersCount = (orders || []).filter(o => o?.status === 'shipped').length;
  const allOnHoldOrdersCount = (orders || []).filter(o => o?.status === 'on_hold').length;
  const allDeliveredOrdersCount = (orders || []).filter(o => o?.status === 'delivered').length;
  const allCancelledOrdersCount = (orders || []).filter(o => o?.status === 'cancelled').length;

  // Newest products first in Admin so newly added products are at index 0 (top of the list)
  const sortedAdminProducts = useMemo(() => {
    return [...(products || [])].sort((a, b) => {
      const tA = getSafeTimestamp(a.createdAt);
      const tB = getSafeTimestamp(b.createdAt);
      return tB - tA;
    });
  }, [products]);

  // Payment filter counts
  const verifiedPaidOrdersCount = (orders || []).filter(o => o?.paymentStatus === 'VERIFIED_PAID' || o?.paymentStatus === 'PAID').length;
  const pendingPaymentOrdersCount = (orders || []).filter(o => o?.paymentStatus === 'PENDING_VERIFICATION').length;

  // Filtered orders sorted newest first
  const filteredOrders = useMemo(() => {
    return (orders || []).filter(o => {
      if (!o) return false;
      if (orderFilter !== 'all' && o.status !== orderFilter) return false;

      // Payment filter check
      if (paymentFilter === 'paid') {
        const isPaid = o.paymentStatus === 'VERIFIED_PAID' || o.paymentStatus === 'PAID';
        if (!isPaid) return false;
      } else if (paymentFilter === 'pending') {
        if (o.paymentStatus !== 'PENDING_VERIFICATION') return false;
      } else if (paymentFilter === 'cod') {
        const isPaid = o.paymentStatus === 'VERIFIED_PAID' || o.paymentStatus === 'PAID';
        if (isPaid || o.paymentStatus === 'PENDING_VERIFICATION') return false;
      }

      if (orderSearch.trim()) {
        const q = orderSearch.toLowerCase();
        const matchId = String(o.id || '').toLowerCase().includes(q);
        const matchName = String(o.customerName || '').toLowerCase().includes(q);
        const matchPhone = String(o.phone || '').toLowerCase().includes(q);
        const matchSenderPhone = o.paymentSenderPhone ? String(o.paymentSenderPhone).toLowerCase().includes(q) : false;
        const matchReceiver = o.paymentReceiverNumber ? String(o.paymentReceiverNumber).toLowerCase().includes(q) : false;
        const matchTrx = o.trxId ? String(o.trxId).toLowerCase().includes(q) : false;
        return matchId || matchName || matchPhone || matchSenderPhone || matchReceiver || matchTrx;
      }
      return true;
    }).sort((a, b) => {
      const tA = getSafeTimestamp(a.createdAt);
      const tB = getSafeTimestamp(b.createdAt);
      return tB - tA;
    });
  }, [orders, orderFilter, paymentFilter, orderSearch]);

  const sidebarItems = [
    { id: 'dashboard', label: lang === 'bn' ? 'ড্যাশবোর্ড' : 'Dashboard', icon: BarChart3 },
    { id: 'orders', label: lang === 'bn' ? 'অর্ডারসমূহ' : 'Orders', icon: ShoppingBag, badge: orders.length },
    { id: 'fraud', label: lang === 'bn' ? '🛡️ ফ্রড চেকার' : 'Fraud Checker', icon: ShieldAlert, badge: flaggedPhones.length },
    { id: 'products', label: lang === 'bn' ? 'পণ্যসমূহ' : 'Products', icon: Tag, badge: products.length },
    { id: 'categories', label: lang === 'bn' ? 'ক্যাটাগরি' : 'Categories', icon: Layers },
    { id: 'customers', label: lang === 'bn' ? 'কাস্টমার ডাটাবেজ' : 'Customers', icon: Users, badge: customerList.length },
    { id: 'coupons', label: lang === 'bn' ? 'কুপন ও ডিসকাউন্ট' : 'Coupons & Discounts', icon: Tag },
    { id: 'payments', label: lang === 'bn' ? 'পেমেন্ট গেটওয়ে' : 'Payments', icon: DollarSign },
    { id: 'refunds', label: lang === 'bn' ? 'রিফান্ড ও রিটার্ন' : 'Refunds', icon: RotateCcw },
    { id: 'reviews', label: lang === 'bn' ? 'রিভিউ ও রেটিং' : 'Reviews', icon: Star },
    { id: 'stock', label: lang === 'bn' ? 'স্টক ইনভেন্টরি' : 'Stock Management', icon: HardDrive },
    { id: 'reports', label: lang === 'bn' ? 'রিপোর্ট ও অ্যানালিটিক্স' : 'Reports & Analytics', icon: BarChart3 },
    { id: 'sales_analytics', label: lang === 'bn' ? 'সেলস অ্যানালিটিক্স' : 'Sales Analytics', icon: TrendingUp },
    { id: 'website_settings', label: lang === 'bn' ? 'ওয়েবসাইট সেটিংস' : 'Website Settings', icon: Sliders },
    { id: 'appearance', label: lang === 'bn' ? 'অ্যাপিয়ারেন্স ও থিম' : 'Appearance', icon: Palette },
    { id: 'pages', label: lang === 'bn' ? 'পেজসমূহ' : 'Pages', icon: FileText },
    { id: 'blog_posts', label: lang === 'bn' ? 'ব্লগ পোস্ট' : 'Blog Posts', icon: BookOpen },
    { id: 'banners', label: lang === 'bn' ? 'ব্যানার ও স্লাইডার' : 'Banners / Sliders', icon: ImagePlus },
    { id: 'shipping', label: lang === 'bn' ? 'শিপিং ও ডেলিভারি' : 'Shipping', icon: Truck },
    { id: 'tax_settings', label: lang === 'bn' ? 'ট্যাক্স সেটিংস' : 'Tax Settings', icon: DollarSign },
    { id: 'seo_settings', label: lang === 'bn' ? 'এসইও (SEO)' : 'SEO Settings', icon: Globe },
    { id: 'admin_users', label: lang === 'bn' ? 'এডমিন ইউজার্স' : 'Admin Users', icon: Users },
    { id: 'roles_permissions', label: lang === 'bn' ? 'রোল ও পারমিশন' : 'Roles & Permissions', icon: ShieldCheck },
    { id: 'notifications', label: lang === 'bn' ? 'নোটিফিকেশন' : 'Notifications', icon: Bell },
    { id: 'messages', label: lang === 'bn' ? '📞 হেল্পলাইন ও কাস্টমার ইনবক্স' : 'Helpline & Inquiries', icon: PhoneCall, badge: (supportMessages || []).length },
    { id: 'system_settings', label: lang === 'bn' ? 'সিস্টেম সেটিংস' : 'System Settings', icon: SlidersHorizontal },
    { id: 'backup_restore', label: lang === 'bn' ? 'ব্যাকআপ ও রিস্টোর' : 'Backup / Restore', icon: Database },
    { id: 'logout', label: lang === 'bn' ? 'লগআউট' : 'Logout', icon: LogOut },
  ];

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-black/85 backdrop-blur-md flex items-center justify-center p-1 sm:p-2 animate-fade-in">
      <div className="relative w-full max-w-[99vw] h-[98vh] sm:h-[96vh] bg-slate-900 rounded-2xl shadow-2xl overflow-hidden border border-slate-700 my-auto flex flex-col md:flex-row">
        
        {/* SECURITY OTP & PIN GATE IF NOT AUTHENTICATED */}
        {!isAdminAuthenticated ? (
          <div className="w-full h-full bg-stone-50 flex flex-col items-center justify-center p-6 sm:p-12 overflow-y-auto">
            {/* Top Close Button for Auth Screen */}
            <div className="absolute top-4 right-4">
              <button
                onClick={onClose}
                className="p-2 rounded-full hover:bg-stone-200 text-stone-600 transition-colors cursor-pointer"
              >
                <X size={20} />
              </button>
            </div>

            <div className="p-4 bg-amber-100 text-rose-950 rounded-full border-2 border-amber-300 shadow-lg animate-bounce mb-4">
              <ShieldCheck size={48} />
            </div>

            <div className="max-w-md space-y-2 text-center">
              <h4 className="text-xl font-serif font-extrabold text-stone-900">
                {lang === 'bn' ? 'এডমিন সিকিউরিটি লগইন' : 'Admin Security Login'}
              </h4>
              <p className="text-xs text-stone-600 leading-relaxed">
                {lang === 'bn' 
                  ? 'অনুমোদিত অনার (ataurulipur14@gmail.com / 01792765693)-এর জন্য নিরাপদ প্রবেশদ্বার।' 
                  : 'Secure entrance for authorized owner.'}
              </p>

              {/* Toggle Login Method */}
              <div className="flex bg-stone-200/80 p-1 rounded-xl gap-1 text-xs font-bold mt-2">
                <button
                  type="button"
                  onClick={() => {
                    setAdminAuthMode('otp');
                    setAuthError('');
                  }}
                  className={`flex-1 py-1.5 rounded-lg transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                    adminAuthMode === 'otp' ? 'bg-white text-stone-900 shadow-sm' : 'text-stone-600 hover:text-stone-900'
                  }`}
                >
                  <Send size={13} />
                  <span>{lang === 'bn' ? 'জিমেইল ওটিপি' : 'Gmail OTP'}</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setAdminAuthMode('master_pass');
                    setAuthError('');
                  }}
                  className={`flex-1 py-1.5 rounded-lg transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                    adminAuthMode === 'master_pass' ? 'bg-amber-500 text-slate-950 shadow-sm font-extrabold' : 'text-stone-600 hover:text-stone-900'
                  }`}
                >
                  <KeyRound size={13} />
                  <span>{lang === 'bn' ? 'মাস্টার পাসকোড (Netlify)' : 'Master Passcode'}</span>
                </button>
              </div>
            </div>

            <div className="w-full max-w-sm space-y-4 my-2">
              {/* If Netlify / Server Unavailable is detected */}
              {showServerNetlifyHelp && adminAuthMode === 'otp' && (
                <div className="p-3 bg-amber-50 border border-amber-300 rounded-2xl text-left text-xs space-y-2">
                  <div className="flex items-center gap-1.5 font-bold text-amber-950">
                    <AlertTriangle size={14} className="text-amber-700 shrink-0" />
                    <span>Netlify হোস্টিং শনাক্ত হয়েছে</span>
                  </div>
                  <p className="text-stone-700 text-[11px] leading-relaxed">
                    Netlify-তে স্ট্যাটিক ফাইল চলে কিন্তু স্বয়ংক্রিয় Node.js ব্যাকঅ্যান্ড সার্ভিস চলে না। তাই ওটিপির বদলে অনার মাস্টার পাসকোড দিয়ে সরাসরি প্রবেশ করুন।
                  </p>
                  <button
                    type="button"
                    onClick={() => {
                      setAdminAuthMode('master_pass');
                      setAuthError('');
                    }}
                    className="w-full py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-xl font-bold text-xs flex items-center justify-center gap-1 cursor-pointer"
                  >
                    <KeyRound size={14} />
                    <span>🔑 মাস্টার পাসকোড অপশনে যান</span>
                  </button>
                </div>
              )}

              {/* MODE 1: MASTER PASSCODE (NETLIFY & OFFLINE RESILIENT) */}
              {adminAuthMode === 'master_pass' ? (
                <form onSubmit={handleMasterPassLogin} className="space-y-3.5">
                  <div className="p-3 bg-amber-50 rounded-2xl border border-amber-200 text-left text-xs space-y-1">
                    <span className="font-bold text-amber-950 flex items-center gap-1.5">
                      <Lock size={13} className="text-rose-900" />
                      <span>অনুমোদিত অনার অ্যাকাউন্ট:</span>
                    </span>
                    <p className="text-stone-700 text-[11px]">
                      আতাউর রহমান • <strong>ataurulipur14@gmail.com</strong> (01792765693)
                    </p>
                  </div>

                  <div>
                    <label className="block text-left text-[11px] font-bold text-stone-700 mb-1">
                      অনার জিমেইল অথবা ফোন নম্বর:
                    </label>
                    <input
                      type="text"
                      required
                      value={adminAuthInput}
                      onChange={(e) => {
                        setAdminAuthInput(e.target.value);
                        setAuthError('');
                      }}
                      placeholder="ataurulipur14@gmail.com / 01792765693"
                      className="w-full px-4 py-3 bg-stone-50 border border-stone-300 rounded-2xl text-center text-sm font-mono font-bold text-stone-900 focus:outline-none focus:ring-2 focus:ring-amber-500 shadow-inner"
                    />
                  </div>

                  <div>
                    <label className="block text-left text-[11px] font-bold text-stone-700 mb-1">
                      অনার মাস্টার পাসকোড / সিকিউরিটি পিন:
                    </label>
                    <input
                      type="password"
                      required
                      autoFocus
                      value={adminMasterPassInput}
                      onChange={(e) => {
                        setAdminMasterPassInput(e.target.value);
                        setAuthError('');
                      }}
                      placeholder="অনারের ফোন নম্বর বা পাসকোড দিন"
                      className="w-full px-4 py-3 bg-stone-50 border border-stone-300 rounded-2xl text-center text-base font-mono font-black text-rose-950 focus:outline-none focus:ring-2 focus:ring-amber-500 shadow-inner"
                    />
                    <div className="flex justify-between items-center mt-1 px-1">
                      <span className="text-[10px] text-stone-500 font-medium">সহায়তা: অনারের মোবাইল নম্বর (01792765693)</span>
                    </div>
                    {authError && (
                      <p className="text-[11px] font-bold text-red-600 mt-1 text-left">
                        ⚠️ {authError}
                      </p>
                    )}
                  </div>

                  <button
                    type="submit"
                    className="w-full py-3.5 bg-rose-950 hover:bg-rose-900 text-amber-300 font-extrabold text-xs rounded-2xl shadow-xl transition-all flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <Unlock size={16} />
                    <span>{lang === 'bn' ? '🔑 মাস্টার পাসকোড দিয়ে এডমিনে প্রবেশ' : 'Login with Master Passcode'}</span>
                  </button>
                </form>
              ) : (
                /* MODE 2: REAL GMAIL OTP VIA SERVER */
                otpStep === 'request' ? (
                  <form onSubmit={handleRequestOtp} className="space-y-3.5">
                    <div className="p-3 bg-amber-50 rounded-2xl border border-amber-200 text-left text-xs space-y-1">
                      <span className="font-bold text-amber-950 flex items-center gap-1.5">
                        <Lock size={13} className="text-rose-900" />
                        <span>অনুমোদিত অনার অ্যাকাউন্ট:</span>
                      </span>
                      <p className="text-stone-700 text-[11px]">
                        আতাউর রহমান • <strong>ataurulipur14@gmail.com</strong>
                      </p>
                    </div>

                    <div>
                      <label className="block text-left text-[11px] font-bold text-stone-700 mb-1">
                        রেজিস্টার্ড জি-মেইল বা ফোন নম্বর:
                      </label>
                      <input
                        type="text"
                        required
                        value={adminAuthInput}
                        onChange={(e) => {
                          setAdminAuthInput(e.target.value);
                          setAuthError('');
                        }}
                        placeholder="e.g. ataurulipur14@gmail.com"
                        className="w-full px-4 py-3 bg-stone-50 border border-stone-300 rounded-2xl text-center text-sm font-mono font-bold text-stone-900 focus:outline-none focus:ring-2 focus:ring-amber-500 shadow-inner"
                      />
                      {authError && (
                        <p className="text-[11px] font-bold text-red-600 mt-1 text-left">
                          ⚠️ {authError}
                        </p>
                      )}
                    </div>

                    <button
                      type="submit"
                      disabled={isSendingOtp}
                      className="w-full py-3.5 bg-rose-950 hover:bg-rose-900 disabled:bg-stone-400 text-amber-300 font-extrabold text-xs rounded-2xl shadow-xl transition-all flex items-center justify-center gap-2 cursor-pointer"
                    >
                      {isSendingOtp ? (
                        <>
                          <RefreshCw size={16} className="animate-spin" />
                          <span>OTP পাঠানো হচ্ছে...</span>
                        </>
                      ) : (
                        <>
                          <Send size={16} />
                          <span>{lang === 'bn' ? 'জি-মেইলে আসল OTP কোড পাঠান' : 'Send Real OTP to Gmail'}</span>
                        </>
                      )}
                    </button>
                  </form>
                ) : (
                  <form onSubmit={handleVerifyOtp} className="space-y-3.5">
                    {/* Status Banner */}
                    <div className="p-3 bg-emerald-50 border border-emerald-300 rounded-2xl text-left text-xs space-y-1">
                      <div className="font-bold text-emerald-950 flex items-center justify-between">
                        <span>✉️ জি-মেইলে OTP সফলভাবে পাঠানো হয়েছে!</span>
                        <span className="bg-emerald-700 text-white text-[9px] px-2 py-0.5 rounded-full font-mono font-bold">SENT</span>
                      </div>
                      <p className="text-emerald-800 text-[11px] leading-relaxed">
                        আপনার <strong>{adminAuthInput}</strong> ইনবক্স অথবা স্প্যাম ফোল্ডারে রঙিলা রূপ সিকিউরিটি ইমেইল চেক করে ৬-ডিজিটের কোডটি দিন।
                      </p>
                    </div>

                    <div>
                      <label className="block text-left text-[11px] font-bold text-stone-700 mb-1">
                        ৬-ডিজিটের সিকিউরিটি OTP কোড:
                      </label>
                      <input
                        type="text"
                        maxLength={6}
                        required
                        autoFocus
                        value={adminOtpInput}
                        onChange={(e) => {
                          setAdminOtpInput(e.target.value);
                          setAuthError('');
                        }}
                        placeholder="যেমন: 582910"
                        className="w-full px-4 py-3 bg-stone-50 border border-stone-300 rounded-2xl text-center text-xl font-mono font-black tracking-widest text-rose-950 focus:outline-none focus:ring-2 focus:ring-amber-500 shadow-inner"
                      />
                      {authError && (
                        <p className="text-[11px] font-bold text-red-600 mt-1 text-left">
                          ⚠️ {authError}
                        </p>
                      )}
                    </div>

                    <div className="flex gap-2">
                      <button
                        type="button"
                        onClick={() => {
                          setOtpStep('request');
                          setAuthError('');
                        }}
                        className="px-4 py-3 bg-stone-200 hover:bg-stone-300 text-stone-800 font-bold text-xs rounded-2xl cursor-pointer"
                      >
                        পুনরায় পাঠান
                      </button>
                      <button
                        type="submit"
                        disabled={isVerifyingOtp}
                        className="flex-1 py-3.5 bg-rose-950 hover:bg-rose-900 disabled:bg-stone-400 text-amber-300 font-extrabold text-xs rounded-2xl shadow-xl transition-all flex items-center justify-center gap-2 cursor-pointer"
                      >
                        {isVerifyingOtp ? (
                          <>
                            <RefreshCw size={16} className="animate-spin" />
                            <span>যাচাই হচ্ছে...</span>
                          </>
                        ) : (
                          <>
                            <Unlock size={16} />
                            <span>{lang === 'bn' ? 'ভেরিফাই ও এডমিনে প্রবেশ' : 'Verify & Enter'}</span>
                          </>
                        )}
                      </button>
                    </div>
                  </form>
                )
              )}
            </div>

            <div className="pt-4 mt-4 border-t border-stone-200 text-[11px] text-stone-500 font-mono text-center">
              Authorized Owner: <strong className="text-stone-800">Ataur Rahman (ataurulipur14@gmail.com)</strong>
            </div>
          </div>
        ) : (
          <>
            {/* MOBILE SIDEBAR OVERLAY */}
            {isMobileSidebarOpen && (
              <div 
                className="fixed inset-0 bg-black/60 z-40 md:hidden"
                onClick={() => setIsMobileSidebarOpen(false)}
              />
            )}

            {/* LEFT SIDEBAR NAVIGATION DRAWER */}
            <aside className={`
              fixed md:relative inset-y-0 left-0 z-50 md:z-auto w-64 bg-[#111827] text-slate-300 flex flex-col shrink-0 border-r border-slate-800 transition-transform duration-300 ease-in-out h-full
              ${isMobileSidebarOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'}
            `}>
              {/* Sidebar Brand Header */}
              <div className="p-4 bg-[#1a0f1b] border-b border-rose-950/60 flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="p-2 bg-gradient-to-br from-rose-600 to-amber-500 text-white rounded-xl font-black shadow-md">
                    <Lock size={18} />
                  </div>
                  <div>
                    <h3 className="font-serif font-extrabold text-white text-sm tracking-wide">
                      রঙিলা রূপ এডমিন
                    </h3>
                    <span className="text-[10px] text-amber-400 font-mono font-medium block">
                      Owner: {OWNER_PHONE}
                    </span>
                  </div>
                </div>
                <button 
                  onClick={() => setIsMobileSidebarOpen(false)}
                  className="md:hidden text-slate-400 hover:text-white p-1"
                >
                  <X size={18} />
                </button>
              </div>

              {/* Navigation Menu List (27 Menu Items) */}
              <div className="flex-1 overflow-y-auto px-2 py-3 space-y-0.5 custom-scrollbar">
                <div className="px-3 py-1 text-[10px] uppercase tracking-wider font-extrabold text-slate-500">
                  Main Navigation
                </div>
                {sidebarItems.map(item => {
                  const Icon = item.icon;
                  const isActive = activeTab === item.id;
                  return (
                    <button
                      key={item.id}
                      onClick={() => {
                        if (item.id === 'logout') {
                          if (confirm(lang === 'bn' ? 'আপনি কি এডমিন প্যানেল থেকে লগআউট করতে চান?' : 'Are you sure you want to log out?')) {
                            handleAdminLogout();
                          }
                        } else {
                          setActiveTab(item.id as any);
                        }
                        setIsMobileSidebarOpen(false);
                      }}
                      className={`
                        w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-semibold transition-all cursor-pointer group
                        ${isActive 
                          ? 'bg-rose-900 text-amber-200 font-bold shadow-md border border-rose-700/50' 
                          : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'}
                      `}
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <Icon size={16} className={isActive ? 'text-amber-400' : 'text-slate-400 group-hover:text-amber-300'} />
                        <span className="truncate">{item.label}</span>
                      </div>
                      {item.badge !== undefined && item.badge > 0 && (
                        <span className={`px-2 py-0.5 text-[10px] font-mono font-bold rounded-full ${
                          isActive ? 'bg-amber-400 text-rose-950' : 'bg-slate-800 text-amber-300 border border-slate-700'
                        }`}>
                          {item.badge}
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>

              {/* Sidebar Footer */}
              <div className="p-3 bg-[#0d131f] border-t border-slate-800 text-[10px] text-slate-400 flex items-center justify-between shrink-0">
                <div className="flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                  <span className="font-mono font-medium text-slate-300">Live System</span>
                </div>
                <span className="text-slate-500 font-mono">v3.5.0</span>
              </div>
            </aside>

            {/* MAIN RIGHT AREA */}
            <div className="flex-1 flex flex-col min-w-0 bg-slate-100 h-full overflow-hidden">
              {/* Top Header Navigation Bar */}
              <header className="px-4 py-2.5 bg-white border-b border-slate-200 flex items-center justify-between shrink-0 shadow-2xs">
                <div className="flex items-center gap-3">
                  <button
                    onClick={() => setIsMobileSidebarOpen(true)}
                    className="md:hidden p-1.5 text-slate-600 hover:text-slate-900 rounded-lg hover:bg-slate-100 cursor-pointer"
                  >
                    <Menu size={20} />
                  </button>
                  <div>
                    <h2 className="font-serif font-bold text-sm sm:text-base text-slate-900 flex items-center gap-2">
                      <span>{sidebarItems.find(i => i.id === activeTab)?.label || 'Dashboard'}</span>
                    </h2>
                    <span className="text-[10px] text-slate-500 hidden sm:block">
                      Rongila Rup E-commerce Administration & Control Center
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-2 sm:gap-3">
                  {/* Date Filter */}
                  <div className="hidden lg:flex items-center gap-1.5 px-3 py-1 bg-slate-100 rounded-xl border border-slate-200 text-xs font-mono font-semibold text-slate-700">
                    <Calendar size={13} className="text-rose-900" />
                    <span>May 1, 2026 - May 31, 2026</span>
                  </div>

                  {/* Language Switcher */}
                  <button
                    onClick={() => setCurrentLang(currentLang === 'bn' ? 'en' : 'bn')}
                    className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-800 font-extrabold text-[11px] rounded-lg border border-slate-200 transition-colors cursor-pointer flex items-center gap-1"
                  >
                    <Globe size={12} className="text-amber-700" />
                    <span>{currentLang === 'bn' ? 'English' : 'বাংলা'}</span>
                  </button>

                  {/* Notifications Bell */}
                  <button 
                    onClick={() => setActiveTab('notifications')}
                    className="relative p-1.5 text-slate-600 hover:text-rose-900 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                    title="Notifications"
                  >
                    <Bell size={18} />
                    <span className="absolute top-0 right-0 w-2 h-2 rounded-full bg-red-600 ring-2 ring-white" />
                  </button>

                  {/* Admin Profile */}
                  <div className="hidden sm:flex items-center gap-2 pl-2 border-l border-slate-200">
                    <div className="w-7 h-7 rounded-full bg-rose-950 text-amber-300 font-black text-xs flex items-center justify-center border border-amber-400">
                      A
                    </div>
                    <div className="text-left leading-none">
                      <span className="text-xs font-bold text-slate-900 block">Ataur Rahman</span>
                      <span className="text-[9px] text-rose-800 font-bold uppercase">Super Admin</span>
                    </div>
                  </div>

                  {/* Header Logout Button */}
                  <button
                    onClick={() => {
                      if (confirm(lang === 'bn' ? 'আপনি কি এডমিন প্যানেল থেকে লগআউট করতে চান?' : 'Are you sure you want to log out?')) {
                        handleAdminLogout();
                      }
                    }}
                    className="px-2.5 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-900 rounded-xl text-xs font-bold border border-rose-200 transition-colors flex items-center gap-1 cursor-pointer"
                    title="এডমিন লগআউট"
                  >
                    <LogOut size={13} />
                    <span className="hidden sm:inline">লগআউট</span>
                  </button>

                  {/* Source Zip & Drive buttons */}
                  <a
                    href="/api/download-zip"
                    download="rongila-rup-kids-source.zip"
                    className="px-3 py-1.5 bg-gradient-to-r from-amber-500 via-rose-600 to-rose-700 hover:from-amber-400 hover:to-rose-600 text-white rounded-xl font-extrabold text-xs flex items-center gap-1.5 transition-all transform hover:scale-105 active:scale-95 cursor-pointer shadow-md border border-amber-300/40"
                    title="Download Full Source Code ZIP"
                  >
                    <Download size={14} className="animate-bounce" />
                    <span className="font-bold">ZIP ডাউনলোড</span>
                  </a>

                  {onOpenDrive && (
                    <button
                      onClick={onOpenDrive}
                      className="px-2 py-1 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded-lg font-bold text-[11px] flex items-center gap-1 border border-stone-300 cursor-pointer"
                    >
                      <HardDrive size={12} className="text-amber-600" />
                      <span className="hidden sm:inline">Drive</span>
                    </button>
                  )}

                  <button
                    onClick={onClose}
                    className="p-1.5 text-slate-500 hover:text-slate-900 hover:bg-slate-200 rounded-full transition-colors cursor-pointer ml-1"
                    title="Close Admin Panel"
                  >
                    <X size={18} />
                  </button>
                </div>
              </header>

              {/* Quick Metrics Top Strip */}
              <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-5 gap-2 px-4 py-2 bg-[#1a0f1b] text-amber-100 border-b border-rose-900/40 text-xs shrink-0">
                <div className="p-1.5 bg-rose-950/60 rounded-xl border border-rose-800/40">
                  <span className="text-[10px] text-amber-300/80 block font-semibold">Total Revenue</span>
                  <span className="text-xs sm:text-sm font-serif font-bold text-amber-300">৳{totalSales.toLocaleString()}</span>
                </div>
                <div className="p-1.5 bg-rose-950/60 rounded-xl border border-rose-800/40">
                  <span className="text-[10px] text-amber-300/80 block font-semibold">Total Orders</span>
                  <span className="text-xs sm:text-sm font-bold text-white">{totalOrders} <span className="text-[10px] text-amber-200">({pendingOrders} pending)</span></span>
                </div>
                <div className="p-1.5 bg-rose-950/60 rounded-xl border border-rose-800/40">
                  <span className="text-[10px] text-amber-300/80 block font-semibold">Shipped / Delivered</span>
                  <span className="text-xs sm:text-sm font-bold text-emerald-400">{confirmedOrders + shippedOrders} orders</span>
                </div>
                <div className="p-1.5 bg-rose-950/60 rounded-xl border border-rose-800/40">
                  <span className="text-[10px] text-amber-300/80 block font-semibold">Unique Customers</span>
                  <span className="text-xs sm:text-sm font-bold text-amber-300">{customerList.length} buyers</span>
                </div>
                <div className="p-1.5 bg-rose-950/60 rounded-xl border border-rose-800/40 hidden lg:block">
                  <span className="text-[10px] text-amber-300/80 block font-semibold">Active Products</span>
                  <span className="text-xs sm:text-sm font-bold text-white">{products.length} items</span>
                </div>
              </div>

              {/* Fast Direct Access Bar for Primary Tabs & Manual Order Creation */}
              <div className="bg-white px-4 py-2.5 border-b border-stone-200 flex items-center justify-between gap-2 overflow-x-auto shadow-xs shrink-0">
                <div className="flex items-center gap-1.5 sm:gap-2">
                  <button
                    onClick={() => setActiveTab('orders')}
                    className={`px-3 py-1.5 rounded-xl font-bold text-xs flex items-center gap-1.5 transition-all cursor-pointer whitespace-nowrap ${
                      activeTab === 'orders'
                        ? 'bg-rose-950 text-amber-300 shadow-xs'
                        : 'bg-stone-100 hover:bg-stone-200 text-stone-800'
                    }`}
                  >
                    <ShoppingBag size={14} />
                    <span>অর্ডারসমূহ</span>
                    <span className="px-1.5 py-0.2 text-[10px] font-mono rounded-full bg-amber-400/20 text-amber-900 border border-amber-400/40">
                      {orders.length}
                    </span>
                    {pendingPaymentOrdersCount > 0 && (
                      <span className="px-1.5 py-0.2 text-[10px] font-bold rounded-full bg-red-600 text-white animate-pulse" title="টাকা যাচাইকরণ বাকি">
                        {pendingPaymentOrdersCount} বাকি
                      </span>
                    )}
                  </button>

                  <button
                    onClick={() => setActiveTab('customers')}
                    className={`px-3 py-1.5 rounded-xl font-bold text-xs flex items-center gap-1.5 transition-all cursor-pointer whitespace-nowrap ${
                      activeTab === 'customers'
                        ? 'bg-rose-950 text-amber-300 shadow-xs'
                        : 'bg-stone-100 hover:bg-stone-200 text-stone-800'
                    }`}
                  >
                    <Users size={14} />
                    <span>কাস্টমার ডাটাবেজ</span>
                    <span className="px-1.5 py-0.2 text-[10px] font-mono rounded-full bg-stone-200 text-stone-700">
                      {customerList.length}
                    </span>
                  </button>

                  <button
                    onClick={() => setActiveTab('messages')}
                    className={`px-3 py-1.5 rounded-xl font-bold text-xs flex items-center gap-1.5 transition-all cursor-pointer whitespace-nowrap ${
                      activeTab === 'messages' || (activeTab as string) === 'helpline'
                        ? 'bg-rose-950 text-amber-300 shadow-xs'
                        : 'bg-stone-100 hover:bg-stone-200 text-stone-800'
                    }`}
                  >
                    <MessageSquare size={14} />
                    <span>হেল্পলাইন ও ইনবক্স</span>
                    <span className="px-1.5 py-0.2 text-[10px] font-mono rounded-full bg-stone-200 text-stone-700">
                      {supportMessages.length}
                    </span>
                  </button>

                  <button
                    onClick={() => setActiveTab('products')}
                    className={`px-3 py-1.5 rounded-xl font-bold text-xs flex items-center gap-1.5 transition-all cursor-pointer whitespace-nowrap ${
                      activeTab === 'products'
                        ? 'bg-rose-950 text-amber-300 shadow-xs'
                        : 'bg-stone-100 hover:bg-stone-200 text-stone-800'
                    }`}
                  >
                    <Tag size={14} />
                    <span>পণ্যসমূহ</span>
                    <span className="px-1.5 py-0.2 text-[10px] font-mono rounded-full bg-stone-200 text-stone-700">
                      {products.length}
                    </span>
                  </button>
                </div>

                <button
                  onClick={() => setIsCreateOrderOpen(true)}
                  className="px-3.5 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl font-bold text-xs flex items-center gap-1.5 shadow-xs transition-transform active:scale-95 cursor-pointer whitespace-nowrap"
                >
                  <Plus size={14} />
                  <span>➕ নতুন কাস্টমার অর্ডার</span>
                </button>
              </div>

              {/* Main Tab Content Body Container */}
              <div className="p-4 sm:p-6 overflow-y-auto flex-1 bg-stone-100">
                <AdminErrorBoundary tabKey={activeTab} lang={lang} onResetTab={() => setActiveTab('dashboard')}>

              {/* MODULE 1: DASHBOARD & ANALYTICS */}
              {activeTab === 'dashboard' && (
                <div className="space-y-6 max-w-7xl mx-auto text-xs animate-fade-in">
                  
                  {/* Top Header Banner & Custom Date Range Filter */}
                  <div className="bg-gradient-to-r from-rose-950 via-rose-900 to-amber-950 text-white p-5 rounded-3xl shadow-md border border-rose-800 space-y-4">
                    <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
                      <div>
                        <h3 className="font-serif font-extrabold text-lg text-amber-300 flex items-center gap-2">
                          <span>রঙিলা রূপ এডমিন কন্ট্রোল ও সেলস ড্যাশবোর্ড</span>
                          <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-400 text-rose-950 font-bold font-mono">LIVE</span>
                        </h3>
                        <p className="text-xs text-rose-200/90">
                          {lang === 'bn' ? 'অর্ডার, সঠিক ডেলিভারি বিক্রয় হিসাব, রিটার্ন লস ও ইনভেন্টরি ট্র্যাকিং' : 'Real-time orders, delivered sales accounting, return loss and inventory'}
                        </p>
                      </div>

                      <div className="flex items-center gap-2 flex-wrap">
                        {/* Courier Live Sync */}
                        <button
                          type="button"
                          onClick={() => handleSyncCourierStatus(true)}
                          disabled={isSyncingCourier}
                          className="px-3.5 py-1.5 bg-purple-700 hover:bg-purple-600 text-white font-extrabold text-xs rounded-xl shadow-xs flex items-center gap-1.5 transition-transform active:scale-95 cursor-pointer whitespace-nowrap disabled:opacity-50"
                          title="স্টিডফাস্ট কুরিয়ারের সাথে লাইভ ডেলিভারি স্ট্যাটাস চেক করুন"
                        >
                          <RefreshCw size={13} className={isSyncingCourier ? 'animate-spin' : ''} />
                          <span>{isSyncingCourier ? 'সিঙ্ক হচ্ছে...' : '🔄 কুরিয়ার ডেলিভারি সিঙ্ক'}</span>
                        </button>

                        {/* Clear History & Reset Dashboard Button */}
                        <button
                          type="button"
                          onClick={() => setIsClearHistoryModalOpen(true)}
                          className="px-3.5 py-1.5 bg-rose-800/80 hover:bg-rose-700 text-white font-extrabold text-xs rounded-xl shadow-xs flex items-center gap-1.5 transition-transform active:scale-95 cursor-pointer whitespace-nowrap border border-rose-600"
                          title="ড্যাশবোর্ড ও পূর্বের অর্ডার হিস্ট্রি মুছে ফেলে নতুনভাবে শুরু করুন"
                        >
                          <Trash2 size={13} />
                          <span>{lang === 'bn' ? '🗑️ হিস্ট্রি ক্লিয়ার' : 'Clear History'}</span>
                        </button>

                        {/* Jump to Detailed Sales Analytics Tab Button */}
                        <button
                          onClick={() => setActiveTab('sales_analytics')}
                          className="px-3.5 py-1.5 bg-amber-400 hover:bg-amber-300 text-rose-950 font-extrabold text-xs rounded-xl shadow-xs flex items-center gap-1.5 transition-transform active:scale-95 cursor-pointer whitespace-nowrap"
                        >
                          <TrendingUp size={14} />
                          <span>{lang === 'bn' ? '📊 সেলস অ্যানালিটিক্স' : 'Analytics'}</span>
                        </button>
                      </div>
                    </div>

                    {/* Interactive Custom Date Range Toolbar */}
                    <div className="p-3 bg-black/40 rounded-2xl border border-white/10 space-y-2.5">
                      <div className="flex items-center justify-between flex-wrap gap-2">
                        <span className="text-xs font-bold text-amber-300 flex items-center gap-1.5">
                          <Calendar size={14} className="text-amber-400" />
                          <span>{lang === 'bn' ? 'তারিখ ও মাস ফিল্টার করে সেলস দেখুন:' : 'Filter Sales by Date / Month:'}</span>
                        </span>

                        {/* Quick Presets */}
                        <div className="flex items-center gap-1.5 flex-wrap">
                          {[
                            { id: 'all', label: 'সকল সময়' },
                            { id: 'today', label: 'আজকে' },
                            { id: 'yesterday', label: 'গতকাল' },
                            { id: '7days', label: 'গত ৭ দিন' },
                            { id: '30days', label: 'গত ৩০ দিন' },
                            { id: 'this_month', label: 'চলতি মাস' },
                            { id: 'last_month', label: 'গত মাস' },
                            { id: 'by_month', label: 'নির্দিষ্ট মাস' },
                            { id: 'custom', label: 'কাস্টম তারিখ' }
                          ].map((p) => (
                            <button
                              key={p.id}
                              onClick={() => setSalesDatePreset(p.id as any)}
                              className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all cursor-pointer ${
                                salesDatePreset === p.id
                                  ? 'bg-amber-400 text-rose-950 shadow-xs'
                                  : 'bg-white/10 hover:bg-white/20 text-rose-100'
                              }`}
                            >
                              {p.label}
                            </button>
                          ))}
                        </div>
                      </div>

                      {/* Custom Range or Month Inputs */}
                      {salesDatePreset === 'by_month' && (
                        <div className="flex items-center gap-2 pt-1 border-t border-white/10">
                          <label className="text-xs text-stone-300 font-bold whitespace-nowrap">মাস সিলেক্ট করুন:</label>
                          <input
                            type="month"
                            value={salesSelectedMonth}
                            onChange={(e) => setSalesSelectedMonth(e.target.value)}
                            className="px-3 py-1 bg-white text-stone-900 rounded-lg text-xs font-bold font-mono focus:outline-none focus:ring-2 focus:ring-amber-400"
                          />
                          <span className="text-[11px] text-amber-200">
                            নির্বাচিত মাস: <strong>{salesSelectedMonth}</strong>
                          </span>
                        </div>
                      )}

                      {salesDatePreset === 'custom' && (
                        <div className="flex items-center gap-2 pt-1 border-t border-white/10 flex-wrap">
                          <span className="text-xs text-stone-300 font-bold whitespace-nowrap">শুরুর তারিখ:</span>
                          <input
                            type="date"
                            value={salesStartDate}
                            onChange={(e) => setSalesStartDate(e.target.value)}
                            className="px-2.5 py-1 bg-white text-stone-900 rounded-lg text-xs font-bold font-mono focus:outline-none focus:ring-2 focus:ring-amber-400"
                          />
                          <span className="text-xs text-stone-300 font-bold whitespace-nowrap">শেষের তারিখ:</span>
                          <input
                            type="date"
                            value={salesEndDate}
                            onChange={(e) => setSalesEndDate(e.target.value)}
                            className="px-2.5 py-1 bg-white text-stone-900 rounded-lg text-xs font-bold font-mono focus:outline-none focus:ring-2 focus:ring-amber-400"
                          />
                          {(salesStartDate || salesEndDate) && (
                            <button
                              onClick={() => {
                                setSalesStartDate('');
                                setSalesEndDate('');
                              }}
                              className="text-[11px] text-amber-300 underline hover:text-white cursor-pointer ml-1"
                            >
                              রিসেট
                            </button>
                          )}
                        </div>
                      )}
                    </div>
                  </div>

                  {/* 5 Top Stat Cards with Delivered-Only Revenue & Return Loss */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
                    {/* Stat 1: Total Orders in Range */}
                    <div className="p-4 bg-white rounded-3xl border border-stone-200 shadow-xs space-y-2 flex flex-col justify-between">
                      <div className="flex items-center justify-between">
                        <span className="text-[11px] font-bold text-stone-500 uppercase tracking-wide">
                          {lang === 'bn' ? 'মোট অর্ডার' : 'Total Orders'}
                        </span>
                        <div className="w-9 h-9 rounded-full bg-pink-100 text-pink-600 flex items-center justify-center font-bold">
                          <ShoppingBag size={18} />
                        </div>
                      </div>
                      <div>
                        <div className="text-2xl font-serif font-extrabold text-stone-900">
                          {totalOrders.toLocaleString()} <span className="text-xs font-normal text-stone-500">টি</span>
                        </div>
                        <p className="text-[10px] text-stone-500 font-medium mt-0.5">
                          ডেলিভারি সম্পন্ন: <strong className="text-emerald-700 font-bold">{deliveredOrders} টি</strong>
                        </p>
                      </div>
                    </div>

                    {/* Stat 2: Delivered Sales Only (STRICT REQUIREMENT) */}
                    <div className="p-4 bg-gradient-to-br from-emerald-50 to-white rounded-3xl border border-emerald-200 shadow-xs space-y-2 flex flex-col justify-between">
                      <div className="flex items-center justify-between">
                        <span className="text-[11px] font-bold text-emerald-800 uppercase tracking-wide">
                          {lang === 'bn' ? 'সম্পন্ন ডেলিভারি বিক্রয়' : 'Delivered Sales'}
                        </span>
                        <div className="w-9 h-9 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold">
                          <DollarSign size={18} />
                        </div>
                      </div>
                      <div>
                        <div className="text-2xl font-serif font-extrabold text-emerald-950">
                          ৳ {totalSales.toLocaleString()}
                        </div>
                        <p className="text-[10px] text-emerald-700 font-bold flex items-center gap-1 mt-0.5">
                          <CheckCircle2 size={12} />
                          <span>শুধুমাত্র সফল ডেলিভারির টাকা</span>
                        </p>
                        <p className="text-[9px] text-stone-500 mt-0.5">
                          কুরিয়ার/প্রসেসিং আছে: ৳{pipelineSales.toLocaleString()}
                        </p>
                      </div>
                    </div>

                    {/* Stat 3: Return & Courier Loss (STRICT REQUIREMENT) */}
                    <div className="p-4 bg-gradient-to-br from-red-50 to-white rounded-3xl border border-red-200 shadow-xs space-y-2 flex flex-col justify-between">
                      <div className="flex items-center justify-between">
                        <span className="text-[11px] font-bold text-red-800 uppercase tracking-wide">
                          {lang === 'bn' ? 'রিটার্ন ও কুরিয়ার লস' : 'Return Loss'}
                        </span>
                        <div className="w-9 h-9 rounded-full bg-red-100 text-red-600 flex items-center justify-center font-bold">
                          <RotateCcw size={18} />
                        </div>
                      </div>
                      <div>
                        <div className="text-2xl font-serif font-extrabold text-red-900">
                          ৳ {totalReturnCourierLoss.toLocaleString()}
                        </div>
                        <p className="text-[10px] text-red-700 font-bold flex items-center gap-1 mt-0.5">
                          <AlertTriangle size={12} />
                          <span>{returnOrders.length} টি রিটার্ন অর্ডারের কুরিয়ার লস</span>
                        </p>
                        <p className="text-[9px] text-stone-500 mt-0.5">
                          বাতিল পণ্যের মূল্য: ৳{totalReturnedGoodsValue.toLocaleString()}
                        </p>
                      </div>
                    </div>

                    {/* Stat 4: Delivery Success Rate */}
                    <div className="p-4 bg-white rounded-3xl border border-stone-200 shadow-xs space-y-2 flex flex-col justify-between">
                      <div className="flex items-center justify-between">
                        <span className="text-[11px] font-bold text-stone-500 uppercase tracking-wide">
                          {lang === 'bn' ? 'সফল ডেলিভারি রেট' : 'Delivery Rate'}
                        </span>
                        <div className="w-9 h-9 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center font-bold">
                          <Truck size={18} />
                        </div>
                      </div>
                      <div>
                        <div className="text-2xl font-serif font-extrabold text-stone-900">
                          {totalOrders > 0 ? Math.round((deliveredOrders / totalOrders) * 100) : 0}%
                        </div>
                        <p className="text-[10px] text-blue-600 font-bold mt-0.5">
                          {deliveredOrders} টি ডেলিভারি সম্পন্ন
                        </p>
                      </div>
                    </div>

                    {/* Stat 5: In-Transit Pipeline Orders */}
                    <div className="p-4 bg-white rounded-3xl border border-stone-200 shadow-xs space-y-2 flex flex-col justify-between sm:col-span-2 lg:col-span-1">
                      <div className="flex items-center justify-between">
                        <span className="text-[11px] font-bold text-stone-500 uppercase tracking-wide">
                          {lang === 'bn' ? 'কুরিয়ার ও প্রসেসিং' : 'In Transit / Pending'}
                        </span>
                        <div className="w-9 h-9 rounded-full bg-amber-100 text-amber-600 flex items-center justify-center font-bold">
                          <Clock size={18} />
                        </div>
                      </div>
                      <div>
                        <div className="text-2xl font-serif font-extrabold text-stone-900">
                          {pendingOrders + confirmedOrders + shippedOrders} <span className="text-xs font-normal text-stone-500">টি</span>
                        </div>
                        <p className="text-[10px] text-amber-700 font-bold mt-0.5">
                          সম্ভাব্য আয়: ৳{pipelineSales.toLocaleString()}
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Main Row 1: Sales Overview Chart, Order Status Donut Chart, Top Categories */}
                  <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
                    
                    {/* Sales Overview Line Curve SVG Chart */}
                    <div className="lg:col-span-6 p-5 bg-white rounded-3xl border border-stone-200 shadow-xs space-y-3">
                      <div className="flex items-center justify-between border-b border-stone-100 pb-2">
                        <div>
                          <h4 className="font-serif font-bold text-stone-900 text-sm flex items-center gap-1.5">
                            <TrendingUp size={16} className="text-rose-900" />
                            <span>Sales Overview</span>
                          </h4>
                          <p className="text-[10px] text-stone-500">Monthly revenue comparison</p>
                        </div>
                        <div className="flex items-center gap-3 text-[10px] font-bold">
                          <span className="flex items-center gap-1 text-pink-600">
                            <span className="w-2.5 h-2.5 rounded-full bg-pink-500 inline-block" />
                            This Month
                          </span>
                          <span className="flex items-center gap-1 text-stone-400">
                            <span className="w-2.5 h-2.5 rounded-full bg-stone-300 inline-block" />
                            Last Month
                          </span>
                        </div>
                      </div>

                      {/* SVG Line Chart */}
                      <div className="relative pt-2">
                        <svg className="w-full h-44 overflow-visible" viewBox="0 0 500 160">
                          {/* Y-Axis Grid Lines */}
                          <line x1="40" y1="20" x2="490" y2="20" stroke="#f1f5f9" strokeDasharray="4 4" />
                          <line x1="40" y1="50" x2="490" y2="50" stroke="#f1f5f9" strokeDasharray="4 4" />
                          <line x1="40" y1="80" x2="490" y2="80" stroke="#f1f5f9" strokeDasharray="4 4" />
                          <line x1="40" y1="110" x2="490" y2="110" stroke="#f1f5f9" strokeDasharray="4 4" />
                          <line x1="40" y1="140" x2="490" y2="140" stroke="#cbd5e1" />

                          {/* Y-Axis Labels */}
                          <text x="32" y="24" textAnchor="end" fill="#94a3b8" fontSize="10">50K</text>
                          <text x="32" y="54" textAnchor="end" fill="#94a3b8" fontSize="10">40K</text>
                          <text x="32" y="84" textAnchor="end" fill="#94a3b8" fontSize="10">30K</text>
                          <text x="32" y="114" textAnchor="end" fill="#94a3b8" fontSize="10">20K</text>
                          <text x="32" y="144" textAnchor="end" fill="#94a3b8" fontSize="10">0</text>

                          {/* Last Month Dashed Line */}
                          <path
                            d="M 50 120 Q 120 110, 180 90 T 320 85 T 480 60"
                            fill="none"
                            stroke="#cbd5e1"
                            strokeWidth="2.5"
                            strokeDasharray="5 5"
                          />

                          {/* This Month Pink Solid Curve */}
                          <path
                            d="M 50 130 Q 120 100, 180 65 T 320 40 T 480 25"
                            fill="none"
                            stroke="#ec4899"
                            strokeWidth="3.5"
                          />

                          {/* Pink Curve Area Fill Gradient */}
                          <path
                            d="M 50 130 Q 120 100, 180 65 T 320 40 T 480 25 L 480 140 L 50 140 Z"
                            fill="rgba(236, 72, 153, 0.08)"
                          />

                          {/* Active Points */}
                          <circle cx="180" cy="65" r="4" fill="#ec4899" stroke="#ffffff" strokeWidth="2" />
                          <circle cx="320" cy="40" r="4" fill="#ec4899" stroke="#ffffff" strokeWidth="2" />
                          <circle cx="480" cy="25" r="5" fill="#ec4899" stroke="#ffffff" strokeWidth="2" />

                          {/* X-Axis Labels */}
                          <text x="50" y="156" textAnchor="middle" fill="#64748b" fontSize="10">May 1</text>
                          <text x="136" y="156" textAnchor="middle" fill="#64748b" fontSize="10">May 7</text>
                          <text x="222" y="156" textAnchor="middle" fill="#64748b" fontSize="10">May 13</text>
                          <text x="308" y="156" textAnchor="middle" fill="#64748b" fontSize="10">May 19</text>
                          <text x="394" y="156" textAnchor="middle" fill="#64748b" fontSize="10">May 25</text>
                          <text x="480" y="156" textAnchor="middle" fill="#64748b" fontSize="10">May 31</text>
                        </svg>
                      </div>
                    </div>

                    {/* Order Status Donut Chart */}
                    <div className="lg:col-span-3 p-5 bg-white rounded-3xl border border-stone-200 shadow-xs space-y-3">
                      <div className="border-b border-stone-100 pb-2">
                        <h4 className="font-serif font-bold text-stone-900 text-sm">Order Status</h4>
                        <p className="text-[10px] text-stone-500">Breakdown of order fulfillment</p>
                      </div>

                      <div className="flex flex-col items-center justify-center py-1">
                        <div className="relative w-28 h-28 flex items-center justify-center">
                          <svg className="w-full h-full transform -rotate-90" viewBox="0 0 36 36">
                            <path
                              d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                              fill="none"
                              stroke="#e2e8f0"
                              strokeWidth="3.8"
                            />
                            {/* Processing 38.6% */}
                            <path
                              d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                              fill="none"
                              stroke="#3b82f6"
                              strokeWidth="3.8"
                              strokeDasharray="38.6, 100"
                            />
                            {/* Shipped 28.5% */}
                            <path
                              d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                              fill="none"
                              stroke="#eab308"
                              strokeWidth="3.8"
                              strokeDasharray="28.5, 100"
                              strokeDashoffset="-38.6"
                            />
                            {/* Pending 18.8% */}
                            <path
                              d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                              fill="none"
                              stroke="#ef4444"
                              strokeWidth="3.8"
                              strokeDasharray="18.8, 100"
                              strokeDashoffset="-67.1"
                            />
                            {/* Delivered 14.0% */}
                            <path
                              d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                              fill="none"
                              stroke="#10b981"
                              strokeWidth="3.8"
                              strokeDasharray="14, 100"
                              strokeDashoffset="-85.9"
                            />
                          </svg>
                          <div className="absolute text-center">
                            <span className="text-base font-serif font-extrabold text-stone-900 block leading-none">{totalOrders}</span>
                            <span className="text-[9px] text-stone-500 uppercase font-bold">Total</span>
                          </div>
                        </div>
                      </div>

                      <div className="space-y-1.5 text-[11px]">
                        <div className="flex items-center justify-between">
                          <span className="flex items-center gap-1.5 text-stone-700">
                            <span className="w-2.5 h-2.5 rounded-full bg-red-500" />
                            Pending
                          </span>
                          <span className="font-bold font-mono">235 (18.8%)</span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="flex items-center gap-1.5 text-stone-700">
                            <span className="w-2.5 h-2.5 rounded-full bg-blue-500" />
                            Processing
                          </span>
                          <span className="font-bold font-mono">482 (38.6%)</span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="flex items-center gap-1.5 text-stone-700">
                            <span className="w-2.5 h-2.5 rounded-full bg-yellow-500" />
                            Shipped
                          </span>
                          <span className="font-bold font-mono">356 (28.5%)</span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="flex items-center gap-1.5 text-stone-700">
                            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
                            Delivered
                          </span>
                          <span className="font-bold font-mono">175 (14.0%)</span>
                        </div>
                      </div>
                    </div>

                    {/* Top Selling Categories Progress Bars */}
                    <div className="lg:col-span-3 p-5 bg-white rounded-3xl border border-stone-200 shadow-xs space-y-3">
                      <div className="border-b border-stone-100 pb-2">
                        <h4 className="font-serif font-bold text-stone-900 text-sm">Top Selling Categories</h4>
                        <p className="text-[10px] text-stone-500">Popular product segments</p>
                      </div>

                      <div className="space-y-3 pt-1">
                        <div>
                          <div className="flex justify-between text-[11px] font-bold mb-1">
                            <span className="text-stone-800">Baby Dress</span>
                            <span className="text-pink-600 font-mono">35%</span>
                          </div>
                          <div className="w-full bg-stone-100 h-2 rounded-full overflow-hidden">
                            <div className="bg-pink-500 h-full rounded-full w-[35%]" />
                          </div>
                        </div>

                        <div>
                          <div className="flex justify-between text-[11px] font-bold mb-1">
                            <span className="text-stone-800">Baby Set</span>
                            <span className="text-amber-600 font-mono">28%</span>
                          </div>
                          <div className="w-full bg-stone-100 h-2 rounded-full overflow-hidden">
                            <div className="bg-amber-500 h-full rounded-full w-[28%]" />
                          </div>
                        </div>

                        <div>
                          <div className="flex justify-between text-[11px] font-bold mb-1">
                            <span className="text-stone-800">Frock</span>
                            <span className="text-purple-600 font-mono">20%</span>
                          </div>
                          <div className="w-full bg-stone-100 h-2 rounded-full overflow-hidden">
                            <div className="bg-purple-500 h-full rounded-full w-[20%]" />
                          </div>
                        </div>

                        <div>
                          <div className="flex justify-between text-[11px] font-bold mb-1">
                            <span className="text-stone-800">Accessories</span>
                            <span className="text-blue-600 font-mono">12%</span>
                          </div>
                          <div className="w-full bg-stone-100 h-2 rounded-full overflow-hidden">
                            <div className="bg-blue-500 h-full rounded-full w-[12%]" />
                          </div>
                        </div>

                        <div>
                          <div className="flex justify-between text-[11px] font-bold mb-1">
                            <span className="text-stone-800">Others</span>
                            <span className="text-stone-500 font-mono">5%</span>
                          </div>
                          <div className="w-full bg-stone-100 h-2 rounded-full overflow-hidden">
                            <div className="bg-stone-400 h-full rounded-full w-[5%]" />
                          </div>
                        </div>
                      </div>
                    </div>

                  </div>

                  {/* Main Row 2: Recent Orders Table, Low Stock Products, Quick Actions */}
                  <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
                    
                    {/* Recent Orders Table */}
                    <div className="lg:col-span-6 p-5 bg-white rounded-3xl border border-stone-200 shadow-xs space-y-3">
                      <div className="flex items-center justify-between border-b border-stone-100 pb-2">
                        <div>
                          <h4 className="font-serif font-bold text-stone-900 text-sm">Recent Orders</h4>
                          <p className="text-[10px] text-stone-500">Latest customer transactions</p>
                        </div>
                        <button
                          onClick={() => setActiveTab('orders')}
                          className="px-3 py-1 bg-pink-500 hover:bg-pink-600 text-white font-extrabold text-[10px] rounded-lg shadow-2xs transition-colors cursor-pointer"
                        >
                          View All Orders
                        </button>
                      </div>

                      <div className="overflow-x-auto">
                        <table className="w-full text-left text-[11px] border-collapse">
                          <thead>
                            <tr className="border-b border-stone-200 text-stone-400 uppercase tracking-wider font-bold">
                              <th className="pb-2">Order ID</th>
                              <th className="pb-2">Customer</th>
                              <th className="pb-2">Date</th>
                              <th className="pb-2">Amount</th>
                              <th className="pb-2">Payment</th>
                              <th className="pb-2">Status</th>
                              <th className="pb-2 text-right">Action</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-stone-100">
                            {[
                              { id: '#RR1001', name: 'Jannatul Ferdous', date: 'May 31, 2024', amount: '৳ 2,350', pay: 'bKash', status: 'Delivered', color: 'bg-emerald-100 text-emerald-800' },
                              { id: '#RR1002', name: 'সিগ্ধা রানী', date: 'May 31, 2024', amount: '৳ 1,850', pay: 'Nagad', status: 'Processing', color: 'bg-blue-100 text-blue-800' },
                              { id: '#RR1003', name: 'Sumaiya Akter', date: 'May 30, 2024', amount: '৳ 3,250', pay: 'COD', status: 'Shipped', color: 'bg-yellow-100 text-yellow-800' },
                              { id: '#RR1004', name: 'Rokibul Hasan', date: 'May 30, 2024', amount: '৳ 2,150', pay: 'bKash', status: 'Pending', color: 'bg-red-100 text-red-800' },
                              { id: '#RR1005', name: 'Nusrat Jahan', date: 'May 29, 2024', amount: '৳ 1,650', pay: 'Rocket', status: 'Delivered', color: 'bg-emerald-100 text-emerald-800' },
                            ].map((row, i) => (
                              <tr key={i} className="hover:bg-stone-50/80 transition-colors">
                                <td className="py-2.5 font-mono font-bold text-rose-950">{row.id}</td>
                                <td className="py-2.5 font-bold text-stone-900">{row.name}</td>
                                <td className="py-2.5 text-stone-500 text-[10px]">{row.date}</td>
                                <td className="py-2.5 font-bold text-stone-900">{row.amount}</td>
                                <td className="py-2.5 text-stone-600">{row.pay}</td>
                                <td className="py-2.5">
                                  <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${row.color}`}>
                                    {row.status}
                                  </span>
                                </td>
                                <td className="py-2.5 text-right">
                                  <button
                                    onClick={() => setActiveTab('orders')}
                                    className="px-2 py-0.5 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded font-bold text-[10px] cursor-pointer"
                                  >
                                    View
                                  </button>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>

                    {/* Low Stock Products List */}
                    <div className="lg:col-span-3 p-5 bg-white rounded-3xl border border-stone-200 shadow-xs space-y-3">
                      <div className="flex items-center justify-between border-b border-stone-100 pb-2">
                        <div>
                          <h4 className="font-serif font-bold text-stone-900 text-sm">Low Stock Products</h4>
                          <p className="text-[10px] text-stone-500">Items needing restocking</p>
                        </div>
                        <button
                          onClick={() => setActiveTab('products')}
                          className="px-2.5 py-1 bg-stone-100 hover:bg-stone-200 text-stone-800 font-bold text-[10px] rounded-lg transition-colors cursor-pointer"
                        >
                          View All
                        </button>
                      </div>

                      <div className="space-y-2 pt-1">
                        {[
                          { name: 'Baby Frock (Pink)', stock: 5 },
                          { name: 'Baby Dress Set', stock: 3 },
                          { name: 'Girl Party Dress', stock: 7 },
                          { name: 'Baby Shoes', stock: 2 },
                          { name: 'Hair Band Set', stock: 4 },
                        ].map((p, i) => (
                          <div key={i} className="p-2.5 bg-stone-50 rounded-2xl border border-stone-200 flex items-center justify-between text-xs">
                            <div>
                              <h5 className="font-bold text-stone-900">{p.name}</h5>
                              <span className="text-[10px] text-stone-500">Stock: <strong className="text-red-600 font-mono">{p.stock} pcs</strong></span>
                            </div>
                            <span className="px-2 py-0.5 bg-red-100 text-red-800 text-[9px] font-extrabold rounded-full">
                              Low Stock
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Quick Actions Buttons */}
                    <div className="lg:col-span-3 p-5 bg-white rounded-3xl border border-stone-200 shadow-xs space-y-3">
                      <div className="border-b border-stone-100 pb-2">
                        <h4 className="font-serif font-bold text-stone-900 text-sm">Quick Actions</h4>
                        <p className="text-[10px] text-stone-500">Frequent store operations</p>
                      </div>

                      <div className="grid grid-cols-2 gap-2 pt-1">
                        {[
                          { label: 'Add New Product', icon: PackagePlus, tab: 'add_product', color: 'bg-pink-50 hover:bg-pink-100 text-pink-900 border-pink-200' },
                          { label: 'Add Category', icon: Plus, tab: 'categories', color: 'bg-blue-50 hover:bg-blue-100 text-blue-900 border-blue-200' },
                          { label: 'Manage Orders', icon: ShoppingBag, tab: 'orders', color: 'bg-emerald-50 hover:bg-emerald-100 text-emerald-900 border-emerald-200' },
                          { label: 'Add Coupon', icon: Tag, tab: 'coupons', color: 'bg-purple-50 hover:bg-purple-100 text-purple-900 border-purple-200' },
                          { label: 'Manage Customers', icon: Users, tab: 'customers', color: 'bg-amber-50 hover:bg-amber-100 text-amber-900 border-amber-200' },
                          { label: 'Website Settings', icon: Globe, tab: 'website_settings', color: 'bg-indigo-50 hover:bg-indigo-100 text-indigo-900 border-indigo-200' },
                          { label: 'Add Banner', icon: ImagePlus, tab: 'banners', color: 'bg-rose-50 hover:bg-rose-100 text-rose-900 border-rose-200' },
                          { label: 'View Reports', icon: BarChart3, tab: 'reports', color: 'bg-teal-50 hover:bg-teal-100 text-teal-900 border-teal-200' },
                        ].map((btn, i) => {
                          const IconComp = btn.icon;
                          return (
                            <button
                              key={i}
                              onClick={() => setActiveTab(btn.tab as any)}
                              className={`p-3 rounded-2xl border ${btn.color} font-bold text-[11px] flex flex-col items-center text-center justify-center gap-1.5 transition-all cursor-pointer shadow-2xs`}
                            >
                              <IconComp size={18} />
                              <span className="leading-tight">{btn.label}</span>
                            </button>
                          );
                        })}
                      </div>
                    </div>

                  </div>

                  {/* Main Row 3: 4 Bottom Stat Cards */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                    <div className="p-4 bg-white rounded-3xl border border-stone-200 shadow-xs space-y-1">
                      <span className="text-[10px] uppercase font-bold text-stone-500">Total Revenue</span>
                      <div className="text-xl font-serif font-black text-rose-950">৳ 1,85,650</div>
                      <p className="text-[10px] text-emerald-600 font-bold">↑ 22.8% This Month</p>
                    </div>

                    <div className="p-4 bg-white rounded-3xl border border-stone-200 shadow-xs space-y-1">
                      <span className="text-[10px] uppercase font-bold text-stone-500">Average Order Value</span>
                      <div className="text-xl font-serif font-black text-stone-900">৳ 1,487</div>
                      <p className="text-[10px] text-emerald-600 font-bold">↑ 11.2% This Month</p>
                    </div>

                    <div className="p-4 bg-white rounded-3xl border border-stone-200 shadow-xs space-y-1">
                      <span className="text-[10px] uppercase font-bold text-stone-500">Conversion Rate</span>
                      <div className="text-xl font-serif font-black text-stone-900">2.45%</div>
                      <p className="text-[10px] text-emerald-600 font-bold">↑ 8.6% This Month</p>
                    </div>

                    <div className="p-4 bg-white rounded-3xl border border-stone-200 shadow-xs space-y-1">
                      <span className="text-[10px] uppercase font-bold text-stone-500">Returning Customers</span>
                      <div className="text-xl font-serif font-black text-stone-900">35.6%</div>
                      <p className="text-[10px] text-emerald-600 font-bold">↑ 6.4% This Month</p>
                    </div>
                  </div>

                  {/* Footer */}
                  <div className="pt-4 border-t border-stone-200 text-center text-stone-500 text-[11px] font-mono">
                    © 2026 Rongila Rup. All rights reserved. | Version 1.0.0
                  </div>

                </div>
              )}

              {/* TAB 1: ORDER MANAGEMENT & CONFIRMATIONS */}
              {activeTab === 'orders' && (
                <div className="space-y-4">
                  {/* Orders Header: Search, Filters, Payment Tabs & Manual Order Button */}
                  <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-xs space-y-3">
                    <div className="flex flex-col sm:flex-row gap-3 justify-between items-start sm:items-center">
                      <div className="relative w-full sm:w-80">
                        <Search size={14} className="absolute left-3 top-3 text-stone-400" />
                        <input
                          type="text"
                          value={orderSearch}
                          onChange={(e) => setOrderSearch(e.target.value)}
                          placeholder={lang === 'bn' ? 'ফোন নম্বর, নাম, অর্ডার আইডি বা TrxID...' : 'Search phone, name, order ID, TrxID...'}
                          className="w-full pl-9 pr-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs text-stone-900 focus:outline-none focus:ring-2 focus:ring-amber-500 font-mono"
                        />
                      </div>

                      <div className="flex items-center gap-2 text-xs w-full sm:w-auto flex-wrap">
                        {/* Courier Delivery Sync Button */}
                        <button
                          type="button"
                          onClick={() => handleSyncCourierStatus(true)}
                          disabled={isSyncingCourier}
                          className="px-3.5 py-2 bg-purple-700 hover:bg-purple-800 text-white font-bold rounded-xl flex items-center gap-1.5 shadow-xs transition-transform active:scale-95 cursor-pointer disabled:opacity-50"
                          title="স্টিডফাস্ট কুরিয়ারের সাথে লাইভ ডেলিভারি স্ট্যাটাস চেক ও অটো-আপডেট"
                        >
                          <RefreshCw size={14} className={isSyncingCourier ? 'animate-spin' : ''} />
                          <span>{isSyncingCourier ? 'সিঙ্ক হচ্ছে...' : '🔄 কুরিয়ার ডেলিভারি সিঙ্ক'}</span>
                        </button>

                        {/* Clear All Orders / Reset History Button */}
                        <button
                          type="button"
                          onClick={() => setIsClearHistoryModalOpen(true)}
                          className="px-3 py-2 bg-rose-100 hover:bg-rose-200 text-rose-800 font-bold rounded-xl flex items-center gap-1.5 transition-transform active:scale-95 cursor-pointer border border-rose-300"
                          title="ড্যাশবোর্ড ও পূর্বের সকল অর্ডার হিস্ট্রি মুছে ফেলুন"
                        >
                          <Trash2 size={14} />
                          <span>{lang === 'bn' ? '🗑️ হিস্ট্রি ক্লিয়ার' : 'Clear History'}</span>
                        </button>

                        <button
                          onClick={() => setIsCreateOrderOpen(true)}
                          className="px-3.5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white font-bold rounded-xl flex items-center gap-1.5 shadow-xs transition-transform active:scale-95 cursor-pointer ml-auto sm:ml-0"
                        >
                          <Plus size={14} />
                          <span>{lang === 'bn' ? 'নতুন অর্ডার তৈরি' : 'Create Order'}</span>
                        </button>
                      </div>
                    </div>

                    {/* ORDER STATUS QUICK TABS (Every order is always 1 click away!) */}
                    <div className="pt-2.5 border-t border-stone-200 flex items-center gap-1.5 flex-wrap text-xs font-bold">
                      <span className="text-stone-500 text-[11px] mr-1 flex items-center gap-1">
                        <Filter size={12} className="text-rose-900" />
                        <span>স্ট্যাটাস ফিল্টার:</span>
                      </span>
                      {[
                        { id: 'all', label: 'সকল অর্ডার', count: allTotalOrdersCount, activeClass: 'bg-stone-900 text-white' },
                        { id: 'processing', label: '⏳ পেন্ডিং / নতুন', count: allPendingOrdersCount, activeClass: 'bg-amber-500 text-stone-950 font-black' },
                        { id: 'confirmed', label: '✅ কনফার্মড', count: allConfirmedOrdersCount, activeClass: 'bg-blue-600 text-white' },
                        { id: 'shipped', label: '🚚 কুরিয়ারে এন্ট্রি', count: allShippedOrdersCount, activeClass: 'bg-purple-600 text-white' },
                        { id: 'on_hold', label: '⏸️ হোল্ডে রাখা', count: allOnHoldOrdersCount, activeClass: 'bg-amber-700 text-white' },
                        { id: 'delivered', label: '🎉 ডেলিভারি সম্পন্ন', count: allDeliveredOrdersCount, activeClass: 'bg-emerald-600 text-white' },
                        { id: 'cancelled', label: '❌ বাতিলকৃত', count: allCancelledOrdersCount, activeClass: 'bg-rose-600 text-white' },
                      ].map(tab => (
                        <button
                          key={tab.id}
                          type="button"
                          onClick={() => setOrderFilter(tab.id as any)}
                          className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                            orderFilter === tab.id
                              ? `${tab.activeClass} shadow-sm ring-2 ring-amber-400 ring-offset-1`
                              : 'bg-stone-100 hover:bg-stone-200 text-stone-700'
                          }`}
                        >
                          <span>{tab.label}</span>
                          <span className={`px-1.5 py-0.2 rounded-full font-mono text-[10px] ${
                            orderFilter === tab.id ? 'bg-white/30 text-white font-bold' : 'bg-stone-200 text-stone-800'
                          }`}>
                            {tab.count}
                          </span>
                        </button>
                      ))}
                    </div>

                    {/* Payment Verification Filter Pills */}
                    <div className="pt-2 border-t border-stone-100 flex items-center gap-1.5 flex-wrap text-xs font-bold">
                      <span className="text-stone-500 text-[11px] mr-1">পেমেন্ট ফিল্টার:</span>
                      <button
                        onClick={() => setPaymentFilter('all')}
                        className={`px-3 py-1 rounded-xl transition-all cursor-pointer ${
                          paymentFilter === 'all'
                            ? 'bg-rose-950 text-amber-300 shadow-xs'
                            : 'bg-stone-100 hover:bg-stone-200 text-stone-700'
                        }`}
                      >
                        সকল ({orders.length})
                      </button>
                      <button
                        onClick={() => setPaymentFilter('pending')}
                        className={`px-3 py-1 rounded-xl transition-all cursor-pointer flex items-center gap-1 ${
                          paymentFilter === 'pending'
                            ? 'bg-amber-500 text-rose-950 shadow-xs'
                            : 'bg-amber-100/80 hover:bg-amber-200 text-amber-900 border border-amber-300'
                        }`}
                      >
                        <span>⏳ টাকা যাচাইকরণ বাকি</span>
                        <span className="px-1.5 py-0.2 bg-rose-950 text-amber-300 text-[10px] rounded-full font-mono">
                          {pendingPaymentOrdersCount}
                        </span>
                      </button>
                      <button
                        onClick={() => setPaymentFilter('paid')}
                        className={`px-3 py-1 rounded-xl transition-all cursor-pointer flex items-center gap-1 ${
                          paymentFilter === 'paid'
                            ? 'bg-emerald-700 text-white shadow-xs'
                            : 'bg-emerald-100 hover:bg-emerald-200 text-emerald-900'
                        }`}
                      >
                        <span>✅ পরিশোধিত অর্ডার</span>
                        <span className="px-1.5 py-0.2 bg-emerald-900 text-white text-[10px] rounded-full font-mono">
                          {verifiedPaidOrdersCount}
                        </span>
                      </button>
                      <button
                        onClick={() => setPaymentFilter('cod')}
                        className={`px-3 py-1 rounded-xl transition-all cursor-pointer ${
                          paymentFilter === 'cod'
                            ? 'bg-stone-800 text-white shadow-xs'
                            : 'bg-stone-100 hover:bg-stone-200 text-stone-700'
                        }`}
                      >
                        📦 ক্যাশ অন ডেলিভারি (COD)
                      </button>
                    </div>
                  </div>

                  {filteredOrders.length === 0 ? (
                    <div className="p-12 text-center bg-white rounded-3xl border border-stone-200 space-y-3">
                      <div className="w-16 h-16 rounded-full bg-stone-100 text-stone-400 flex items-center justify-center mx-auto">
                        <ShoppingBag size={32} />
                      </div>
                      <h4 className="font-serif font-bold text-stone-800 text-sm">
                        {lang === 'bn' ? 'কোনো কাস্টমার অর্ডার পাওয়া যায়নি' : 'No customer orders found'}
                      </h4>
                      <p className="text-xs text-stone-500 font-medium max-w-sm mx-auto">
                        {lang === 'bn' ? 'ওয়েবসাইট থেকে নতুন অর্ডার আসলে এখানে সম্পূর্ণ লাইভ তালিকা প্রদর্শিত হবে।' : 'When new customer orders are placed, they will appear here in real-time.'}
                      </p>
                      {(orderFilter !== 'all' || paymentFilter !== 'all' || orderSearch.trim()) && (
                        <button
                          onClick={() => { setOrderFilter('all'); setPaymentFilter('all'); setOrderSearch(''); }}
                          className="px-4 py-2 bg-rose-950 text-amber-300 font-bold text-xs rounded-xl shadow-xs cursor-pointer"
                        >
                          সকল অর্ডার দেখুন (Show All Orders)
                        </button>
                      )}
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {filteredOrders.map(order => {
                        const customerOrderCount = getCustomerOrdersCount(order?.phone || '');
                        const customerSpend = getCustomerTotalSpend(order?.phone || '');
                        const safePhone = String(order?.phone || '');
                        const cleanPhone = safePhone.replace(/[^\d]/g, '');

                        // Payment calculation helpers
                        const isVerifiedPaid = order?.paymentStatus === 'VERIFIED_PAID' || order?.paymentStatus === 'PAID';
                        const isPendingVerification = order?.paymentStatus === 'PENDING_VERIFICATION';
                        const totalPayable = Number(order?.totalAmount) || 0;
                        const paidAmount = Number(order?.amountPaid ?? (isVerifiedPaid ? totalPayable : 0));
                        const dueAmount = Number(order?.amountDue ?? (isVerifiedPaid ? 0 : Math.max(0, totalPayable - paidAmount)));
                        const pMethod = (order?.paymentMethod || 'cod').toLowerCase();
                        const senderNumber = order?.paymentSenderPhone || order?.paymentPhone || '—';
                        const receiverNumber = order?.paymentReceiverNumber || '01792765693';

                        return (
                          <div key={order.id} className={`bg-white rounded-2xl p-4 sm:p-5 border shadow-sm space-y-3.5 transition-all ${
                            isPendingVerification ? 'border-amber-400 bg-amber-50/20' : 'border-stone-200 hover:border-amber-400'
                          }`}>
                            
                            {/* Order Header Info */}
                            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-stone-100 pb-3">
                              <div>
                                <div className="flex items-center gap-2 flex-wrap">
                                  <span className="text-[11px] font-mono bg-stone-100 text-stone-800 px-2 py-0.5 rounded font-extrabold">
                                    #{order.id}
                                  </span>
                                  <span className="text-[10px] text-stone-500">
                                    {order.createdAt || 'Just now'}
                                  </span>
                                  
                                  {/* Repeat Buyer Intelligence Tag */}
                                  <span className={`px-2 py-0.5 rounded-full text-[10px] font-extrabold flex items-center gap-1 border ${
                                    customerOrderCount > 1 
                                      ? 'bg-amber-100 border-amber-300 text-amber-900' 
                                      : 'bg-stone-100 border-stone-200 text-stone-700'
                                  }`}>
                                    <Users size={10} />
                                    <span>
                                      {customerOrderCount > 1 
                                        ? (lang === 'bn' ? `এই নম্বর থেকে ${customerOrderCount} টি অর্ডার করা হয়েছে (VIP Client - ৳${customerSpend.toLocaleString()})` : `Repeat Customer: ${customerOrderCount} Orders (৳${customerSpend})`) 
                                        : (lang === 'bn' ? '১ম অর্ডার (New Customer)' : '1st Order')}
                                    </span>
                                  </span>
                                </div>

                                <h4 className="text-base font-serif font-bold text-stone-900 mt-1 flex flex-wrap items-center gap-2">
                                  <span>{order.customerName || 'Customer'}</span>
                                  {safePhone && (
                                    <span className="text-rose-900 font-mono text-sm bg-rose-50 px-2 py-0.5 rounded border border-rose-200 font-bold">
                                      📞 {safePhone}
                                    </span>
                                  )}

                                  {/* Quick Fraud Check Button */}
                                  {safePhone && (
                                    <button
                                      onClick={() => {
                                        setActiveTab('fraud');
                                        setFraudSearchPhone(safePhone);
                                      }}
                                      className="px-2 py-0.5 bg-amber-100 hover:bg-amber-200 text-amber-950 font-bold text-[10px] rounded border border-amber-300 flex items-center gap-1 transition-colors cursor-pointer"
                                      title="কুরিয়ার রিটার্ন ও ফ্রড হিস্ট্রি চেক করুন"
                                    >
                                      <ShieldAlert size={12} className="text-rose-800" />
                                      <span>ফ্রড চেক</span>
                                    </button>
                                  )}

                                  {/* Flagged Fraud Warning Badge */}
                                  {cleanPhone && flaggedPhones.includes(cleanPhone) && (
                                    <span className="px-2 py-0.5 bg-red-600 text-white font-extrabold text-[10px] rounded-full flex items-center gap-1 animate-pulse shadow-xs">
                                      <ShieldX size={12} />
                                      <span>🚨 ফ্রড অ্যালার্ট ফ্ল্যাগড! (Blacklisted)</span>
                                    </span>
                                  )}
                                </h4>
                                <p className="text-xs text-stone-600 mt-0.5 font-medium">
                                  📍 {order.address || 'Address'}, {order.city || 'Dhaka'}
                                </p>
                              </div>

                              {/* Order Status Badge & Fast Changer */}
                              <div className="flex items-center gap-2">
                                <span className={`px-3 py-1 text-xs font-bold rounded-full uppercase tracking-wider flex items-center gap-1 ${
                                  order.status === 'delivered' ? 'bg-emerald-100 text-emerald-900' :
                                  order.status === 'confirmed' ? 'bg-blue-100 text-blue-900' :
                                  order.status === 'shipped' ? 'bg-purple-100 text-purple-900' :
                                  order.status === 'on_hold' ? 'bg-amber-100 text-amber-900' :
                                  order.status === 'cancelled' ? 'bg-red-100 text-red-900' :
                                  'bg-rose-100 text-rose-900'
                                }`}>
                                  {order.status === 'processing' && (lang === 'bn' ? '⏳ পেন্ডিং / প্রসেসিং' : 'Pending')}
                                  {order.status === 'confirmed' && (lang === 'bn' ? '✅ কনফার্মড' : 'Confirmed')}
                                  {order.status === 'shipped' && (lang === 'bn' ? '🚚 কুরিয়ারে এন্ট্রি করা' : 'Shipped')}
                                  {order.status === 'on_hold' && (lang === 'bn' ? '⏸️ হোল্ডে রাখা' : 'On Hold')}
                                  {order.status === 'delivered' && (lang === 'bn' ? '🎉 ডেলিভারি সম্পন্ন' : 'Delivered')}
                                  {order.status === 'cancelled' && (lang === 'bn' ? '❌ বাতিলকৃত' : 'Cancelled')}
                                </span>

                                <button
                                  onClick={() => setSelectedOrderDetail(order)}
                                  className="px-2.5 py-1 bg-amber-50 hover:bg-amber-100 text-amber-900 font-bold rounded-lg border border-amber-200 text-xs flex items-center gap-1 cursor-pointer transition-colors"
                                  title="সম্পূর্ণ বিবরণ দেখুন"
                                >
                                  <Eye size={13} />
                                  <span>{lang === 'bn' ? 'ডিটেইলস' : 'Details'}</span>
                                </button>
                              </div>
                            </div>

                            {/* Order Products List with Super Clear Size Badges */}
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs bg-stone-50 p-3 rounded-xl border border-stone-200">
                              {(order.items || []).map((item, idx) => {
                                const prod = item?.product;
                                const prodName = lang === 'bn' ? (prod?.nameBn || prod?.nameEn) : (prod?.nameEn || prod?.nameBn);
                                const prodImg = prod?.image || (prod?.images && prod.images[0]) || 'https://images.unsplash.com/photo-1519689680058-324335c77eba?w=100';
                                const prodPrice = Number(prod?.price) || 0;
                                const prodQty = Number(item?.quantity) || 1;

                                return (
                                  <div key={idx} className="flex items-center gap-2.5 bg-white p-2.5 rounded-xl border border-stone-200/80 shadow-2xs">
                                    <img src={prodImg} alt={prodName} className="w-12 h-12 object-cover rounded-lg shrink-0 border border-stone-200" referrerPolicy="no-referrer" />
                                    <div className="flex-1 min-w-0">
                                      <p className="font-bold text-stone-900 truncate text-xs">
                                        {prodName}
                                      </p>
                                      <div className="flex items-center justify-between gap-1 mt-1">
                                        <span className="text-[11px] text-stone-600 font-medium">
                                          <span className="font-extrabold text-stone-900">{prodQty}টি</span> × ৳{prodPrice.toLocaleString()}
                                        </span>

                                        {/* PROMINENT SIZE DISPLAY */}
                                        {item?.selectedSize ? (
                                          <span className="px-2 py-0.5 bg-rose-950 text-amber-300 font-mono font-black text-xs rounded-lg shadow-2xs border border-amber-500/40 flex items-center gap-1">
                                            <span>সাইজ:</span>
                                            <span className="text-white text-xs">{item.selectedSize}</span>
                                          </span>
                                        ) : (
                                          <span className="px-1.5 py-0.5 bg-stone-100 text-stone-500 font-mono text-[9px] rounded border border-stone-200">
                                            ফ্রি সাইজ
                                          </span>
                                        )}
                                      </div>
                                    </div>
                                  </div>
                                );
                              })}
                            </div>

                            {/* COMPREHENSIVE PAYMENT DETAILS, SCREENSHOT & VERIFICATION BOX */}
                            <div className="p-3.5 bg-gradient-to-br from-amber-50/70 via-stone-50 to-white rounded-2xl border border-amber-200/90 text-xs space-y-3">
                              <div className="flex flex-wrap items-center justify-between gap-2 border-b border-amber-200/60 pb-2.5">
                                <div className="flex items-center gap-2 flex-wrap">
                                  <span className="text-[10px] font-bold text-stone-500 uppercase tracking-wider">পেমেন্ট মেথড:</span>
                                  <span className={`px-2.5 py-0.5 rounded-lg font-black font-mono text-xs uppercase ${
                                    pMethod === 'bkash' ? 'bg-[#d12053] text-white' :
                                    pMethod === 'nagad' ? 'bg-[#f7941d] text-white' :
                                    pMethod === 'rocket' ? 'bg-[#8c3494] text-white' :
                                    'bg-stone-800 text-amber-300'
                                  }`}>
                                    {order.paymentMethod || 'COD'}
                                  </span>

                                  {/* Verification Badge */}
                                  <span className={`px-2.5 py-0.5 rounded-full font-bold text-xs flex items-center gap-1 ${
                                    isVerifiedPaid ? 'bg-emerald-100 text-emerald-900 border border-emerald-300' :
                                    isPendingVerification ? 'bg-amber-100 text-amber-900 border border-amber-300 animate-pulse' :
                                    'bg-stone-100 text-stone-700 border border-stone-300'
                                  }`}>
                                    {isVerifiedPaid && <span>✅ টাকা পরিশোধিত (Verified Paid)</span>}
                                    {isPendingVerification && <span>⏳ টাকা যাচাইকরণ বাকি (Verify)</span>}
                                    {!isVerifiedPaid && !isPendingVerification && <span>📦 ক্যাশ অন ডেলিভারি (বাকি)</span>}
                                  </span>
                                </div>

                                <div className="flex items-center gap-1 text-[11px]">
                                  <span className="text-stone-500">আমাদের রিসিভার নম্বর:</span>
                                  <span className="font-mono font-bold text-stone-900 bg-stone-100 px-2 py-0.5 rounded">
                                    {receiverNumber}
                                  </span>
                                </div>
                              </div>

                              {/* Payment Info Grid: Sender, TrxID, Amount Paid, Due COD, Screenshot */}
                              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 items-center">
                                {/* Sender Info */}
                                <div className="p-2.5 bg-white rounded-xl border border-stone-200">
                                  <span className="text-[10px] text-stone-400 font-bold block uppercase">কাস্টমারের সেন্ডার নম্বর</span>
                                  <p className="font-mono font-bold text-rose-950 text-xs mt-0.5">
                                    📞 {senderNumber}
                                  </p>
                                  {order.trxId ? (
                                    <div className="mt-1 pt-1 border-t border-stone-100">
                                      <span className="text-[9px] text-pink-700 font-bold block uppercase">TrxID / ট্রানজেকশন আইডি</span>
                                      <span className="font-mono font-extrabold text-pink-900 text-xs select-all">
                                        {order.trxId}
                                      </span>
                                    </div>
                                  ) : (
                                    <span className="text-[10px] text-stone-400 italic block mt-1">TrxID দেওয়া হয়নি</span>
                                  )}
                                </div>

                                {/* Financial Amounts: Total, Paid, Due */}
                                <div className="p-2.5 bg-white rounded-xl border border-stone-200 space-y-1">
                                  <div className="flex justify-between text-[11px]">
                                    <span className="text-stone-500">মোট বিল:</span>
                                    <span className="font-bold text-stone-900">৳{totalPayable.toLocaleString()}</span>
                                  </div>
                                  <div className="flex justify-between text-[11px]">
                                    <span className="text-emerald-700 font-bold">পরিশোধিত (Paid):</span>
                                    <span className="font-mono font-bold text-emerald-800">৳{paidAmount.toLocaleString()}</span>
                                  </div>
                                  <div className="flex justify-between text-[11px] pt-1 border-t border-stone-100 font-bold">
                                    <span className="text-rose-900">বাকি প্রদেয় (COD Due):</span>
                                    <span className="font-serif font-black text-rose-950">৳{dueAmount.toLocaleString()}</span>
                                  </div>
                                </div>

                                {/* Payment Screenshot Proof */}
                                <div className="p-2.5 bg-white rounded-xl border border-stone-200 flex items-center gap-2">
                                  {order.paymentScreenshot ? (
                                    <>
                                      <img
                                        src={order.paymentScreenshot}
                                        alt="Payment Proof"
                                        onClick={() => openScreenshotPreview(order.paymentScreenshot || '', order)}
                                        className="w-12 h-12 object-cover rounded-lg border border-amber-300 cursor-pointer hover:opacity-80 transition-opacity shrink-0 shadow-2xs"
                                        title="বড় করে দেখতে ক্লিক করুন"
                                      />
                                      <div className="min-w-0">
                                        <span className="text-[10px] text-emerald-700 font-bold block">📸 পেমেন্ট স্ক্রিনশট</span>
                                        <button
                                          onClick={() => openScreenshotPreview(order.paymentScreenshot || '', order)}
                                          className="text-[11px] text-amber-900 font-bold hover:underline flex items-center gap-1 cursor-pointer mt-0.5"
                                        >
                                          <Eye size={11} />
                                          <span>স্ক্রিনশট দেখুন</span>
                                        </button>
                                      </div>
                                    </>
                                  ) : (
                                    <div className="text-center w-full py-1 text-stone-400">
                                      <ImageIcon size={18} className="mx-auto text-stone-300" />
                                      <span className="text-[10px] block mt-0.5">কোনো স্ক্রিনশট নেই</span>
                                    </div>
                                  )}
                                </div>

                                {/* 1-Click Verification Action Buttons for Admin */}
                                <div className="flex flex-col gap-1.5 justify-center">
                                  {!isVerifiedPaid ? (
                                    <button
                                      onClick={() => {
                                        if (onUpdateFullOrder) {
                                          onUpdateFullOrder({
                                            ...order,
                                            paymentStatus: 'VERIFIED_PAID',
                                            amountPaid: totalPayable,
                                            amountDue: 0
                                          });
                                        }
                                      }}
                                      className="px-3 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl font-bold text-xs flex items-center justify-center gap-1 shadow-xs cursor-pointer transition-transform active:scale-95"
                                      title="সম্পূর্ণ টাকা পেয়েছি হিসেবে কনফার্ম করুন"
                                    >
                                      <CheckCircle2 size={13} />
                                      <span>✅ টাকা পেয়েছি (Mark Paid)</span>
                                    </button>
                                  ) : (
                                    <button
                                      onClick={() => {
                                        if (onUpdateFullOrder) {
                                          onUpdateFullOrder({
                                            ...order,
                                            paymentStatus: 'UNPAID',
                                            amountPaid: 0,
                                            amountDue: totalPayable
                                          });
                                        }
                                      }}
                                      className="px-3 py-1 bg-stone-200 hover:bg-stone-300 text-stone-700 rounded-xl font-bold text-[11px] flex items-center justify-center gap-1 cursor-pointer"
                                      title="টাকা পাওয়া যায়নি হিসেবে মার্ক করুন"
                                    >
                                      <RotateCcw size={12} />
                                      <span>পেমেন্ট বাতিল (Unpaid)</span>
                                    </button>
                                  )}

                                  <button
                                    onClick={() => {
                                      setEditingPaymentOrder(order);
                                      const paid = order.amountPaid !== undefined
                                        ? order.amountPaid
                                        : (order.paymentStatus === 'VERIFIED_PAID' ? order.totalAmount : 0);
                                      setCustomPaidAmount(paid);
                                      setCustomPaymentMethod(order.paymentMethod || 'bkash');
                                      setCustomPaymentTrxId(order.trxId || '');
                                    }}
                                    className="px-3 py-1 bg-amber-100 hover:bg-amber-200 text-amber-900 rounded-xl font-bold text-[11px] flex items-center justify-center gap-1 cursor-pointer"
                                    title="পেইড টাকা এন্ট্রি করুন বা COD কালেকশন ৳০ করুন"
                                  >
                                    <Edit3 size={11} />
                                    <span>✏️ পেইড ও COD ৳০ এডিট</span>
                                  </button>
                                </div>
                              </div>
                            </div>

                            {/* ADMIN ACTION CONTROL BUTTONS */}
                            <div className="pt-2 flex flex-wrap items-center justify-between gap-2 border-t border-stone-200 text-xs">
                              <div className="flex items-center gap-2 flex-wrap">
                                {/* Always Available: Edit Items, Delivery Fee, or Confirm Order */}
                                <button
                                  onClick={() => {
                                    setConfirmingOrder(order);
                                    setCustomShippingFee(order.shippingFee || 80);
                                    setCustomDiscount(order.discount || 0);
                                    setConfirmIsPaid(order.paymentStatus === 'VERIFIED_PAID' || order.amountDue === 0);
                                  }}
                                  className={`px-3.5 py-2 font-bold rounded-xl flex items-center gap-1.5 transition-all shadow-xs cursor-pointer ${
                                    order.status === 'processing'
                                      ? 'bg-emerald-700 hover:bg-emerald-800 text-white'
                                      : 'bg-amber-100 hover:bg-amber-200 text-amber-950 border border-amber-300'
                                  }`}
                                  title="অর্ডার থেকে পণ্য বাদ দিন, ডেলিভারি চার্জ বা ডিসকাউন্ট এডিট করুন"
                                >
                                  {order.status === 'processing' ? (
                                    <>
                                      <CheckCircle2 size={14} />
                                      <span>{lang === 'bn' ? 'অর্ডার কনফার্ম ও চার্জ এডিট' : 'Confirm Order & Edit Fee'}</span>
                                    </>
                                  ) : (
                                    <>
                                      <Edit3 size={14} />
                                      <span>{lang === 'bn' ? '✏️ পণ্য বাদ / অর্ডার এডিট' : 'Edit Items & Fee'}</span>
                                    </>
                                  )}
                                </button>

                                {/* Quick Status Selector */}
                                <div className="flex items-center gap-1 bg-stone-100 px-2.5 py-1.5 rounded-xl border border-stone-200">
                                  <span className="text-[10px] font-bold text-stone-500">স্ট্যাটাস:</span>
                                  <select
                                    value={order.status}
                                    onChange={(e) => onUpdateOrderStatus(order.id, e.target.value as any)}
                                    className="bg-transparent font-bold text-xs text-rose-950 focus:outline-none cursor-pointer"
                                  >
                                    <option value="processing">⏳ পেন্ডিং</option>
                                    <option value="confirmed">✅ কনফার্মড</option>
                                    <option value="shipped">🚚 কুরিয়ারে এন্ট্রি</option>
                                    <option value="on_hold">⏸️ হোল্ডে রাখা</option>
                                    <option value="delivered">🎉 ডেলিভারি সম্পন্ন</option>
                                    <option value="cancelled">❌ বাতিল</option>
                                  </select>
                                </div>

                                {/* Auto Courier Dispatch Entry Button */}
                                <button
                                  onClick={() => {
                                    setDispatchingOrder(order);
                                    const initialCod = order.amountDue !== undefined
                                      ? order.amountDue
                                      : (order.paymentStatus === 'VERIFIED_PAID' ? 0 : order.totalAmount);
                                    setDispatchCodAmount(initialCod);
                                  }}
                                  className="px-3.5 py-2 bg-rose-950 hover:bg-rose-900 text-amber-300 font-bold rounded-xl flex items-center gap-1.5 transition-all shadow-xs cursor-pointer"
                                >
                                  <Truck size={14} />
                                  <span>{lang === 'bn' ? 'কুরিয়ারে এন্ট্রি (Steadfast/Pathao)' : 'Dispatch Courier'}</span>
                                </button>

                                {/* Mark Delivered by Rider Button */}
                                {order.status === 'shipped' && (
                                  <button
                                    type="button"
                                    onClick={() => handleMarkRiderDelivered(order)}
                                    className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl flex items-center gap-1.5 transition-all shadow-xs cursor-pointer animate-pulse"
                                    title="রাইডার ডেলিভারি সম্পন্ন করলে এখানে ক্লিক করে সরাসরি ডেলিভারি ও পেমেন্ট কনফার্ম করুন"
                                  >
                                    <CheckCircle2 size={14} />
                                    <span>{lang === 'bn' ? '✅ রাইডার ডেলিভারি সম্পন্ন' : 'Mark Delivered'}</span>
                                  </button>
                                )}

                                {/* Cancel Order Button */}
                                {order.status !== 'cancelled' && (
                                  <button
                                    onClick={() => {
                                      if (confirm(lang === 'bn' ? 'আপনি কি নিশ্চিত যে এই অর্ডারটি বাতিল করতে চান?' : 'Are you sure you want to cancel this order?')) {
                                        onUpdateOrderStatus(order.id, 'cancelled');
                                      }
                                    }}
                                    className="px-3 py-2 bg-red-100 hover:bg-red-200 text-red-800 font-bold rounded-xl flex items-center gap-1 transition-all cursor-pointer"
                                  >
                                    <XCircle size={14} />
                                    <span>{lang === 'bn' ? 'বাতিল' : 'Cancel'}</span>
                                  </button>
                                )}
                              </div>

                              <div className="flex items-center gap-2">
                                {/* Print Invoice & Sticker */}
                                <button
                                  onClick={() => setPrintingOrder(order)}
                                  className="px-3 py-2 bg-stone-200 hover:bg-stone-300 text-stone-800 font-bold rounded-xl flex items-center gap-1 transition-all cursor-pointer"
                                >
                                  <Printer size={14} />
                                  <span>{lang === 'bn' ? 'ইনভয়েস প্রিন্ট' : 'Print Invoice'}</span>
                                </button>

                                {/* Direct Call Customer */}
                                <a
                                  href={`tel:${order.phone}`}
                                  className="px-3 py-2 bg-emerald-100 hover:bg-emerald-200 text-emerald-900 font-bold rounded-xl flex items-center gap-1 transition-all"
                                >
                                  <PhoneCall size={14} />
                                  <span>{lang === 'bn' ? 'কল করুন' : 'Call'}</span>
                                </a>

                                {/* Direct WhatsApp */}
                                <a
                                  href={`https://wa.me/88${String(order.phone || '').replace(/[^0-9]/g, '')}`}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="px-3 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl flex items-center gap-1 transition-all"
                                >
                                  <Send size={14} />
                                  <span>WhatsApp</span>
                                </a>
                              </div>
                            </div>

                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              )}

              {/* TAB 2: CUSTOMER CRM DATABASE & REPEAT BUYERS */}
              {activeTab === 'customers' && (
                <div className="space-y-4">
                  <div className="p-4 bg-white rounded-2xl border border-stone-200 shadow-xs flex flex-col md:flex-row justify-between items-start md:items-center gap-3">
                    <div>
                      <h4 className="font-serif font-bold text-stone-900 text-base flex items-center gap-2">
                        <Users size={18} className="text-amber-600" />
                        <span>{lang === 'bn' ? 'কাস্টমার ডাটাবেজ ও ইন্টেলিজেন্স (CRM)' : 'Customer Intelligence Database'}</span>
                      </h4>
                      <p className="text-xs text-stone-500">
                        {lang === 'bn' ? 'সকল কাস্টমারের নাম, মোবাইল নম্বর, ক্রয়ের সংখ্যা ও মোট টাকার হিসাব ট্র্যাক করুন।' : 'Track total order count, VIP buyers, and lifetime value per customer.'}
                      </p>
                    </div>

                    <div className="flex items-center gap-2 w-full md:w-auto flex-wrap">
                      {/* Customer Search Bar */}
                      <div className="relative w-full sm:w-56">
                        <Search size={14} className="absolute left-3 top-3 text-stone-400" />
                        <input
                          type="text"
                          value={customerSearch}
                          onChange={(e) => setCustomerSearch(e.target.value)}
                          placeholder={lang === 'bn' ? 'নাম বা ফোন দিয়ে খুঁজুন...' : 'Search customer...'}
                          className="w-full pl-9 pr-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs text-stone-900 focus:outline-none focus:ring-2 focus:ring-amber-500 font-mono"
                        />
                      </div>

                      {/* Filter Toggle Buttons: All vs Top Customers */}
                      <div className="flex bg-stone-100 p-1 rounded-xl border border-stone-200 gap-1 text-xs font-bold">
                        <button
                          onClick={() => setCustomerTabFilter('all')}
                          className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
                            customerTabFilter === 'all' ? 'bg-rose-950 text-amber-300 shadow-xs' : 'text-stone-700 hover:text-stone-900'
                          }`}
                        >
                          সকল ({customerList.length})
                        </button>
                        <button
                          onClick={() => setCustomerTabFilter('top')}
                          className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer flex items-center gap-1 ${
                            customerTabFilter === 'top' ? 'bg-amber-500 text-rose-950 shadow-xs' : 'text-stone-700 hover:text-stone-900'
                          }`}
                        >
                          <span>👑 শীর্ষ ভিআইপি</span>
                        </button>
                      </div>
                    </div>
                  </div>

                  {(() => {
                    let displayList = customerTabFilter === 'top'
                      ? [...customerList].sort((a, b) => (b.totalSpent || 0) - (a.totalSpent || 0))
                      : customerList;

                    if (customerSearch.trim()) {
                      const q = customerSearch.toLowerCase();
                      displayList = displayList.filter(c => 
                        (c.name || '').toLowerCase().includes(q) || 
                        (c.phone || '').toLowerCase().includes(q) ||
                        (c.city || '').toLowerCase().includes(q)
                      );
                    }

                    if (displayList.length === 0) {
                      return (
                        <div className="p-12 text-center bg-white rounded-3xl border border-stone-200 space-y-3">
                          <div className="w-16 h-16 rounded-full bg-amber-50 text-amber-700 flex items-center justify-center mx-auto border border-amber-200">
                            <Users size={32} />
                          </div>
                          <h4 className="font-serif font-bold text-stone-800 text-base">
                            {lang === 'bn' ? 'বর্তমানে কোনো কাস্টমার রেকর্ড নেই' : 'No customer records found'}
                          </h4>
                          <p className="text-xs text-stone-500 max-w-md mx-auto leading-relaxed">
                            {lang === 'bn' 
                              ? 'কাস্টমাররা অর্ডার করার সাথে সাথে স্বয়ংক্রিয়ভাবে তাদের নাম, ফোন নম্বর, ঠিকানা ও মোট ক্রয়ের হিসাব এখানে যুক্ত হয়ে যাবে।'
                              : 'Customer profiles and purchase history will automatically appear here as orders are placed.'}
                          </p>
                          <button
                            onClick={() => { setActiveTab('orders'); setOrderFilter('all'); }}
                            className="px-4 py-2 bg-rose-950 text-amber-300 font-bold text-xs rounded-xl shadow-xs cursor-pointer"
                          >
                            অর্ডার সেকশন দেখুন (View Orders)
                          </button>
                        </div>
                      );
                    }

                    return (
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {displayList.map((cust, i) => {
                          const isTopRank = customerTabFilter === 'top' && i < 3;
                          const rankBadge = i === 0 ? '🥇 #1 VIP' : i === 1 ? '🥈 #2 VIP' : i === 2 ? '🥉 #3 VIP' : `👑 #${i + 1}`;
                          const cleanCustPhone = String(cust.phone || '').replace(/[^0-9]/g, '');

                          return (
                            <div key={i} className={`p-4 rounded-2xl border shadow-xs space-y-3 transition-all ${
                              isTopRank ? 'bg-gradient-to-br from-amber-50 to-orange-50/40 border-amber-300' : 'bg-white border-stone-200 hover:border-amber-400'
                            }`}>
                              <div className="flex justify-between items-start">
                                <div>
                                  <div className="flex items-center gap-2">
                                    <h5 className="font-serif font-bold text-stone-900 text-sm">
                                      {cust.name || 'গ্রাহক'}
                                    </h5>
                                    {customerTabFilter === 'top' && (
                                      <span className="px-2 py-0.5 bg-amber-400 text-rose-950 text-[10px] font-extrabold rounded-full font-mono">
                                        {rankBadge}
                                      </span>
                                    )}
                                  </div>
                                  <span className="text-xs font-mono font-bold text-rose-950 block mt-0.5">
                                    📞 {cust.phone || 'N/A'}
                                  </span>
                                  <span className="text-[11px] text-stone-500 block">
                                    📍 {cust.city || 'ঢাকা'} • সর্বশেষ অর্ডার: {cust.lastOrderDate || 'সাম্প্রতিক'}
                                  </span>
                                </div>

                                <div className="text-right">
                                  <span className={`px-2.5 py-1 rounded-full text-xs font-mono font-extrabold block ${
                                    (cust.ordersCount || 0) > 1 ? 'bg-amber-100 text-amber-900 border border-amber-300' : 'bg-stone-100 text-stone-700'
                                  }`}>
                                    {cust.ordersCount || 1} {lang === 'bn' ? 'টি অর্ডার' : 'Orders'}
                                  </span>
                                  <span className="text-sm font-serif font-black text-rose-950 mt-1 block">
                                    ৳{(cust.totalSpent || 0).toLocaleString()}
                                  </span>
                                </div>
                              </div>

                              <div className="pt-2 border-t border-stone-100 flex items-center justify-between text-xs">
                                <button
                                  onClick={() => {
                                    setActiveTab('orders');
                                    setOrderSearch(cust.phone || '');
                                  }}
                                  className="text-amber-800 font-bold hover:underline flex items-center gap-1 cursor-pointer"
                                >
                                  <Eye size={12} />
                                  <span>{lang === 'bn' ? 'এই কাস্টমারের সকল অর্ডার দেখুন' : 'View Orders'}</span>
                                </button>

                                {cleanCustPhone && (
                                  <a
                                    href={`https://wa.me/88${cleanCustPhone}`}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-bold text-[11px] flex items-center gap-1 transition-colors"
                                  >
                                    <Send size={10} />
                                    <span>WhatsApp</span>
                                  </a>
                                )}
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    );
                  })()}
                </div>
              )}

              {/* TAB 5: FRAUD CUSTOMER INTELLIGENCE & BLACKLIST */}
              {activeTab === 'fraud' && (
                <div className="space-y-6 max-w-4xl mx-auto text-xs animate-fade-in">
                  
                  {/* Top Fraud Check Search Bar */}
                  <div className="p-6 bg-gradient-to-r from-rose-950 via-amber-950 to-stone-900 text-amber-50 rounded-3xl border border-amber-500/30 shadow-xl space-y-4">
                    <div className="flex items-center gap-3">
                      <div className="p-3 bg-amber-500 text-rose-950 rounded-2xl font-bold shrink-0">
                        <ShieldAlert size={26} />
                      </div>
                      <div>
                        <h4 className="font-serif font-bold text-base text-amber-200">
                          🛡️ কুরিয়ার ফ্রড কাস্টমার ইন্টেলিজেন্স ও রিটার্ন রিস্ক চেকার
                        </h4>
                        <p className="text-xs text-amber-100/70">
                          অর্ডার কনফার্ম বা ডেলিভারি করার পূর্বে মোবাইল নম্বর দিয়ে কাস্টমারের পার্সেল রিসিভ ও রিটার্ন রেকর্ড যাচাই করুন।
                        </p>
                      </div>
                    </div>

                    <div className="flex flex-col sm:flex-row gap-3 pt-2">
                      <input
                        type="text"
                        placeholder="কাস্টমার মোবাইল নম্বর (e.g. 01712345678)"
                        value={fraudSearchPhone}
                        onChange={(e) => setFraudSearchPhone(e.target.value)}
                        className="flex-1 px-4 py-3 bg-white text-stone-900 font-mono font-bold text-sm rounded-2xl border-2 border-amber-400 focus:outline-none placeholder:font-sans placeholder:text-stone-400 placeholder:text-xs"
                      />
                      <button
                        onClick={() => {
                          if (!fraudSearchPhone.trim()) {
                            alert('দয়া করে ফোন নম্বর লিখুন');
                            return;
                          }
                        }}
                        className="px-6 py-3 bg-amber-500 hover:bg-amber-400 text-rose-950 font-black text-xs rounded-2xl shadow-md transition-all cursor-pointer shrink-0 flex items-center justify-center gap-2"
                      >
                        <Search size={16} />
                        <span>লাইভ ফ্রড রেকর্ড চেক করুন</span>
                      </button>
                    </div>
                  </div>

                  {/* Fraud Search Analysis Result Box */}
                  {fraudSearchPhone.trim() !== '' && (() => {
                    const clean = fraudSearchPhone.replace(/[^\d]/g, '');
                    const customerOrders = orders.filter(o => o.phone.replace(/[^\d]/g, '') === clean);
                    const deliveredCount = customerOrders.filter(o => o.status === 'delivered').length;
                    const cancelledCount = customerOrders.filter(o => o.status === 'cancelled').length;
                    const isFlagged = flaggedPhones.includes(clean);
                    
                    // Courier Network Simulated Score
                    const hashVal = clean.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
                    const courierSuccessRate = isFlagged ? 35 : (hashVal % 25) + 75; // 75% to 99%
                    const riskLevel = isFlagged ? 'HIGH_RISK_FRAUD' : (courierSuccessRate < 80 ? 'MEDIUM_RISK' : 'SAFE');

                    return (
                      <div className="p-6 bg-white rounded-3xl border border-stone-200 shadow-md space-y-5 animate-fade-in">
                        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b border-stone-100 pb-4">
                          <div>
                            <span className="text-[10px] font-bold text-stone-400 uppercase tracking-wider block">মোবাইল নম্বর অ্যানালিসিস:</span>
                            <div className="text-xl font-mono font-black text-rose-950 flex items-center gap-2">
                              <span>📞 {clean || fraudSearchPhone}</span>
                              {isFlagged && (
                                <span className="px-2.5 py-0.5 bg-red-600 text-white font-extrabold text-xs rounded-full">
                                  🚨 ফ্ল্যাগড / ব্ল্যাকলিস্টেড
                                </span>
                              )}
                            </div>
                          </div>

                          <button
                            onClick={() => toggleFlagPhone(clean)}
                            className={`px-4 py-2 rounded-xl font-bold text-xs flex items-center gap-1.5 transition-all cursor-pointer ${
                              isFlagged
                                ? 'bg-stone-200 text-stone-800 hover:bg-stone-300'
                                : 'bg-red-600 hover:bg-red-700 text-white shadow-md'
                            }`}
                          >
                            <ShieldX size={16} />
                            <span>{isFlagged ? 'ব্ল্যাকলিস্ট থেকে সরান' : '🚨 কাস্টমারকে ব্ল্যাকলিস্টে যুক্ত করুন'}</span>
                          </button>
                        </div>

                        {/* Risk Indicator Card */}
                        <div className={`p-4 rounded-2xl border flex flex-col sm:flex-row items-center justify-between gap-4 ${
                          riskLevel === 'HIGH_RISK_FRAUD'
                            ? 'bg-red-50 border-red-300 text-red-950'
                            : riskLevel === 'MEDIUM_RISK'
                            ? 'bg-amber-50 border-amber-300 text-amber-950'
                            : 'bg-emerald-50 border-emerald-300 text-emerald-950'
                        }`}>
                          <div className="flex items-center gap-3">
                            <div className={`p-3 rounded-2xl font-bold ${
                              riskLevel === 'HIGH_RISK_FRAUD' ? 'bg-red-600 text-white' : riskLevel === 'MEDIUM_RISK' ? 'bg-amber-500 text-rose-950' : 'bg-emerald-600 text-white'
                            }`}>
                              {riskLevel === 'HIGH_RISK_FRAUD' ? <ShieldX size={24} /> : riskLevel === 'MEDIUM_RISK' ? <AlertTriangle size={24} /> : <ShieldCheck size={24} />}
                            </div>
                            <div>
                              <h5 className="font-serif font-extrabold text-sm">
                                {riskLevel === 'HIGH_RISK_FRAUD' && '🚨 উচ্চ রিটার্ন ঝুঁকি (High Return Fraud Risk)'}
                                {riskLevel === 'MEDIUM_RISK' && '⚠️ মাঝারি ঝুঁকি (Medium Risk Customer)'}
                                {riskLevel === 'SAFE' && '✅ নিরাপদ কাস্টমার (Verified Safe Customer)'}
                              </h5>
                              <p className="text-xs opacity-80 mt-0.5">
                                {riskLevel === 'HIGH_RISK_FRAUD' && 'এই কাস্টমারের কুরিয়ার রিটার্ন হার বেশি বা ফ্রড ফ্ল্যাগ রয়েছে। অগ্রিম ডেলিভারি চার্জ নিশ্চিত করে অর্ডার কনফার্ম করার পরামর্শ দেয়া হচ্ছে।'}
                                {riskLevel === 'MEDIUM_RISK' && 'কুরিয়ার ডেলিভারি রেট ৮০% এর নিচে। অর্ডার কনফার্ম করার আগে ফোনে কথা বলুন।'}
                                {riskLevel === 'SAFE' && 'কুরিয়ার সিস্টেমে এই নম্বরের ডেলিভারি রেকর্ড অত্যন্ত চমৎকার (৯০%+ সাকসেস)। ক্যাশ অন ডেলিভারিতে পাঠানো নিরাপদ।'}
                              </p>
                            </div>
                          </div>

                          <div className="text-center sm:text-right shrink-0 bg-white/80 p-3 rounded-xl border border-black/5">
                            <span className="text-[10px] uppercase font-bold text-stone-500 block">কুরিয়ার সাকসেস স্কোর:</span>
                            <span className="text-2xl font-mono font-black text-rose-950">{courierSuccessRate}%</span>
                          </div>
                        </div>

                        {/* Store Statistics for this phone */}
                        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                          <div className="p-3 bg-stone-50 rounded-xl border border-stone-200">
                            <span className="text-[10px] text-stone-500 font-bold block uppercase">স্টোরে মোট অর্ডার</span>
                            <span className="text-lg font-mono font-extrabold text-stone-900">{customerOrders.length}টি</span>
                          </div>
                          <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-200">
                            <span className="text-[10px] text-emerald-800 font-bold block uppercase">সফল ডেলিভারি</span>
                            <span className="text-lg font-mono font-extrabold text-emerald-900">{deliveredCount}টি</span>
                          </div>
                          <div className="p-3 bg-red-50 rounded-xl border border-red-200">
                            <span className="text-[10px] text-red-800 font-bold block uppercase">বাতিল বা রিটার্ন</span>
                            <span className="text-lg font-mono font-extrabold text-red-900">{cancelledCount}টি</span>
                          </div>
                          <div className="p-3 bg-amber-50 rounded-xl border border-amber-200">
                            <span className="text-[10px] text-amber-900 font-bold block uppercase">স্ট্যাটাস</span>
                            <span className="text-xs font-bold text-rose-950 block mt-1">
                              {isFlagged ? '🚨 ব্ল্যাকলিস্টেড' : customerOrders.length > 1 ? '💎 রিপিট কাস্টমার' : 'নতুন কাস্টমার'}
                            </span>
                          </div>
                        </div>
                      </div>
                    );
                  })()}

                  {/* Flagged / Blacklisted Phones List Section */}
                  <div className="p-6 bg-white rounded-3xl border border-stone-200 shadow-sm space-y-4">
                    <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b border-stone-100 pb-3">
                      <div>
                        <h4 className="font-serif font-bold text-stone-900 text-base flex items-center gap-2">
                          <ShieldX size={18} className="text-red-600" />
                          <span>ব্ল্যাকলিস্টে থাকা সন্দেহজনক ফোন নম্বরসমূহ ({flaggedPhones.length})</span>
                        </h4>
                        <p className="text-xs text-stone-500">
                          এখানে থাকা নম্বরগুলো থেকে কেউ অর্ডার দিলে কাস্টমার প্যানেল ও এডমিন প্যানেলে তাৎক্ষণিক ফ্রড ওয়ার্নিং দেখানো হয়।
                        </p>
                      </div>
                    </div>

                    {flaggedPhones.length === 0 ? (
                      <div className="p-8 text-center text-stone-500 bg-stone-50 rounded-2xl border border-stone-200">
                        <ShieldCheck size={32} className="mx-auto text-emerald-600 mb-2" />
                        <p className="font-bold text-xs">বর্তমানে কোনো ব্ল্যাকলিস্টেড ফোন নম্বর নেই।</p>
                      </div>
                    ) : (
                      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                        {flaggedPhones.map((ph, idx) => (
                          <div key={idx} className="p-3.5 bg-red-50/60 rounded-2xl border border-red-200 flex items-center justify-between gap-2 shadow-2xs">
                            <div>
                              <span className="text-[10px] font-bold text-red-700 uppercase block">🚨 ব্ল্যাকলিস্টেড</span>
                              <span className="font-mono font-black text-sm text-stone-900">📞 {ph}</span>
                            </div>
                            <button
                              onClick={() => toggleFlagPhone(ph)}
                              className="px-2.5 py-1 bg-white hover:bg-stone-100 text-stone-800 font-bold text-[11px] rounded-xl border border-stone-300 transition-colors cursor-pointer"
                              title="ব্ল্যাকলিস্ট থেকে মুছুন"
                            >
                              আনব্লক
                            </button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                </div>
              )}

              {/* TAB 3: PRODUCT INVENTORY LIST */}
              {activeTab === 'products' && (
                <div className="space-y-4">
                  {/* Meta Carousel & Order Now Ads Promotion Banner */}
                  <div className="p-4 bg-gradient-to-r from-blue-900 via-indigo-950 to-slate-900 text-white rounded-2xl flex flex-wrap items-center justify-between gap-3 shadow-md border border-blue-400/30 animate-fade-in">
                    <div className="flex items-center gap-3">
                      <div className="p-2.5 bg-blue-600 rounded-2xl text-white font-black shadow-md border border-blue-400 shrink-0">
                        <Rocket size={20} />
                      </div>
                      <div>
                        <h4 className="font-serif font-bold text-sm text-blue-100 flex items-center gap-2">
                          <span>ফেসবুক ক্যারোসেল বুস্ট ও "Order now" বাটন অ্যাড জেনারেটর</span>
                          <span className="bg-blue-500 text-white text-[10px] px-2 py-0.5 rounded-full font-bold">Meta Carousel Ads</span>
                        </h4>
                        <p className="text-xs text-blue-200/90 mt-0.5">
                          ৫-১০টি ড্রেস একসাথে সিলেক্ট করে বিজ্ঞাপনের নিচে বড় নীল "Order now" বাটন সহ বুস্ট লিংক তৈরি করুন
                        </p>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => {
                        setBoostModalProduct(null);
                        setIsAdsManagerOpen(true);
                      }}
                      className="px-4 py-2.5 bg-blue-500 hover:bg-blue-400 text-white font-extrabold text-xs rounded-xl shadow-lg transition-all flex items-center gap-1.5 cursor-pointer shrink-0"
                    >
                      <Rocket size={14} />
                      <span>৫-১০টি প্রোডাক্ট ক্যারোসেল অ্যাড তৈরি করুন</span>
                    </button>
                  </div>

                  <div className="flex justify-between items-center bg-white p-3.5 rounded-2xl border border-stone-200">
                    <h4 className="font-serif font-bold text-stone-900 text-sm">
                      {lang === 'bn' ? `সর্বমোট ওয়েবসাইট প্রডাক্ট লিস্ট (${products.length})` : `All Products (${products.length})`}
                    </h4>
                    <button
                      onClick={() => setActiveTab('add_product')}
                      className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs rounded-xl flex items-center gap-1 transition-colors cursor-pointer"
                    >
                      <Plus size={14} />
                      <span>{lang === 'bn' ? 'নতুন প্রডাক্ট যোগ করুন' : 'Add Product'}</span>
                    </button>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                    {products.map(p => (
                      <div key={p.id} className="bg-white rounded-2xl p-3 border border-stone-200 shadow-sm flex gap-3">
                        <img src={p.image} alt={p.nameEn} className="w-20 h-24 object-cover rounded-xl shrink-0 border border-stone-200" referrerPolicy="no-referrer" />
                        <div className="flex-1 min-w-0 flex flex-col justify-between">
                          <div>
                            <span className="text-[9px] font-bold text-amber-800 uppercase tracking-wider block">
                              {p.category}
                            </span>
                            <h5 className="font-serif font-bold text-xs text-stone-900 truncate">
                              {lang === 'bn' ? p.nameBn : p.nameEn}
                            </h5>
                            <div className="flex items-center justify-between mt-1">
                              <p className="text-xs font-bold text-rose-950">৳{p.price.toLocaleString()}</p>
                              <button
                                onClick={() => {
                                  const updated = {
                                    ...p,
                                    isFlashSale: !p.isFlashSale,
                                    originalPrice: p.originalPrice || Math.round(p.price * 1.25)
                                  };
                                  onUpdateProduct(updated);
                                }}
                                className={`px-2 py-0.5 text-[10px] font-bold rounded-lg border transition-colors flex items-center gap-1 cursor-pointer ${
                                  p.isFlashSale || (p.originalPrice && p.originalPrice > p.price)
                                    ? 'bg-amber-500 text-rose-950 border-amber-400'
                                    : 'bg-stone-100 text-stone-600 border-stone-200 hover:bg-stone-200'
                                }`}
                                title="ডিসকাউন্ট স্লাইডারে অন/অফ করুন"
                              >
                                <Flame size={11} />
                                <span>{p.isFlashSale || (p.originalPrice && p.originalPrice > p.price) ? 'অফার স্লাইডারে আছে' : '+ অফারে দিন'}</span>
                              </button>
                            </div>
                            <p className="text-[10px] text-stone-500">{p.fabricBn}</p>
                          </div>

                          <div className="flex items-center justify-between pt-2 border-t border-stone-100">
                            <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${p.inStock ? 'bg-emerald-100 text-emerald-800' : 'bg-red-100 text-red-800'}`}>
                              {p.inStock ? (lang === 'bn' ? 'স্টকে আছে' : 'In Stock') : (lang === 'bn' ? 'স্টক আউট' : 'Out of Stock')}
                            </span>
                            <div className="flex items-center gap-1">
                              <button
                                onClick={() => {
                                  setBoostModalProduct(p);
                                  setIsAdsManagerOpen(true);
                                }}
                                className="p-1.5 text-blue-600 hover:text-blue-800 hover:bg-blue-50 rounded-lg transition-colors cursor-pointer"
                                title="ফেসবুক বুস্ট ও Order now লিংক জেনারেটর"
                              >
                                <Rocket size={14} />
                              </button>
                              <button
                                onClick={() => setEditingProduct(p)}
                                className="p-1.5 text-stone-600 hover:text-amber-800 hover:bg-amber-100 rounded-lg transition-colors cursor-pointer"
                                title="প্রডাক্ট তথ্য ও ছবি এডিট করুন"
                              >
                                <Edit3 size={14} />
                              </button>
                              <button
                                onClick={() => {
                                  if (confirm(lang === 'bn' ? 'আপনি কি এই প্রডাক্টটি মুছে ফেলতে চান?' : 'Are you sure you want to delete this product?')) {
                                    onDeleteProduct(p.id);
                                  }
                                }}
                                className="p-1.5 text-stone-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors cursor-pointer"
                                title="Delete Product"
                              >
                                <Trash2 size={14} />
                              </button>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* TAB 4: ADD NEW PRODUCT FORM */}
              {activeTab === 'add_product' && (
                <form onSubmit={handleCreateProduct} className="bg-white rounded-3xl p-6 border border-stone-200 shadow-sm space-y-4 max-w-2xl mx-auto">
                  <div className="border-b border-stone-100 pb-3">
                    <h4 className="font-serif font-bold text-base text-rose-950 flex items-center gap-2">
                      <PackagePlus size={20} className="text-emerald-700" />
                      <span>{lang === 'bn' ? 'ওয়েবসাইটে নতুন প্রডাক্ট যোগ করার ফরম' : 'Add New Product to Store'}</span>
                    </h4>
                    <p className="text-xs text-stone-500">
                      {lang === 'bn' ? 'মোবাইল/কম্পিউটার থেকে ছবি দিয়ে সরাসরি প্রডাক্ট এড করুন (লিংক লাগবে না)' : 'Upload product pictures directly without needing links'}
                    </p>
                  </div>

                  {/* DIRECT PHOTO UPLOAD BOX */}
                  <div className="p-4 bg-amber-50/70 rounded-2xl border-2 border-dashed border-amber-300 space-y-3">
                    <div className="flex items-center justify-between">
                      <label className="block font-extrabold text-stone-800 text-xs flex items-center gap-1.5">
                        <ImagePlus size={18} className="text-rose-900" />
                        <span>{lang === 'bn' ? '১. প্রডাক্টের ছবি আপলোড করুন (ফোন/গ্যালারি থেকে) *' : '1. Select Product Photos (Direct File/Camera) *'}</span>
                      </label>
                      {uploadedImages.length > 0 && (
                        <span className="text-[11px] font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-full">
                          {uploadedImages.length} {lang === 'bn' ? 'টি ছবি যুক্ত হয়েছে' : 'Photos selected'}
                        </span>
                      )}
                    </div>

                    <div className="flex flex-wrap gap-2.5 items-center">
                      <label className="px-4 py-3 bg-rose-950 hover:bg-rose-900 text-amber-300 font-extrabold text-xs rounded-xl cursor-pointer flex items-center gap-2 shadow-md transition-all">
                        <Camera size={18} />
                        <span>{lang === 'bn' ? '📸 গ্যালারি / ক্যামেরা থেকে ছবি সিলেক্ট করুন' : '📸 Pick / Capture Photos'}</span>
                        <input
                          type="file"
                          accept="image/*"
                          multiple
                          onChange={(e) => handleImageFilesUpload(e, false)}
                          className="hidden"
                        />
                      </label>

                      {isUploadingImage && (
                        <span className="text-xs text-amber-900 font-extrabold flex items-center gap-1.5 animate-pulse bg-amber-200/80 px-3 py-2 rounded-xl">
                          <RefreshCw size={15} className="animate-spin text-rose-900" />
                          <span>{lang === 'bn' ? 'ছবি প্রসেস হচ্ছে...' : 'Processing photo...'}</span>
                        </span>
                      )}
                    </div>

                    {/* Previews */}
                    {uploadedImages.length > 0 ? (
                      <div className="space-y-1.5 pt-1">
                        <p className="text-[10px] text-stone-600 font-bold">
                          {lang === 'bn' ? 'আপলোড করা ছবিগুলো (কভার পিক বানাতে ছবিতে ক্লিক করুন):' : 'Uploaded photos (Click photo to set cover):'}
                        </p>
                        <div className="grid grid-cols-4 sm:grid-cols-6 gap-2">
                          {uploadedImages.map((imgSrc, idx) => {
                            const isMain = newProd.image === imgSrc || (idx === 0 && !newProd.image);
                            return (
                              <div key={idx} className={`relative group rounded-xl overflow-hidden border-2 aspect-square bg-stone-200 shadow-xs ${
                                isMain ? 'border-amber-500 ring-2 ring-amber-400' : 'border-stone-300'
                              }`}>
                                <img src={imgSrc} alt="" className="w-full h-full object-cover" />
                                {isMain && (
                                  <span className="absolute top-1 left-1 bg-amber-500 text-rose-950 text-[9px] font-black px-1 rounded shadow-xs">
                                    প্রধান ছবি
                                  </span>
                                )}
                                <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 flex flex-col items-center justify-center gap-1 transition-opacity p-1">
                                  {!isMain && (
                                    <button
                                      type="button"
                                      onClick={() => setNewProd({ ...newProd, image: imgSrc })}
                                      className="text-[9px] bg-amber-400 text-rose-950 font-bold px-1.5 py-0.5 rounded cursor-pointer"
                                    >
                                      কভার পিক
                                    </button>
                                  )}
                                  <button
                                    type="button"
                                    onClick={() => {
                                      const filtered = uploadedImages.filter((_, i) => i !== idx);
                                      setUploadedImages(filtered);
                                      if (newProd.image === imgSrc) {
                                        setNewProd({ ...newProd, image: filtered[0] || '' });
                                      }
                                    }}
                                    className="text-red-400 hover:text-red-200 cursor-pointer"
                                    title="মুছে ফেলুন"
                                  >
                                    <Trash2 size={14} />
                                  </button>
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    ) : (
                      <div className="text-[11px] text-stone-600 flex items-center justify-between pt-1">
                        <span>{lang === 'bn' ? '💡 কোনো লিংক লাগবে না! সরাসরি ফোন বা পিসির ছবি সিলেক্ট করুন।' : '💡 Direct photo picker enabled. No URL needed!'}</span>
                        <button
                          type="button"
                          onClick={() => setShowUrlInput(!showUrlInput)}
                          className="text-rose-900 font-bold underline hover:text-rose-700 cursor-pointer text-[11px]"
                        >
                          {showUrlInput ? (lang === 'bn' ? 'লিংক অপশন লুকান' : 'Hide Link Input') : (lang === 'bn' ? 'অথবা লিংক পেস্ট করুন' : 'Or paste URL')}
                        </button>
                      </div>
                    )}

                    {/* Optional URL input fallback */}
                    {showUrlInput && (
                      <div className="pt-2 border-t border-amber-200/60">
                        <label className="block font-bold text-stone-700 mb-1">{lang === 'bn' ? 'ইমেজ লিংক (URL) অপশনাল' : 'Optional Image URL'}</label>
                        <input
                          type="url"
                          value={newProd.image || ''}
                          onChange={(e) => setNewProd({ ...newProd, image: e.target.value })}
                          placeholder="https://images.unsplash.com/..."
                          className="w-full p-2 bg-white border border-stone-300 rounded-xl focus:ring-1 focus:ring-amber-500 focus:outline-none"
                        />
                      </div>
                    )}
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                    <div>
                      <label className="block font-bold text-stone-700 mb-1">{lang === 'bn' ? 'প্রডাক্টের বাংলা নাম *' : 'Product Name (Bengali) *'}</label>
                      <input
                        type="text"
                        required
                        value={newProd.nameBn || ''}
                        onChange={(e) => setNewProd({ ...newProd, nameBn: e.target.value })}
                        placeholder="যেমন: প্রিমিয়াম পিঙ্ক ফ্লোরাল বেবি ফ্রক"
                        className="w-full p-2.5 bg-stone-50 border border-stone-200 rounded-xl focus:ring-1 focus:ring-amber-500 focus:outline-none"
                      />
                    </div>

                    <div>
                      <label className="block font-bold text-stone-700 mb-1">{lang === 'bn' ? 'প্রডাক্টের ইংলিশ নাম' : 'Product Name (English)'}</label>
                      <input
                        type="text"
                        value={newProd.nameEn || ''}
                        onChange={(e) => setNewProd({ ...newProd, nameEn: e.target.value })}
                        placeholder="e.g. Premium Pink Floral Baby Frock"
                        className="w-full p-2.5 bg-stone-50 border border-stone-200 rounded-xl focus:ring-1 focus:ring-amber-500 focus:outline-none"
                      />
                    </div>

                    <div>
                      <label className="block font-bold text-stone-700 mb-1">{lang === 'bn' ? 'ক্যাটাগরি *' : 'Category *'}</label>
                      <select
                        value={newProd.category || 'babydress'}
                        onChange={(e) => setNewProd({ ...newProd, category: e.target.value as CategoryId })}
                        className="w-full p-2.5 bg-stone-50 border border-stone-200 rounded-xl font-bold text-stone-800 focus:outline-none"
                      >
                        <option value="babydress">{lang === 'bn' ? '👗 বেবি ফ্রক ও ড্রেস (Baby Frocks)' : 'Baby Frocks & Dresses'}</option>
                        <option value="babyset">{lang === 'bn' ? '🍼 বেবি রোম্পার ও সেট (Romper & Sets)' : 'Baby Rompers & Sets'}</option>
                        <option value="frock">{lang === 'bn' ? '🎀 পার্টি ফ্রক ও গাউন (Party Frocks)' : 'Party Frocks & Gowns'}</option>
                        <option value="combo">{lang === 'bn' ? '🎁 মেগা কম্বো প্যাকেজ (Mega Combo Package)' : 'Mega Combo Package'}</option>
                        <option value="panjabi">{lang === 'bn' ? '👔 বয়েজ পাঞ্জাবি ও ফতুয়া (Boys Panjabi)' : 'Boys Panjabi & Fotua'}</option>
                        <option value="footwear">{lang === 'bn' ? '👟 কিউট জুতো ও স্যান্ডেল (Baby Shoes)' : 'Baby Shoes & Footwear'}</option>
                        <option value="accessories">{lang === 'bn' ? '👑 হেয়ার ব্যান্ড ও ক্রাউন (Accessories)' : 'Baby Accessories'}</option>
                        <option value="toys">{lang === 'bn' ? '🧸 খেলনা ও গিফট আইটেম (Toys & Gifts)' : 'Kids Toys & Gifts'}</option>
                      </select>
                    </div>

                    <div>
                      <label className="block font-bold text-stone-700 mb-1">{lang === 'bn' ? 'বিক্রয় মূল্য (টাকা) *' : 'Sale Price (BDT) *'}</label>
                      <input
                        type="number"
                        required
                        value={newProd.price || ''}
                        onChange={(e) => setNewProd({ ...newProd, price: Number(e.target.value) })}
                        placeholder="950"
                        className="w-full p-2.5 bg-stone-50 border border-stone-200 rounded-xl font-bold text-rose-950 focus:ring-1 focus:ring-amber-500 focus:outline-none"
                      />
                    </div>

                    <div>
                      <label className="block font-bold text-stone-700 mb-1">{lang === 'bn' ? 'আগের মূল মূল্য (রেগুলার প্রাইজ)' : 'Original Price'}</label>
                      <input
                        type="number"
                        value={newProd.originalPrice || ''}
                        onChange={(e) => setNewProd({ ...newProd, originalPrice: Number(e.target.value) })}
                        placeholder="1250"
                        className="w-full p-2.5 bg-stone-50 border border-stone-200 rounded-xl focus:ring-1 focus:ring-amber-500 focus:outline-none"
                      />
                    </div>

                    <div>
                      <label className="block font-bold text-stone-700 mb-1">{lang === 'bn' ? 'ফেব্রিক / উপাদান' : 'Fabric Details'}</label>
                      <input
                        type="text"
                        value={newProd.fabricBn || ''}
                        onChange={(e) => setNewProd({ ...newProd, fabricBn: e.target.value })}
                        placeholder="যেমন: ১০০% অরগানিক সফট সুতি কটন"
                        className="w-full p-2.5 bg-stone-50 border border-stone-200 rounded-xl focus:ring-1 focus:ring-amber-500 focus:outline-none"
                      />
                    </div>

                    <div className="sm:col-span-2">
                      <label className="block font-bold text-stone-700 mb-1">{lang === 'bn' ? 'বিবরণ (Description)' : 'Product Description'}</label>
                      <textarea
                        rows={3}
                        value={newProd.descriptionBn || ''}
                        onChange={(e) => setNewProd({ ...newProd, descriptionBn: e.target.value })}
                        placeholder="প্রডাক্টের সৌন্দর্য, নকশা ও ব্যবহারের নিয়ম লিখুন..."
                        className="w-full p-2.5 bg-stone-50 border border-stone-200 rounded-xl focus:ring-1 focus:ring-amber-500 focus:outline-none"
                      />
                    </div>
                  </div>

                  <div className="pt-2 flex justify-end gap-3">
                    <button
                      type="button"
                      onClick={() => setActiveTab('products')}
                      className="px-5 py-2.5 bg-stone-200 hover:bg-stone-300 text-stone-800 font-bold text-xs rounded-xl"
                    >
                      {lang === 'bn' ? 'বাতিল' : 'Cancel'}
                    </button>
                    <button
                      type="submit"
                      className="px-6 py-2.5 bg-rose-950 hover:bg-rose-900 text-amber-300 font-bold text-xs rounded-xl flex items-center gap-1.5 shadow-md cursor-pointer"
                    >
                      <Plus size={16} />
                      <span>{lang === 'bn' ? 'পণ্য পাবলিশ করুন' : 'Publish Product'}</span>
                    </button>
                  </div>
                </form>
              )}

              {/* MODULE 5: DISCOUNTS & MARKETING TOOLS */}
              {(activeTab === 'marketing' || activeTab === 'coupons') && (
                <div className="space-y-6 max-w-4xl mx-auto text-xs animate-fade-in">
                  
                  {/* Meta Facebook Carousel & Order Now Ads Tool */}
                  <div className="p-6 bg-gradient-to-r from-blue-900 via-indigo-950 to-slate-900 text-white rounded-3xl border border-blue-400/30 shadow-lg space-y-4">
                    <div className="flex flex-wrap items-center justify-between gap-3 border-b border-blue-800/60 pb-3">
                      <div className="flex items-center gap-3">
                        <div className="p-2.5 bg-blue-600 rounded-2xl text-white font-black shadow-md border border-blue-400">
                          <Rocket size={22} />
                        </div>
                        <div>
                          <h4 className="font-serif font-bold text-base text-blue-100 flex items-center gap-2">
                            <span>ফেসবুক ক্যারোসেল বুস্ট ও "Order now" বাটন অ্যাড জেনারেটর</span>
                            <span className="bg-blue-500 text-white text-[10px] px-2 py-0.5 rounded-full font-bold">Meta Ads</span>
                          </h4>
                          <p className="text-xs text-blue-200/90 mt-0.5">
                            একসাথে ৫ থেকে ১০টি প্রোডাক্ট সিলেক্ট করে প্রতিটিতে বড় নীল "Order now" বাটন সহ বুস্ট করুন
                          </p>
                        </div>
                      </div>

                      <button
                        type="button"
                        onClick={() => {
                          setBoostModalProduct(null);
                          setIsAdsManagerOpen(true);
                        }}
                        className="px-5 py-2.5 bg-blue-500 hover:bg-blue-400 text-white font-black text-xs rounded-xl shadow-xl transition-all flex items-center gap-2 cursor-pointer"
                      >
                        <Rocket size={16} />
                        <span>ক্যারোসেল অ্যাড বিল্ডার খুলুন</span>
                      </button>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1 text-stone-200">
                      <div className="p-3 bg-white/10 rounded-2xl backdrop-blur-xs space-y-1">
                        <span className="font-bold text-blue-300 block text-xs">🎠 মাল্টি-প্রোডাক্ট ক্যারোসেল</span>
                        <p className="text-[11px] text-blue-100 leading-snug">
                          ৫-১০টি ড্রেসের ছবি, নাম ও ডিরেক্ট চেকআউট লিংক ১-ক্লিকে কপি করুন।
                        </p>
                      </div>

                      <div className="p-3 bg-white/10 rounded-2xl backdrop-blur-xs space-y-1">
                        <span className="font-bold text-blue-300 block text-xs">🔘 নীল "Order now" বাটন</span>
                        <p className="text-[11px] text-blue-100 leading-snug">
                          ফেসবুকে পোস্ট বুস্ট বা অ্যাড তৈরি করার সময় Call to action-এ "Order now" সিলেক্ট করার পূর্ণাঙ্গ গাইড।
                        </p>
                      </div>

                      <div className="p-3 bg-white/10 rounded-2xl backdrop-blur-xs space-y-1">
                        <span className="font-bold text-blue-300 block text-xs">🚀 ডিরেক্ট COD চেকআউট</span>
                        <p className="text-[11px] text-blue-100 leading-snug">
                          কাস্টমার ক্লিক করলেই সরাসরি ওয়েবসাইটের ক্যাশ অন ডেলিভারি (COD) অর্ডার পেজ খুলে যাবে।
                        </p>
                      </div>
                    </div>
                  </div>
                  
                  {/* Coupon & Promo Code Generator */}
                  <div className="p-6 bg-white rounded-3xl border border-stone-200 shadow-sm space-y-4">
                    <div className="border-b border-stone-100 pb-3 flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Tag className="text-rose-950" size={20} />
                        <div>
                          <h4 className="font-serif font-bold text-base text-stone-900">
                            {lang === 'bn' ? 'ডিসকাউন্ট কুপন ও প্রমো কোড জেনারেটর' : 'Coupon & Promo Code Generator'}
                          </h4>
                          <p className="text-[11px] text-stone-500">
                            {lang === 'bn' ? 'নতুন প্রমো কোড তৈরি করুন, পার্সেন্ট বা ফিক্সড ছাড় নির্ধারণ করুন' : 'Create percentage or fixed BDT discount promo codes'}
                          </p>
                        </div>
                      </div>
                    </div>

                    {/* New Coupon Creation Form */}
                    <form onSubmit={handleAddCoupon} className="p-4 bg-stone-50 rounded-2xl border border-stone-200 space-y-3">
                      <h5 className="font-bold text-stone-900 text-xs">{lang === 'bn' ? '+ নতুন প্রমো কোড তৈরি করুন:' : '+ Create New Promo Code:'}</h5>
                      <div className="grid grid-cols-1 sm:grid-cols-4 gap-2.5">
                        <div>
                          <label className="block text-[10px] font-bold text-stone-600 mb-0.5">কুপন কোড (Promo Code)</label>
                          <input
                            type="text"
                            required
                            placeholder="e.g. EID2026"
                            value={newCoupon.code}
                            onChange={(e) => setNewCoupon({ ...newCoupon, code: e.target.value })}
                            className="w-full px-3 py-2 bg-white border border-stone-300 rounded-xl font-mono font-bold text-rose-950 uppercase"
                          />
                        </div>

                        <div>
                          <label className="block text-[10px] font-bold text-stone-600 mb-0.5">ছাড়ের ধরন (Type)</label>
                          <select
                            value={newCoupon.type}
                            onChange={(e) => setNewCoupon({ ...newCoupon, type: e.target.value as any })}
                            className="w-full px-3 py-2 bg-white border border-stone-300 rounded-xl font-bold text-stone-800"
                          >
                            <option value="percent">শতাংশ ছাড় (%)</option>
                            <option value="fixed">নির্দিষ্ট টাকা ছাড় (৳ BDT)</option>
                          </select>
                        </div>

                        <div>
                          <label className="block text-[10px] font-bold text-stone-600 mb-0.5">ছাড়ের পরিমাণ (Amount)</label>
                          <input
                            type="number"
                            required
                            min="1"
                            value={newCoupon.discountValue}
                            onChange={(e) => setNewCoupon({ ...newCoupon, discountValue: Number(e.target.value) })}
                            className="w-full px-3 py-2 bg-white border border-stone-300 rounded-xl font-bold text-stone-900"
                          />
                        </div>

                        <div>
                          <label className="block text-[10px] font-bold text-stone-600 mb-0.5">সর্বনিম্ন অর্ডার (Min Order ৳)</label>
                          <input
                            type="number"
                            required
                            value={newCoupon.minOrderAmount}
                            onChange={(e) => setNewCoupon({ ...newCoupon, minOrderAmount: Number(e.target.value) })}
                            className="w-full px-3 py-2 bg-white border border-stone-300 rounded-xl font-bold text-stone-900"
                          />
                        </div>
                      </div>

                      <div className="flex justify-end pt-1">
                        <button
                          type="submit"
                          className="px-5 py-2 bg-rose-950 hover:bg-rose-900 text-amber-300 font-extrabold text-xs rounded-xl shadow-md cursor-pointer flex items-center gap-1"
                        >
                          <Plus size={14} />
                          <span>{lang === 'bn' ? 'কুপন এড করুন' : 'Add Promo Coupon'}</span>
                        </button>
                      </div>
                    </form>

                    {/* Coupons Table List */}
                    <div className="space-y-2 pt-2">
                      <h5 className="font-bold text-stone-900 text-xs">{lang === 'bn' ? 'বর্তমান সক্রিয় কুপনসমূহ:' : 'Active Promo Coupons:'}</h5>
                      <div className="space-y-2">
                        {coupons.map(c => (
                          <div key={c.id} className="p-3 bg-stone-50 rounded-2xl border border-stone-200 flex flex-wrap items-center justify-between gap-3">
                            <div className="flex items-center gap-3">
                              <span className="px-3 py-1 bg-amber-100 text-rose-950 border border-amber-300 rounded-xl font-mono font-black text-xs">
                                {c.code}
                              </span>
                              <div>
                                <span className="font-bold text-stone-900">
                                  {c.type === 'percent' ? `${c.discountValue}% ছাড়` : `৳${c.discountValue} ফ্ল্যাট ছাড়`}
                                </span>
                                <span className="text-[10px] text-stone-500 block">
                                  সর্বনিম্ন অর্ডার: ৳{c.minOrderAmount} | ব্যবহৃত হয়েছে: {c.usedCount} বার
                                </span>
                              </div>
                            </div>

                            <div className="flex items-center gap-2">
                              <button
                                onClick={() => toggleCouponActive(c.id)}
                                className={`px-3 py-1 rounded-xl text-[11px] font-bold cursor-pointer transition-colors ${
                                  c.active ? 'bg-emerald-100 text-emerald-900 border border-emerald-300' : 'bg-stone-200 text-stone-700'
                                }`}
                              >
                                {c.active ? 'একটিভ ✅' : 'নিষ্ক্রিয় ⏸️'}
                              </button>
                              <button
                                onClick={() => deleteCoupon(c.id)}
                                className="p-1.5 text-stone-400 hover:text-red-600 rounded-lg cursor-pointer"
                              >
                                <Trash2 size={14} />
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Top Notice Banner & Announcement Manager */}
                  <form onSubmit={(e) => {
                    e.preventDefault();
                    if (onUpdateStoreSettings) {
                      onUpdateStoreSettings(settingsForm);
                      alert(lang === 'bn' ? '✅ ওয়েবসাইট ব্যানার ও ডিসকাউন্ট সফলভাবে আপডেট করা হয়েছে!' : '✅ Banner & Store Offer Updated!');
                    }
                  }} className="p-6 bg-white rounded-3xl border border-stone-200 shadow-sm space-y-4">
                    <div className="border-b border-stone-100 pb-3 flex items-center gap-2">
                      <Megaphone size={20} className="text-amber-600" />
                      <div>
                        <h4 className="font-serif font-bold text-base text-stone-900">
                          {lang === 'bn' ? 'ওয়েবসাইট টপ নোটিশ ব্যানার ও অফার হেডার' : 'Top Notice Banner & Homepage Announcement'}
                        </h4>
                        <p className="text-[11px] text-stone-500">
                          {lang === 'bn' ? 'ওয়েবসাইটের একদম শীর্ষে অফার ব্যানার এবং হোমপেজ টেক্সট পরিবর্তন করুন' : 'Update top notification strip text'}
                        </p>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="block text-stone-800 font-bold mb-1">টপ ব্যানার নোটিশ (বাংলা)</label>
                        <input
                          type="text"
                          value={settingsForm.announcementBn}
                          onChange={(e) => setSettingsForm({ ...settingsForm, announcementBn: e.target.value, topAnnouncementBn: e.target.value })}
                          className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl font-medium text-stone-900"
                        />
                      </div>
                      <div>
                        <label className="block text-stone-800 font-bold mb-1">Top Banner Notice (English)</label>
                        <input
                          type="text"
                          value={settingsForm.announcementEn}
                          onChange={(e) => setSettingsForm({ ...settingsForm, announcementEn: e.target.value, topAnnouncementEn: e.target.value })}
                          className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl font-medium text-stone-900"
                        />
                      </div>
                    </div>

                    <div className="pt-2 flex justify-end">
                      <button
                        type="submit"
                        className="px-5 py-2 bg-rose-950 hover:bg-rose-900 text-amber-300 font-extrabold text-xs rounded-xl shadow-md cursor-pointer flex items-center gap-1"
                      >
                        <CheckCircle2 size={14} />
                        <span>{lang === 'bn' ? 'ব্যানার আপডেট করুন' : 'Update Banner Text'}</span>
                      </button>
                    </div>
                  </form>

                  {/* Facebook Pixel & Ad Boosting */}
                  <div className="p-6 bg-gradient-to-r from-blue-900 via-indigo-950 to-rose-950 text-white rounded-3xl border border-blue-400/30 shadow-lg space-y-4">
                    <div className="flex items-center justify-between border-b border-blue-400/20 pb-3">
                      <div className="flex items-center gap-2 font-serif font-bold text-base text-blue-100">
                        <Rocket size={20} className="text-amber-400" />
                        <span>{lang === 'bn' ? 'ফেসবুক এড বুস্টিং ও মেটা পিক্সেল ইন্টিগ্রেশন' : 'Facebook Ad Boost & Meta Pixel'}</span>
                      </div>
                      <span className="px-2 py-0.5 bg-emerald-500 text-slate-950 font-mono text-[10px] font-black rounded-full uppercase">
                        Pixel Live
                      </span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 items-end">
                      <div className="sm:col-span-2">
                        <label className="block text-xs font-bold text-blue-200 mb-1">Meta Pixel ID (Dataset Code)</label>
                        <input
                          type="text"
                          value={fbPixelId}
                          onChange={(e) => setFbPixelId(e.target.value)}
                          placeholder="4595345874045944"
                          className="w-full px-3 py-2 bg-slate-900/80 border border-blue-400/40 rounded-xl font-mono text-sm text-blue-100"
                        />
                      </div>
                      <button
                        type="button"
                        onClick={(e) => handleSavePixel(e as any)}
                        className="w-full py-2 bg-blue-500 hover:bg-blue-600 text-white font-bold text-xs rounded-xl cursor-pointer"
                      >
                        পিক্সেল সেভ করুন
                      </button>
                    </div>
                  </div>

                </div>
              )}

              {/* MODULE 6: STORE SETTINGS & ADMIN ROLES */}
              {activeTab === 'settings' && (
                <div className="space-y-6 max-w-4xl mx-auto text-xs animate-fade-in">
                  
                  {/* Store Details Settings Form */}
                  <form onSubmit={(e) => {
                    e.preventDefault();
                    if (onUpdateStoreSettings) {
                      onUpdateStoreSettings(settingsForm);
                      alert(lang === 'bn' ? '✅ শপের ব্যবসার বিবরণ ও পেমেন্ট সেটিংস সেভ করা হয়েছে!' : '✅ Store settings updated successfully!');
                    }
                  }} className="p-6 bg-white rounded-3xl border border-stone-200 shadow-sm space-y-4">
                    
                    <div className="border-b border-stone-100 pb-3 flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Building2 size={20} className="text-rose-950" />
                        <div>
                          <h4 className="font-serif font-bold text-base text-stone-900">
                            {lang === 'bn' ? 'দোকানের মূল তথ্য ও সাপোর্ট কনট্যাক্ট' : 'Store Business Details & Contact'}
                          </h4>
                          <p className="text-[11px] text-stone-500">
                            {lang === 'bn' ? 'ব্যবসায়িক নাম, অফিসিয়াল কাস্টমার সাপোর্ট ফোন নম্বর ও ঠিকানা' : 'Store name, phone numbers, and physical office address'}
                          </p>
                        </div>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="block font-bold text-stone-800 mb-1">শপের নাম (বাংলা)</label>
                        <input
                          type="text"
                          value={settingsForm.storeNameBn || 'রঙিলা রূপ কিডস'}
                          onChange={(e) => setSettingsForm({ ...settingsForm, storeNameBn: e.target.value })}
                          className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl font-serif font-bold text-stone-900"
                        />
                      </div>

                      <div>
                        <label className="block font-bold text-stone-800 mb-1">Store Name (English)</label>
                        <input
                          type="text"
                          value={settingsForm.storeNameEn || 'Rongila Rup Kids'}
                          onChange={(e) => setSettingsForm({ ...settingsForm, storeNameEn: e.target.value })}
                          className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl font-serif font-bold text-stone-900"
                        />
                      </div>

                      <div>
                        <label className="block font-bold text-stone-800 mb-1">অনলাইন অর্ডার হটলাইন ফোন 📞</label>
                        <input
                          type="text"
                          value={settingsForm.phone || '01792765693'}
                          onChange={(e) => setSettingsForm({ ...settingsForm, phone: e.target.value })}
                          className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl font-mono font-bold text-rose-950"
                        />
                      </div>

                      <div>
                        <label className="block font-bold text-stone-800 mb-1">সাপোর্ট ইমেইল ✉️</label>
                        <input
                          type="email"
                          value={settingsForm.email || 'supportrongilarup@gmail.com'}
                          onChange={(e) => setSettingsForm({ ...settingsForm, email: e.target.value })}
                          className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl font-mono text-stone-900"
                        />
                      </div>

                      <div className="sm:col-span-2">
                        <label className="block font-bold text-stone-800 mb-1">দোকানের অফিসিয়াল ঠিকানা 📍</label>
                        <input
                          type="text"
                          value={settingsForm.addressBn || 'হাউজ ১২, রোড ৫, ধানমন্ডি, ঢাকা ১২০৫'}
                          onChange={(e) => setSettingsForm({ ...settingsForm, addressBn: e.target.value })}
                          className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl font-medium text-stone-900"
                        />
                      </div>
                    </div>

                    {/* Shipping & Delivery Rates */}
                    <div className="pt-3 border-t border-stone-200 space-y-3">
                      <h5 className="font-bold text-stone-900 text-xs flex items-center gap-1.5">
                        <Truck size={16} className="text-amber-700" />
                        <span>{lang === 'bn' ? 'কুরিয়ার ডেলিভারি চার্জ নির্ধারণ (BDT):' : 'Shipping & Delivery Rates Configuration:'}</span>
                      </h5>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div>
                          <label className="block text-[11px] font-bold text-stone-700 mb-1">ঢাকা সিটির ভেতরে (Inside Dhaka ৳)</label>
                          <input
                            type="number"
                            value={settingsForm.shippingInsideDhaka || 80}
                            onChange={(e) => setSettingsForm({ ...settingsForm, shippingInsideDhaka: Number(e.target.value) })}
                            className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl font-mono font-bold text-rose-950"
                          />
                        </div>
                        <div>
                          <label className="block text-[11px] font-bold text-stone-700 mb-1">ঢাকার বাইরে সারাদেশে (Outside Dhaka ৳)</label>
                          <input
                            type="number"
                            value={settingsForm.shippingOutsideDhaka || 150}
                            onChange={(e) => setSettingsForm({ ...settingsForm, shippingOutsideDhaka: Number(e.target.value) })}
                            className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl font-mono font-bold text-rose-950"
                          />
                        </div>
                      </div>
                    </div>

                    {/* Payment Gateways (bKash, Nagad, Rocket, COD) */}
                    <div className="pt-3 border-t border-stone-200 space-y-3">
                      <h5 className="font-bold text-stone-900 text-xs flex items-center gap-1.5">
                        <DollarSign size={16} className="text-emerald-700" />
                        <span>{lang === 'bn' ? 'মোবাইল ব্যাংকিং পেমেন্ট নম্বর ও গেটওয়ে সেটিংস:' : 'Payment Methods Configuration:'}</span>
                      </h5>
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                        <div>
                          <label className="block text-[11px] font-bold text-stone-700 mb-1">bKash Personal / Merchant No.</label>
                          <input
                            type="text"
                            value={settingsForm.bkashNumber || '01792765693'}
                            onChange={(e) => setSettingsForm({ ...settingsForm, bkashNumber: e.target.value })}
                            className="w-full px-3 py-2 bg-pink-50 border border-pink-300 rounded-xl font-mono font-bold text-pink-900"
                          />
                        </div>
                        <div>
                          <label className="block text-[11px] font-bold text-stone-700 mb-1">Nagad Personal No.</label>
                          <input
                            type="text"
                            value={settingsForm.nagadNumber || '01792765693'}
                            onChange={(e) => setSettingsForm({ ...settingsForm, nagadNumber: e.target.value })}
                            className="w-full px-3 py-2 bg-orange-50 border border-orange-300 rounded-xl font-mono font-bold text-orange-900"
                          />
                        </div>
                        <div>
                          <label className="block text-[11px] font-bold text-stone-700 mb-1">Rocket Account No.</label>
                          <input
                            type="text"
                            value={settingsForm.rocketNumber || '01792765693'}
                            onChange={(e) => setSettingsForm({ ...settingsForm, rocketNumber: e.target.value })}
                            className="w-full px-3 py-2 bg-purple-50 border border-purple-300 rounded-xl font-mono font-bold text-purple-900"
                          />
                        </div>
                      </div>
                    </div>

                    <div className="pt-2 flex justify-end">
                      <button
                        type="submit"
                        className="px-6 py-2.5 bg-rose-950 hover:bg-rose-900 text-amber-300 font-extrabold text-xs rounded-xl shadow-md cursor-pointer flex items-center gap-1.5"
                      >
                        <CheckCircle2 size={16} />
                        <span>{lang === 'bn' ? 'সকল তথ্য সেভ করুন' : 'Save All Settings'}</span>
                      </button>
                    </div>
                  </form>

                  {/* Admin Roles & Permissions Management */}
                  <div className="p-6 bg-white rounded-3xl border border-stone-200 shadow-sm space-y-4">
                    <div className="border-b border-stone-100 pb-3 flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <ShieldCheck size={20} className="text-amber-700" />
                        <div>
                          <h4 className="font-serif font-bold text-base text-stone-900">
                            {lang === 'bn' ? 'এডমিন স্টাফ ইউজার ও পারমিশন রোলস' : 'Admin Staff Roles & Access Control'}
                          </h4>
                          <p className="text-[11px] text-stone-500">
                            {lang === 'bn' ? 'দোকানের ম্যানেজার, স্টক এডিটর ও স্টাফদের সিকিউরিটি রোলস' : 'Manage store admins, managers, and staff permissions'}
                          </p>
                        </div>
                      </div>
                    </div>

                    {/* Add New Staff Form */}
                    <form onSubmit={handleAddAdminUser} className="p-4 bg-stone-50 rounded-2xl border border-stone-200 space-y-3">
                      <h5 className="font-bold text-stone-900 text-xs">{lang === 'bn' ? '+ নতুন এডমিন স্টাফ যুক্ত করুন:' : '+ Add New Admin User:'}</h5>
                      <div className="grid grid-cols-1 sm:grid-cols-4 gap-2">
                        <input
                          type="text"
                          required
                          placeholder="নাম (Name)"
                          value={newAdmin.name}
                          onChange={(e) => setNewAdmin({ ...newAdmin, name: e.target.value })}
                          className="px-3 py-2 bg-white border border-stone-300 rounded-xl text-xs text-stone-900"
                        />
                        <input
                          type="text"
                          required
                          placeholder="ফোন (Phone)"
                          value={newAdmin.phone}
                          onChange={(e) => setNewAdmin({ ...newAdmin, phone: e.target.value })}
                          className="px-3 py-2 bg-white border border-stone-300 rounded-xl text-xs text-stone-900 font-mono"
                        />
                        <input
                          type="email"
                          placeholder="ইমেইল (Email)"
                          value={newAdmin.email}
                          onChange={(e) => setNewAdmin({ ...newAdmin, email: e.target.value })}
                          className="px-3 py-2 bg-white border border-stone-300 rounded-xl text-xs text-stone-900 font-mono"
                        />
                        <select
                          value={newAdmin.role}
                          onChange={(e) => setNewAdmin({ ...newAdmin, role: e.target.value as any })}
                          className="px-3 py-2 bg-white border border-stone-300 rounded-xl text-xs font-bold text-stone-900"
                        >
                          <option value="Super Admin">Super Admin (পূর্ণ ক্ষমতা)</option>
                          <option value="Store Manager">Store Manager (ম্যানেজার)</option>
                          <option value="Order Specialist">Order Specialist (অর্ডার ও কুরিয়ার)</option>
                          <option value="Editor">Editor (স্টক ও পণ্য এডিটর)</option>
                        </select>
                      </div>
                      <div className="flex justify-end">
                        <button
                          type="submit"
                          className="px-4 py-2 bg-stone-900 hover:bg-stone-800 text-amber-300 font-bold text-xs rounded-xl cursor-pointer shadow-sm"
                        >
                          + স্টাফ যোগ করুন
                        </button>
                      </div>
                    </form>

                    {/* Staff List */}
                    <div className="space-y-2">
                      {adminUsers.map(u => {
                        const isOwner = u.role === 'Super Admin' || u.phone === OWNER_PHONE || u.email.includes('ataur');
                        return (
                          <div key={u.id} className="p-3 bg-stone-50 rounded-2xl border border-stone-200 flex items-center justify-between gap-3 text-xs">
                            <div>
                              <div className="font-bold text-stone-900 flex items-center gap-2">
                                <span>{u.name}</span>
                                {isOwner && <span title="অনার / মালিক">👑</span>}
                                <span className="px-2 py-0.5 bg-rose-950 text-amber-300 text-[10px] rounded-full font-mono font-bold">
                                  {u.role}
                                </span>
                              </div>
                              <div className="text-[10px] text-stone-500 font-mono mt-0.5">
                                📞 {u.phone} • ✉️ {u.email} • লাস্ট লগইন: {u.lastLogin}
                              </div>
                            </div>

                            <div className="flex items-center gap-2">
                              <span className="px-2.5 py-1 bg-emerald-100 text-emerald-900 text-[10px] font-extrabold rounded-lg border border-emerald-300">
                                {u.status}
                              </span>

                              {isOwner ? (
                                <span className="px-2 py-1 bg-amber-100 text-amber-900 border border-amber-300 text-[10px] font-bold rounded-lg flex items-center gap-1" title="মালিককে রিমুভ করা নিষিদ্ধ">
                                  <Lock size={12} className="text-amber-700" />
                                  <span>রিমুভ নিষিদ্ধ</span>
                                </span>
                              ) : (
                                <button
                                  onClick={() => {
                                    if (confirm(lang === 'bn' ? `আপনি কি ${u.name}-কে রিমুভ করতে চান?` : `Remove ${u.name}?`)) {
                                      const updated = adminUsers.filter(item => item.id !== u.id);
                                      setAdminUsers(updated);
                                      localStorage.setItem('rr_admin_users', JSON.stringify(updated));
                                    }
                                  }}
                                  className="px-2.5 py-1 bg-red-100 hover:bg-red-200 text-red-900 text-[10px] font-bold rounded-lg cursor-pointer transition-colors"
                                >
                                  রিমুভ করুন
                                </button>
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>

                    {/* Official Support Gmail & OTP Sender Configuration */}
                    <div className="p-4 sm:p-5 bg-gradient-to-br from-amber-50/70 via-rose-50/50 to-white rounded-2xl border-2 border-rose-200/80 shadow-xs space-y-4">
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-rose-100 pb-3">
                        <div>
                          <h5 className="font-serif font-bold text-rose-950 text-sm flex items-center gap-2">
                            <Mail size={16} className="text-rose-700" />
                            <span>{lang === 'bn' ? 'অফিসিয়াল সাপোর্ট জিমেইল ও ওটিপি প্রেরক কনফিগারেশন' : 'Official Support Gmail & OTP Sender'}</span>
                          </h5>
                          <p className="text-[11px] text-stone-600 mt-0.5">
                            {lang === 'bn' 
                              ? 'ওয়েবসাইটের অফিসিয়াল সাপোর্ট ও ওটিপি প্রেরক ইমেইল: supportrongilarup@gmail.com'
                              : 'Brand support & OTP sender: supportrongilarup@gmail.com'}
                          </p>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className={`px-2.5 py-1 rounded-full text-[11px] font-bold flex items-center gap-1.5 ${
                            emailConfig.isConfigured 
                              ? 'bg-emerald-100 text-emerald-900 border border-emerald-300' 
                              : 'bg-amber-100 text-amber-900 border border-amber-300 animate-pulse'
                          }`}>
                            <span className={`w-2 h-2 rounded-full ${emailConfig.isConfigured ? 'bg-emerald-600' : 'bg-amber-600'}`} />
                            <span>{emailConfig.isConfigured ? '✅ অফিসিয়াল জিমেইল সক্রিয়' : '⚠️ ব্যাকআপ রিলে সক্রিয়'}</span>
                          </span>
                        </div>
                      </div>

                      {/* Info Alert Box */}
                      <div className={`p-3 rounded-xl text-xs flex items-start gap-2.5 ${
                        emailConfig.isConfigured 
                          ? 'bg-emerald-50 text-emerald-900 border border-emerald-200' 
                          : 'bg-amber-50 text-amber-950 border border-amber-200'
                      }`}>
                        <ShieldCheck size={16} className={`shrink-0 mt-0.5 ${emailConfig.isConfigured ? 'text-emerald-700' : 'text-amber-700'}`} />
                        <div className="space-y-1">
                          <p className="font-medium leading-relaxed">
                            {emailConfig.message || (emailConfig.isConfigured
                              ? 'সকল এডমিন ও কাস্টমার ওটিপি এখন সরাসরি supportrongilarup@gmail.com থেকে প্রেরিত হচ্ছে।'
                              : 'বর্তমানে ব্যাকআপ রিলে (ataurulipur14@gmail.com) চালু রয়েছে। supportrongilarup@gmail.com থেকে ওটিপি পাঠাতে নিচের ঘরে অ্যাপ পাসওয়ার্ড সংরক্ষণ করুন।')}
                          </p>
                          <p className="text-[11px] text-stone-500">
                            সাপোর্ট ও যোগাযোগ ইমেইল: <strong className="font-mono text-rose-950">supportrongilarup@gmail.com</strong>
                          </p>
                        </div>
                      </div>

                      {/* App Password Form */}
                      <form onSubmit={handleSaveEmailConfig} className="space-y-3 bg-white p-3.5 rounded-xl border border-stone-200">
                        <div className="space-y-1.5">
                          <label className="block text-xs font-bold text-stone-800">
                            {lang === 'bn' ? 'supportrongilarup@gmail.com এর ১৬ অক্ষরের গুগল অ্যাপ পাসওয়ার্ড (App Password):' : 'Google App Password (16-chars):'}
                          </label>
                          <div className="relative flex items-center">
                            <input
                              type={showAppPassword ? 'text' : 'password'}
                              value={appPasswordInput}
                              onChange={(e) => setAppPasswordInput(e.target.value)}
                              placeholder="যেমন: abcd efgh ijkl mnop (১৬ অক্ষরের কোড)"
                              className="w-full px-3.5 py-2.5 bg-stone-50 border border-stone-300 rounded-xl text-xs font-mono font-bold text-stone-900 focus:outline-none focus:ring-2 focus:ring-rose-900 pr-10"
                            />
                            <button
                              type="button"
                              onClick={() => setShowAppPassword(!showAppPassword)}
                              className="absolute right-3 text-stone-400 hover:text-stone-600 cursor-pointer"
                              title={showAppPassword ? 'হাইড করুন' : 'দেখুন'}
                            >
                              {showAppPassword ? <EyeOff size={15} /> : <Eye size={15} />}
                            </button>
                          </div>
                          <p className="text-[11px] text-stone-500">
                            💡 গুগল একাউন্টে ২-স্টেপ ভেরিফিকেশন অন করে <strong>Security &gt; 2-Step Verification &gt; App Passwords</strong> এ গিয়ে নতুন অ্যাপ পাসওয়ার্ড তৈরি করুন।
                          </p>
                        </div>

                        {emailFeedback && (
                          <div className={`p-2.5 rounded-lg text-xs font-bold ${
                            emailFeedback.type === 'success' 
                              ? 'bg-emerald-100 text-emerald-900 border border-emerald-300' 
                              : 'bg-rose-100 text-rose-900 border border-rose-300'
                          }`}>
                            {emailFeedback.text}
                          </div>
                        )}

                        <div className="flex items-center gap-2 pt-1 flex-wrap">
                          <button
                            type="submit"
                            disabled={isSavingEmail || !appPasswordInput.trim()}
                            className="px-4 py-2 bg-rose-950 hover:bg-rose-900 text-amber-300 rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-xs cursor-pointer transition-all disabled:opacity-50"
                          >
                            <Save size={14} />
                            <span>{isSavingEmail ? 'যাচাই ও সংরক্ষণ হচ্ছে...' : 'অ্যাপ পাসওয়ার্ড সংরক্ষণ করুন'}</span>
                          </button>

                          <button
                            type="button"
                            onClick={handleTestEmailConfig}
                            disabled={isTestingEmail}
                            className="px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-800 rounded-xl text-xs font-bold flex items-center gap-1.5 border border-stone-300 cursor-pointer transition-all disabled:opacity-50"
                          >
                            <Send size={14} />
                            <span>{isTestingEmail ? 'টেস্ট ইমেইল পাঠানো হচ্ছে...' : '🧪 টেস্ট ইমেইল পাঠান'}</span>
                          </button>
                        </div>
                      </form>
                    </div>

                    {/* Reset Order History & Clear Dashboard Card */}
                    <div className="p-4 sm:p-5 bg-rose-50/60 rounded-2xl border-2 border-rose-200 shadow-xs space-y-3">
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                        <div>
                          <h5 className="font-serif font-bold text-rose-950 text-sm flex items-center gap-2">
                            <Trash2 size={16} className="text-rose-700" />
                            <span>{lang === 'bn' ? 'ড্যাশবোর্ড ও অর্ডার হিস্ট্রি রিসেট কন্ট্রোল' : 'Reset Order History & Clear Dashboard'}</span>
                          </h5>
                          <p className="text-[11px] text-stone-600 mt-0.5">
                            {lang === 'bn'
                              ? 'সকল পরীক্ষামূলক ও পূর্বের অর্ডার ড্যাশবোর্ড থেকে মুছে ফেলে শূন্য (০) থেকে নতুনভাবে শুরু করুন।'
                              : 'Wipe all past orders from dashboard and start fresh from zero.'}
                          </p>
                        </div>

                        <button
                          type="button"
                          onClick={() => setIsClearHistoryModalOpen(true)}
                          className="px-4 py-2 bg-rose-700 hover:bg-rose-800 text-white rounded-xl text-xs font-extrabold flex items-center gap-1.5 shadow-sm transition-transform active:scale-95 cursor-pointer whitespace-nowrap"
                        >
                          <Trash2 size={14} />
                          <span>{lang === 'bn' ? '🗑️ সকল অর্ডার হিস্ট্রি ক্লিয়ার করুন' : 'Clear All Order History'}</span>
                        </button>
                      </div>

                      <div className="text-[11px] text-stone-500 bg-white/80 p-2.5 rounded-xl border border-rose-200/60">
                        ℹ️ <strong>তথ্য:</strong> এটি ক্লিয়ার করলে বর্তমান ড্যাশবোর্ডের অর্ডার সংখ্যা ০ হয়ে যাবে। এর পর ওয়েবসাইট থেকে কাস্টমাররা যত নতুন অর্ডার করবে, সেগুলো ১, ২, ৩ করে ক্রমান্বয়ে স্বয়ংক্রিয়ভাবে তালিকায় যুক্ত হতে থাকবে।
                      </div>
                    </div>

                  </div>

                </div>
              )}

              {/* MODULE 7: CATEGORIES MANAGEMENT */}
              {(activeTab === 'categories') && (
                <div className="space-y-6 max-w-5xl mx-auto text-xs animate-fade-in">
                  <div className="p-6 bg-white rounded-3xl border border-stone-200 shadow-sm space-y-4">
                    <div className="flex items-center justify-between border-b border-stone-100 pb-3">
                      <div>
                        <h4 className="font-serif font-bold text-base text-stone-900">
                          {lang === 'bn' ? 'ক্যাটাগরি কন্ট্রোল' : 'Product Categories'}
                        </h4>
                        <p className="text-[11px] text-stone-500">
                          {lang === 'bn' ? 'শপের প্রধান পোশাক ও এক্সেসরিজ ক্যাটাগরি তালিকা' : 'Manage main store product categories'}
                        </p>
                      </div>
                      <button onClick={() => alert(lang === 'bn' ? 'নতুন ক্যাটাগরি যুক্ত করার ফর্ম তৈরি হচ্ছে' : 'Add new category modal')} className="px-4 py-2 bg-rose-950 text-amber-300 font-bold rounded-xl flex items-center gap-1 cursor-pointer">
                        <PackagePlus size={14} />
                        <span>+ ক্যাটাগরি যুক্ত করুন</span>
                      </button>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                      {[
                        { id: 'combo', nameBn: '🎁 মেগা কম্বো প্যাকেজ', count: products.filter(p => p.category === 'combo').length, icon: '🎁' },
                        { id: 'babydress', nameBn: '👗 বেবি ফ্রক ও ড্রেস (০-৮ বছর)', count: products.filter(p => p.category === 'babydress').length, icon: '👗' },
                        { id: 'babyset', nameBn: '🍼 রোম্পার ও ২-পিস সেট', count: products.filter(p => p.category === 'babyset').length, icon: '🍼' },
                        { id: 'frock', nameBn: '🎀 পার্টি ফ্রক ও গাউন', count: products.filter(p => p.category === 'frock').length, icon: '🎀' },
                        { id: 'panjabi', nameBn: '👔 বয়েজ পাঞ্জাবি ও ফতুয়া', count: products.filter(p => p.category === 'panjabi').length, icon: '👔' },
                        { id: 'footwear', nameBn: '👟 কিউট জুতো ও স্যান্ডেল', count: products.filter(p => p.category === 'footwear').length, icon: '👟' },
                        { id: 'accessories', nameBn: '👑 হেয়ার ব্যান্ড ও ক্রাউন', count: products.filter(p => p.category === 'accessories').length, icon: '👑' },
                        { id: 'toys', nameBn: '🧸 খেলনা ও গিফট আইটেম', count: products.filter(p => p.category === 'toys').length, icon: '🧸' },
                      ].map((cat) => (
                        <div key={cat.id} className="p-4 bg-stone-50 rounded-2xl border border-stone-200 flex items-center justify-between">
                          <div className="flex items-center gap-2.5">
                            <span className="text-2xl">{cat.icon}</span>
                            <div>
                              <h5 className="font-bold text-stone-900">{cat.nameBn}</h5>
                              <span className="text-[10px] text-stone-500">{cat.count} টি আইটেম সক্রিয়</span>
                            </div>
                          </div>
                          <span className="px-2 py-1 bg-emerald-100 text-emerald-800 text-[10px] font-bold rounded-lg">সক্রিয়</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* MODULE 8: PAYMENTS */}
              {(activeTab === 'payments') && (
                <div className="space-y-6 max-w-4xl mx-auto text-xs animate-fade-in">
                  <form onSubmit={(e) => {
                    e.preventDefault();
                    if (onUpdateStoreSettings) onUpdateStoreSettings(settingsForm);
                    alert(lang === 'bn' ? '✅ পেমেন্ট নম্বর ও গেটওয়ে সেটিংস আপডেট করা হয়েছে!' : '✅ Payment gateways saved!');
                  }} className="p-6 bg-white rounded-3xl border border-stone-200 shadow-sm space-y-4">
                    <div className="border-b border-stone-100 pb-3 flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <CreditCard size={20} className="text-amber-600" />
                        <div>
                          <h4 className="font-serif font-bold text-base text-stone-900">
                            {lang === 'bn' ? 'বিকাশ, নগদ, রকেট ও ক্যাশ অন ডেলিভারি পেমেন্ট' : 'bKash, Nagad, Rocket & COD Configuration'}
                          </h4>
                          <p className="text-[11px] text-stone-500">
                            {lang === 'bn' ? 'কাস্টমারদের নিকট থেকে মোবাইল ব্যাংকিং পার্সোনাল/মার্চেন্ট নম্বর পরিবর্তন করুন' : 'Update mobile banking numbers'}
                          </p>
                        </div>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div className="p-4 bg-rose-50/60 rounded-2xl border border-rose-200 space-y-2">
                        <div className="flex items-center justify-between font-bold text-rose-950">
                          <span>💖 বিকাশ (bKash Personal / Merchant)</span>
                          <input type="checkbox" checked={settingsForm.enableBkash} onChange={(e) => setSettingsForm({ ...settingsForm, enableBkash: e.target.checked })} className="w-4 h-4 accent-rose-900 cursor-pointer" />
                        </div>
                        <input type="text" value={settingsForm.bkashNumber} onChange={(e) => setSettingsForm({ ...settingsForm, bkashNumber: e.target.value })} className="w-full px-3 py-2 bg-white border border-rose-300 rounded-xl font-mono text-sm font-bold text-stone-900" />
                      </div>

                      <div className="p-4 bg-amber-50/60 rounded-2xl border border-amber-200 space-y-2">
                        <div className="flex items-center justify-between font-bold text-amber-950">
                          <span>🟠 নগদ (Nagad Mobile Wallet)</span>
                          <input type="checkbox" checked={settingsForm.enableNagad} onChange={(e) => setSettingsForm({ ...settingsForm, enableNagad: e.target.checked })} className="w-4 h-4 accent-amber-600 cursor-pointer" />
                        </div>
                        <input type="text" value={settingsForm.nagadNumber} onChange={(e) => setSettingsForm({ ...settingsForm, nagadNumber: e.target.value })} className="w-full px-3 py-2 bg-white border border-amber-300 rounded-xl font-mono text-sm font-bold text-stone-900" />
                      </div>

                      <div className="p-4 bg-purple-50/60 rounded-2xl border border-purple-200 space-y-2">
                        <div className="flex items-center justify-between font-bold text-purple-950">
                          <span>🟣 রকেট (Rocket Banking)</span>
                          <input type="checkbox" checked={settingsForm.enableRocket} onChange={(e) => setSettingsForm({ ...settingsForm, enableRocket: e.target.checked })} className="w-4 h-4 accent-purple-800 cursor-pointer" />
                        </div>
                        <input type="text" value={settingsForm.rocketNumber} onChange={(e) => setSettingsForm({ ...settingsForm, rocketNumber: e.target.value })} className="w-full px-3 py-2 bg-white border border-purple-300 rounded-xl font-mono text-sm font-bold text-stone-900" />
                      </div>

                      <div className="p-4 bg-emerald-50/60 rounded-2xl border border-emerald-200 space-y-2">
                        <div className="flex items-center justify-between font-bold text-emerald-950">
                          <span>📦 ক্যাশ অন ডেলিভারি (Cash on Delivery)</span>
                          <input type="checkbox" checked={settingsForm.enableCOD} onChange={(e) => setSettingsForm({ ...settingsForm, enableCOD: e.target.checked })} className="w-4 h-4 accent-emerald-700 cursor-pointer" />
                        </div>
                        <span className="text-[11px] text-emerald-800 block">পণ্য হাতে পেয়ে পুরো টাকা পরিশোধের অপশন সক্রিয়</span>
                      </div>
                    </div>

                    <div className="pt-2 flex justify-end">
                      <button type="submit" className="px-5 py-2.5 bg-rose-950 text-amber-300 font-extrabold text-xs rounded-xl shadow-md cursor-pointer flex items-center gap-1">
                        <CheckCircle2 size={16} />
                        <span>পেমেন্ট সেটিংস সেভ করুন</span>
                      </button>
                    </div>
                  </form>
                </div>
              )}

              {/* MODULE 9: REFUNDS & RETURN MANAGEMENT */}
              {(activeTab === 'refunds') && (
                <div className="space-y-6 max-w-5xl mx-auto text-xs animate-fade-in">
                  <div className="p-6 bg-white rounded-3xl border border-stone-200 shadow-sm space-y-4">
                    <div className="flex items-center justify-between border-b border-stone-100 pb-3">
                      <div className="flex items-center gap-2">
                        <RotateCcw size={20} className="text-rose-900" />
                        <div>
                          <h4 className="font-serif font-bold text-base text-stone-900">
                            {lang === 'bn' ? 'রিফান্ড ও রিটার্ন রিকোয়েস্ট কন্ট্রোল' : 'Refunds & Returns Management'}
                          </h4>
                          <p className="text-[11px] text-stone-500">
                            {lang === 'bn' ? 'কাস্টমারদের রিটার্ন আবেদন, কারণ ও বিকাশ/নগদ রিফান্ড অনুমোদন করুন' : 'Process customer return & refund requests'}
                          </p>
                        </div>
                      </div>
                      <span className="px-3 py-1 bg-rose-100 text-rose-950 font-bold rounded-full font-mono">
                        {refundsList.length} Requests
                      </span>
                    </div>

                    <div className="overflow-x-auto">
                      <table className="w-full text-left border-collapse">
                        <thead>
                          <tr className="bg-stone-50 text-stone-600 border-b border-stone-200">
                            <th className="p-3 font-bold">রিফান্ড আইডি</th>
                            <th className="p-3 font-bold">অর্ডার নম্বর</th>
                            <th className="p-3 font-bold">কাস্টমার</th>
                            <th className="p-3 font-bold">টাকার পরিমাণ</th>
                            <th className="p-3 font-bold">কারণ</th>
                            <th className="p-3 font-bold">পেমেন্ট মেথড</th>
                            <th className="p-3 font-bold">স্ট্যাটাস</th>
                            <th className="p-3 font-bold text-right">অ্যাকশন</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-stone-100">
                          {refundsList.map((ref) => (
                            <tr key={ref.id} className="hover:bg-stone-50/50">
                              <td className="p-3 font-mono font-bold text-stone-900">{ref.id}</td>
                              <td className="p-3 font-mono text-rose-950 font-bold">{ref.orderId}</td>
                              <td className="p-3">
                                <div className="font-bold text-stone-900">{ref.customerName}</div>
                                <div className="text-[10px] text-stone-500 font-mono">{ref.phone}</div>
                              </td>
                              <td className="p-3 font-mono font-bold text-rose-900">৳{ref.amount}</td>
                              <td className="p-3 text-stone-600 max-w-[200px] truncate" title={ref.reason}>{ref.reason}</td>
                              <td className="p-3 font-mono text-[11px] text-stone-700">{ref.paymentMethod}</td>
                              <td className="p-3">
                                <span className={`px-2 py-0.5 rounded-full font-bold text-[10px] ${
                                  ref.status === 'refunded' ? 'bg-emerald-100 text-emerald-900' :
                                  ref.status === 'approved' ? 'bg-blue-100 text-blue-900' :
                                  'bg-amber-100 text-amber-900'
                                }`}>
                                  {ref.status === 'refunded' ? 'পরিশোধিত' : ref.status === 'approved' ? 'অনুমোদিত' : 'অপেক্ষমান'}
                                </span>
                              </td>
                              <td className="p-3 text-right space-x-1">
                                {ref.status === 'pending' && (
                                  <button onClick={() => {
                                    setRefundsList(prev => prev.map(r => r.id === ref.id ? { ...r, status: 'approved' } : r));
                                    alert(`✅ রিফান্ড ${ref.id} অনুমোদিত হয়েছে!`);
                                  }} className="px-2.5 py-1 bg-blue-600 text-white rounded-lg font-bold text-[10px] cursor-pointer">
                                    অনুমোদন
                                  </button>
                                )}
                                {ref.status === 'approved' && (
                                  <button onClick={() => {
                                    setRefundsList(prev => prev.map(r => r.id === ref.id ? { ...r, status: 'refunded' } : r));
                                    alert(`✅ বিকাশ/নগদে ৳${ref.amount} রিফান্ড কনফার্ম করা হয়েছে!`);
                                  }} className="px-2.5 py-1 bg-emerald-600 text-white rounded-lg font-bold text-[10px] cursor-pointer">
                                    টাকা পাঠান
                                  </button>
                                )}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              )}

              {/* MODULE 10: REVIEWS & RATINGS */}
              {(activeTab === 'reviews') && (
                <div className="space-y-6 max-w-5xl mx-auto text-xs animate-fade-in">
                  <div className="p-6 bg-white rounded-3xl border border-stone-200 shadow-sm space-y-4">
                    <div className="flex items-center justify-between border-b border-stone-100 pb-3">
                      <div className="flex items-center gap-2">
                        <Star size={20} className="text-amber-500 fill-amber-400" />
                        <div>
                          <h4 className="font-serif font-bold text-base text-stone-900">
                            {lang === 'bn' ? 'কাস্টমার রিভিউ ও রেটিং মডারেশন' : 'Customer Reviews & Feedback'}
                          </h4>
                          <p className="text-[11px] text-stone-500">
                            {lang === 'bn' ? 'পণ্যভিত্তিক কাস্টমারদের মতামত যাচাই ও ওয়েবসাইটে প্রদর্শন কন্ট্রোল' : 'Moderate reviews and customer feedback'}
                          </p>
                        </div>
                      </div>
                      <span className="px-3 py-1 bg-amber-100 text-amber-950 font-bold rounded-full font-mono">
                        গড় রেটিং 4.9 ★
                      </span>
                    </div>

                    <div className="space-y-3">
                      {reviewsList.map((rev) => (
                        <div key={rev.id} className="p-4 bg-stone-50 rounded-2xl border border-stone-200 space-y-2">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <span className="font-bold text-stone-900 text-sm">{rev.customerName}</span>
                              {rev.verified && (
                                <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 text-[9px] font-bold rounded-md">
                                  ✓ ভেরিফাইড ক্রেতা
                                </span>
                              )}
                              <span className="text-[10px] text-stone-400 font-mono">• {rev.date}</span>
                            </div>
                            <div className="flex items-center gap-1 text-amber-500">
                              {Array.from({ length: Math.min(5, Math.max(1, Math.floor(rev.rating || 5))) }).map((_, i) => (
                                <Star key={i} size={14} className="fill-amber-400 text-amber-400" />
                              ))}
                            </div>
                          </div>

                          <div className="font-bold text-rose-950 text-xs">
                            পণ্য: {rev.productName}
                          </div>

                          <p className="text-stone-700 text-[11px] leading-relaxed">
                            "{rev.comment}"
                          </p>

                          <div className="flex items-center justify-between pt-2 border-t border-stone-200/60">
                            <span className={`text-[10px] font-bold ${rev.status === 'approved' ? 'text-emerald-700' : 'text-amber-700'}`}>
                              {rev.status === 'approved' ? '● লাইভ ওয়েবসাইটে প্রদর্শিত' : '● অনুমোদনের অপেক্ষায়'}
                            </span>
                            <div className="flex gap-2">
                              <button onClick={() => {
                                setReviewsList(prev => prev.map(r => r.id === rev.id ? { ...r, status: r.status === 'approved' ? 'pending' : 'approved' } : r));
                              }} className="px-3 py-1 bg-stone-200 hover:bg-stone-300 rounded-lg text-stone-800 font-bold text-[10px] cursor-pointer">
                                {rev.status === 'approved' ? 'লুকিয়ে রাখুন' : 'অনুমোদন দিন'}
                              </button>
                              <button onClick={() => {
                                const reply = prompt('রিভিউতে উত্তর লিখুন (Reply to customer):');
                                if (reply) alert('✅ কাস্টমারকে উত্তর পাঠানো হয়েছে!');
                              }} className="px-3 py-1 bg-rose-950 text-amber-300 rounded-lg font-bold text-[10px] cursor-pointer">
                                উত্তর দিন
                              </button>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* MODULE 11: STOCK MANAGEMENT */}
              {(activeTab === 'stock') && (
                <div className="space-y-6 max-w-5xl mx-auto text-xs animate-fade-in">
                  <div className="p-6 bg-white rounded-3xl border border-stone-200 shadow-sm space-y-4">
                    <div className="flex items-center justify-between border-b border-stone-100 pb-3">
                      <div className="flex items-center gap-2">
                        <Box size={20} className="text-stone-900" />
                        <div>
                          <h4 className="font-serif font-bold text-base text-stone-900">
                            {lang === 'bn' ? 'স্টক ও ইনভেন্টরি কন্ট্রোল' : 'Stock & Inventory Management'}
                          </h4>
                          <p className="text-[11px] text-stone-500">
                            {lang === 'bn' ? 'প্রতিটি পোশাকের বর্তমান ইনভেন্টরি, সাইজ স্টক ও লো-স্টক এলার্ট' : 'Manage real-time inventory quantity and low-stock alerts'}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="px-3 py-1 bg-stone-100 text-stone-900 font-bold rounded-lg font-mono">
                          মোট পণ্য: {products.length}
                        </span>
                      </div>
                    </div>

                    <div className="overflow-x-auto">
                      <table className="w-full text-left border-collapse">
                        <thead>
                          <tr className="bg-stone-50 text-stone-600 border-b border-stone-200">
                            <th className="p-3 font-bold">পণ্য</th>
                            <th className="p-3 font-bold">ক্যাটাগরি</th>
                            <th className="p-3 font-bold">মূল্য</th>
                            <th className="p-3 font-bold">বর্তমান স্টক</th>
                            <th className="p-3 font-bold">স্ট্যাটাস</th>
                            <th className="p-3 font-bold text-right">স্টক অ্যাডজাস্ট</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-stone-100">
                          {products.map((p) => {
                            const isLowStock = !p.inStock;
                            return (
                              <tr key={p.id} className="hover:bg-stone-50/50">
                                <td className="p-3">
                                  <div className="flex items-center gap-2.5">
                                    <img src={p.image} alt={p.nameBn} className="w-10 h-10 object-cover rounded-lg border border-stone-200" />
                                    <div>
                                      <div className="font-bold text-stone-900">{p.nameBn}</div>
                                      <div className="text-[10px] text-stone-400 font-mono">SKU: {p.id}</div>
                                    </div>
                                  </div>
                                </td>
                                <td className="p-3 text-stone-600">{p.category}</td>
                                <td className="p-3 font-mono font-bold text-rose-950">৳{p.price}</td>
                                <td className="p-3">
                                  <span className="font-mono font-bold text-sm text-stone-900">
                                    {p.inStock ? 'উপলব্ধ (In Stock)' : 'স্টক শেষ (Out of Stock)'}
                                  </span>
                                </td>
                                <td className="p-3">
                                  <span className={`px-2 py-0.5 rounded-full font-bold text-[10px] ${
                                    p.inStock ? 'bg-emerald-100 text-emerald-900' : 'bg-red-100 text-red-900'
                                  }`}>
                                    {p.inStock ? 'ইন স্টক' : 'স্টক আউট'}
                                  </span>
                                </td>
                                <td className="p-3 text-right">
                                  <button onClick={() => {
                                    if (onUpdateProduct) {
                                      onUpdateProduct({ ...p, inStock: !p.inStock });
                                    }
                                  }} className={`px-3 py-1 rounded-lg font-bold text-[10px] cursor-pointer ${
                                    p.inStock ? 'bg-amber-100 hover:bg-amber-200 text-amber-950' : 'bg-emerald-600 hover:bg-emerald-700 text-white'
                                  }`}>
                                    {p.inStock ? 'স্টক আউট করুন' : 'স্টকে যুক্ত করুন'}
                                  </button>
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              )}

              {/* MODULE 12: REPORTS & ANALYTICS */}
              {(activeTab === 'reports') && (
                <div className="space-y-6 max-w-5xl mx-auto text-xs animate-fade-in">
                  <div className="p-6 bg-white rounded-3xl border border-stone-200 shadow-sm space-y-4">
                    <div className="flex items-center justify-between border-b border-stone-100 pb-3">
                      <div className="flex items-center gap-2">
                        <BarChart3 size={20} className="text-rose-950" />
                        <div>
                          <h4 className="font-serif font-bold text-base text-stone-900">
                            {lang === 'bn' ? 'রিপোর্ট ও ব্যবসায়িক অ্যানালিটিক্স' : 'Business Reports & Statements'}
                          </h4>
                          <p className="text-[11px] text-stone-500">
                            {lang === 'bn' ? 'মাসিক বিক্রয় বিবরণী ও পারফরম্যান্স ডাটা এক্সপোর্ট করুন' : 'Export sales reports and monthly revenue trends'}
                          </p>
                        </div>
                      </div>
                      <button onClick={() => {
                        const csvContent = "data:text/csv;charset=utf-8," + ["অর্ডার আইডি,কাস্টমার,ফোন,টাকা,স্ট্যাটাস,তারিখ", ...orders.map(o => `${o.id},${o.customerName},${o.phone},${o.totalAmount},${o.status},${o.createdAt}`)].join("\n");
                        const encodedUri = encodeURI(csvContent);
                        const link = document.createElement("a");
                        link.setAttribute("href", encodedUri);
                        link.setAttribute("download", `rongila_rup_sales_report_${Date.now()}.csv`);
                        document.body.appendChild(link);
                        link.click();
                        alert('✅ সেলস রিপোর্ট CSV ডাউনলোড সম্পন্ন হয়েছে!');
                      }} className="px-4 py-2 bg-stone-900 text-amber-300 font-bold rounded-xl flex items-center gap-1.5 cursor-pointer shadow-sm">
                        <Download size={14} />
                        <span>CSV রিপোর্ট ডাউনলোড</span>
                      </button>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                      <div className="p-4 bg-stone-50 rounded-2xl border border-stone-200 space-y-1">
                        <span className="text-stone-500 text-[11px]">মোট সম্পন্ন ডেলিভারি</span>
                        <div className="font-bold font-mono text-xl text-stone-900">
                          {orders.filter(o => o.status === 'delivered').length} টি
                        </div>
                        <span className="text-[10px] text-emerald-700 font-bold">সফল ডেলিভারি রেট ৯৪%</span>
                      </div>

                      <div className="p-4 bg-stone-50 rounded-2xl border border-stone-200 space-y-1">
                        <span className="text-stone-500 text-[11px]">গড় অর্ডার ভ্যালু (AOV)</span>
                        <div className="font-bold font-mono text-xl text-stone-900">
                          ৳{orders.length > 0 ? Math.round(orders.reduce((s, o) => s + o.totalAmount, 0) / orders.length) : 0}
                        </div>
                        <span className="text-[10px] text-stone-500 font-mono">প্রতি অর্ডারে গড় আয়</span>
                      </div>

                      <div className="p-4 bg-stone-50 rounded-2xl border border-stone-200 space-y-1">
                        <span className="text-stone-500 text-[11px]">রিটার্ন / ক্যান্সেলেশন রেট</span>
                        <div className="font-bold font-mono text-xl text-stone-900">
                          {orders.length > 0 ? ((orders.filter(o => o.status === 'cancelled').length / orders.length) * 100).toFixed(1) : 0}%
                        </div>
                        <span className="text-[10px] text-stone-500">নিয়ন্ত্রণে রয়েছে</span>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* MODULE 13: CUSTOMIZABLE SALES ANALYTICS & REVENUE REPORTS */}
              {(activeTab === 'sales_analytics') && (() => {
                const dayNamesBn = ['রবিবার', 'সোমবার', 'মঙ্গলবার', 'বুধবার', 'বৃহস্পতিবার', 'শুক্রবার', 'শনিবার'];
                const shortDaysBn = ['রবি', 'সোম', 'মঙ্গল', 'বুধ', 'বৃহঃ', 'শুক্র', 'শনি'];

                // Group dateFilteredOrders by YYYY-MM-DD
                const dailyMap: { [dateKey: string]: { dateStr: string; orders: typeof orders; deliveredRev: number; deliveredCount: number; returnCount: number; courierLoss: number; totalCount: number } } = {};

                // Sort filtered orders chronologically
                const sortedFilteredOrders = [...dateFilteredOrders].sort((a, b) => {
                  return parseOrderDate(a.createdAt).getTime() - parseOrderDate(b.createdAt).getTime();
                });

                sortedFilteredOrders.forEach(o => {
                  const d = parseOrderDate(o.createdAt);
                  const y = d.getFullYear();
                  const m = String(d.getMonth() + 1).padStart(2, '0');
                  const day = String(d.getDate()).padStart(2, '0');
                  const key = `${y}-${m}-${day}`;

                  if (!dailyMap[key]) {
                    dailyMap[key] = {
                      dateStr: key,
                      orders: [],
                      deliveredRev: 0,
                      deliveredCount: 0,
                      returnCount: 0,
                      courierLoss: 0,
                      totalCount: 0
                    };
                  }

                  dailyMap[key].orders.push(o);
                  dailyMap[key].totalCount += 1;
                  if (o.status === 'delivered') {
                    dailyMap[key].deliveredRev += Number(o.totalAmount) || 0;
                    dailyMap[key].deliveredCount += 1;
                  }
                  if (o.status === 'cancelled' || (o.status as string) === 'returned') {
                    dailyMap[key].returnCount += 1;
                    dailyMap[key].courierLoss += Number(o.shippingFee) || 120;
                  }
                });

                // Convert map to array sorted by date
                let dailyStats = Object.values(dailyMap);

                // If no orders found in selected range, show informative empty or fallback
                const maxOrdersInDay = Math.max(...dailyStats.map(d => d.totalCount), 1);

                return (
                  <div className="space-y-6 max-w-6xl mx-auto text-xs animate-fade-in">
                    {/* Top Custom Filter Control Card */}
                    <div className="p-6 bg-white rounded-3xl border border-stone-200 shadow-sm space-y-5">
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-stone-100 pb-4">
                        <div className="flex items-center gap-3">
                          <div className="p-2.5 bg-emerald-100 text-emerald-800 rounded-2xl">
                            <TrendingUp size={24} />
                          </div>
                          <div>
                            <h4 className="font-serif font-bold text-lg text-stone-900 flex items-center gap-2">
                              <span>{lang === 'bn' ? 'কাস্টম সেলস ও ইনকাম অ্যানালিটিক্স' : 'Custom Sales & Revenue Analytics'}</span>
                              <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-900 font-bold font-mono">
                                REAL-TIME
                              </span>
                            </h4>
                            <p className="text-[11px] text-stone-500">
                              {lang === 'bn' 
                                ? 'যেকোনো মাস, শুরুর তারিখ ও শেষের তারিখ অনুযায়ী সম্পূর্ণ কাস্টমাইজড বিক্রয় ও রিটার্ন ক্ষতি হিসাব' 
                                : 'Accurate sales & return losses filtered by custom month or date range'}
                            </p>
                          </div>
                        </div>

                        {/* Export CSV for current filtered range */}
                        <button 
                          onClick={() => {
                            const headers = "অর্ডার আইডি,তারিখ,কাস্টমার,মোবাইল,পণ্যসংখ্যা,মোট টাকা,স্ট্যাটাস,পেমেন্ট মেথড";
                            const rows = dateFilteredOrders.map(o => {
                              const d = parseOrderDate(o.createdAt);
                              const dateStr = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
                              return `${o.id},"${dateStr}","${o.customerName}","${o.phone}",${(o.items || []).length},${o.totalAmount},${o.status},${o.paymentMethod || 'COD'}`;
                            });
                            const csvContent = "data:text/csv;charset=utf-8,\uFEFF" + [headers, ...rows].join("\n");
                            const encodedUri = encodeURI(csvContent);
                            const link = document.createElement("a");
                            link.setAttribute("href", encodedUri);
                            link.setAttribute("download", `rongila_rup_sales_${salesDatePreset}_${Date.now()}.csv`);
                            document.body.appendChild(link);
                            link.click();
                            alert('✅ নির্বাচিত তারিখ অনুযায়ী সেলস রিপোর্ট CSV ডাউনলোড সম্পন্ন হয়েছে!');
                          }} 
                          className="px-4 py-2 bg-stone-900 hover:bg-stone-800 text-amber-300 font-bold rounded-xl flex items-center gap-1.5 cursor-pointer shadow-xs transition-colors self-start sm:self-auto"
                        >
                          <Download size={14} />
                          <span>ফিল্টারকৃত CSV ডাউনলোড</span>
                        </button>
                      </div>

                      {/* Interactive Range Presets & Date Pickers */}
                      <div className="p-4 bg-stone-50 rounded-2xl border border-stone-200 space-y-3">
                        <div className="flex items-center justify-between flex-wrap gap-2">
                          <span className="font-bold text-stone-700 flex items-center gap-1.5">
                            <Calendar size={15} className="text-rose-900" />
                            <span>সময়সীমা সিলেক্ট করুন (Choose Period):</span>
                          </span>

                          <div className="flex items-center gap-1.5 flex-wrap">
                            {[
                              { id: 'all', label: 'সকল সময়' },
                              { id: 'today', label: 'আজকে' },
                              { id: 'yesterday', label: 'গতকাল' },
                              { id: '7days', label: 'গত ৭ দিন' },
                              { id: '30days', label: 'গত ৩০ দিন' },
                              { id: 'this_month', label: 'চলতি মাস' },
                              { id: 'last_month', label: 'গত মাস' },
                              { id: 'by_month', label: 'নির্দিষ্ট মাস' },
                              { id: 'custom', label: 'কাস্টম তারিখ রেঞ্জ' }
                            ].map((p) => (
                              <button
                                key={p.id}
                                onClick={() => setSalesDatePreset(p.id as any)}
                                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                                  salesDatePreset === p.id
                                    ? 'bg-rose-950 text-amber-300 shadow-xs'
                                    : 'bg-white hover:bg-stone-200 text-stone-700 border border-stone-200'
                                }`}
                              >
                                {p.label}
                              </button>
                            ))}
                          </div>
                        </div>

                        {/* If specific month is chosen */}
                        {salesDatePreset === 'by_month' && (
                          <div className="flex items-center gap-3 pt-2 border-t border-stone-200/60 flex-wrap bg-white p-3 rounded-xl">
                            <label className="font-bold text-stone-800 text-xs">মাস নির্বাচন করুন:</label>
                            <input
                              type="month"
                              value={salesSelectedMonth}
                              onChange={(e) => setSalesSelectedMonth(e.target.value)}
                              className="px-3 py-1.5 bg-stone-50 border border-stone-300 text-stone-900 rounded-xl text-xs font-bold font-mono focus:ring-2 focus:ring-rose-950 focus:outline-none"
                            />
                            <span className="text-xs text-stone-500 font-medium">
                              📅 নির্বাচিত মাস: <strong className="text-rose-950 font-bold">{salesSelectedMonth}</strong>
                            </span>
                          </div>
                        )}

                        {/* If custom date range is chosen */}
                        {salesDatePreset === 'custom' && (
                          <div className="flex items-center gap-3 pt-2 border-t border-stone-200/60 flex-wrap bg-white p-3 rounded-xl">
                            <div className="flex items-center gap-1.5">
                              <span className="font-bold text-stone-700 text-xs">শুরুর তারিখ (From):</span>
                              <input
                                type="date"
                                value={salesStartDate}
                                onChange={(e) => setSalesStartDate(e.target.value)}
                                className="px-3 py-1.5 bg-stone-50 border border-stone-300 text-stone-900 rounded-xl text-xs font-bold font-mono focus:ring-2 focus:ring-rose-950 focus:outline-none"
                              />
                            </div>

                            <div className="flex items-center gap-1.5">
                              <span className="font-bold text-stone-700 text-xs">শেষের তারিখ (To):</span>
                              <input
                                type="date"
                                value={salesEndDate}
                                onChange={(e) => setSalesEndDate(e.target.value)}
                                className="px-3 py-1.5 bg-stone-50 border border-stone-300 text-stone-900 rounded-xl text-xs font-bold font-mono focus:ring-2 focus:ring-rose-950 focus:outline-none"
                              />
                            </div>

                            {(salesStartDate || salesEndDate) && (
                              <button
                                onClick={() => {
                                  setSalesStartDate('');
                                  setSalesEndDate('');
                                }}
                                className="text-xs text-rose-700 font-bold hover:underline cursor-pointer ml-2"
                              >
                                তারিখ মুছুন
                              </button>
                            )}
                          </div>
                        )}
                      </div>

                      {/* 4 Essential KPI Cards in Selected Timeframe */}
                      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
                        {/* KPI 1: Delivered Sales Revenue (Delivered Only) */}
                        <div className="p-4 bg-gradient-to-br from-emerald-50 via-white to-emerald-50/30 rounded-2xl border border-emerald-200 shadow-xs space-y-1.5">
                          <div className="flex items-center justify-between">
                            <span className="text-[11px] font-bold text-emerald-800 uppercase tracking-wide">
                              সম্পন্ন ডেলিভারি বিক্রয় (আসল আয়)
                            </span>
                            <div className="w-7 h-7 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold">
                              <DollarSign size={15} />
                            </div>
                          </div>
                          <div className="text-2xl font-serif font-extrabold text-emerald-950">
                            ৳{deliveredSales.toLocaleString()}
                          </div>
                          <p className="text-[10px] text-emerald-700 font-bold flex items-center gap-1">
                            <CheckCircle2 size={12} />
                            <span>{deliveredOrders} টি সফল ডেলিভারি থেকে আয়</span>
                          </p>
                          <p className="text-[9px] text-stone-400">
                            (অর্ডার কনফার্মে নয়, শুধুমাত্র সফল ডেলিভারিতে যোগ হয়)
                          </p>
                        </div>

                        {/* KPI 2: Total Orders & Success Rate */}
                        <div className="p-4 bg-white rounded-2xl border border-stone-200 shadow-xs space-y-1.5">
                          <div className="flex items-center justify-between">
                            <span className="text-[11px] font-bold text-stone-500 uppercase tracking-wide">
                              মোট অর্ডার সংখ্যা
                            </span>
                            <div className="w-7 h-7 rounded-full bg-pink-100 text-pink-600 flex items-center justify-center font-bold">
                              <ShoppingBag size={15} />
                            </div>
                          </div>
                          <div className="text-2xl font-serif font-extrabold text-stone-900">
                            {totalOrders.toLocaleString()} <span className="text-xs font-normal text-stone-500">টি</span>
                          </div>
                          <p className="text-[10px] text-stone-600 font-medium">
                            সফল ডেলিভারি রেট: <strong className="text-emerald-700 font-bold">{totalOrders > 0 ? Math.round((deliveredOrders / totalOrders) * 100) : 0}%</strong>
                          </p>
                          <p className="text-[9px] text-stone-400">
                            গড়ে প্রতি ডেলিভারি: ৳{deliveredOrders > 0 ? Math.round(deliveredSales / deliveredOrders).toLocaleString() : 0}
                          </p>
                        </div>

                        {/* KPI 3: Return & Courier Loss */}
                        <div className="p-4 bg-gradient-to-br from-red-50 via-white to-red-50/30 rounded-2xl border border-red-200 shadow-xs space-y-1.5">
                          <div className="flex items-center justify-between">
                            <span className="text-[11px] font-bold text-red-800 uppercase tracking-wide">
                              রিটার্ন ও কুরিয়ার লস (ক্ষতি)
                            </span>
                            <div className="w-7 h-7 rounded-full bg-red-100 text-red-600 flex items-center justify-center font-bold">
                              <RotateCcw size={15} />
                            </div>
                          </div>
                          <div className="text-2xl font-serif font-extrabold text-red-900">
                            ৳{totalReturnCourierLoss.toLocaleString()}
                          </div>
                          <p className="text-[10px] text-red-700 font-bold flex items-center gap-1">
                            <AlertTriangle size={12} />
                            <span>{returnOrders.length} টি বাতিল/রিটার্ন পার্সেলের কুরিয়ার চার্জ</span>
                          </p>
                          <p className="text-[9px] text-stone-500">
                            ড্রপড পণ্যের মূল্য: ৳{totalReturnedGoodsValue.toLocaleString()}
                          </p>
                        </div>

                        {/* KPI 4: Pending / In-Transit Pipeline */}
                        <div className="p-4 bg-white rounded-2xl border border-stone-200 shadow-xs space-y-1.5">
                          <div className="flex items-center justify-between">
                            <span className="text-[11px] font-bold text-stone-500 uppercase tracking-wide">
                              কুরিয়ার ও প্রসেসিং পাইপলাইন
                            </span>
                            <div className="w-7 h-7 rounded-full bg-amber-100 text-amber-600 flex items-center justify-center font-bold">
                              <Clock size={15} />
                            </div>
                          </div>
                          <div className="text-2xl font-serif font-extrabold text-stone-900">
                            {pendingOrders + confirmedOrders + shippedOrders} <span className="text-xs font-normal text-stone-500">টি</span>
                          </div>
                          <p className="text-[10px] text-amber-800 font-bold">
                            সম্ভাব্য আয়: ৳{pipelineSales.toLocaleString()}
                          </p>
                          <p className="text-[9px] text-stone-400">
                            ডেলিভারি সম্পন্ন হলে আসল বিক্রয়ে যুক্ত হবে
                          </p>
                        </div>
                      </div>

                      {/* Visual Dynamic Bar Chart for Dates in Range */}
                      {dailyStats.length > 0 && (
                        <div className="p-5 bg-stone-950 text-white rounded-2xl space-y-4 shadow-md">
                          <div className="flex items-center justify-between text-xs">
                            <span className="text-stone-300 font-semibold">
                              📊 {lang === 'bn' ? 'তারিখ অনুযায়ী অর্ডার ও ডেলিভারি গ্রাফ:' : 'Date-by-Date Order & Delivery Graph:'}
                            </span>
                            <span className="text-emerald-400 font-bold font-mono bg-emerald-950/60 px-2.5 py-0.5 rounded-full border border-emerald-800">
                              ● {dailyStats.length} টি দিনের রেকর্ড
                            </span>
                          </div>

                          <div className="h-44 flex items-end gap-2 sm:gap-3 pt-6 border-b border-stone-800 pb-3 overflow-x-auto">
                            {dailyStats.map((d, idx) => {
                              const barHeight = Math.max(18, Math.round((d.totalCount / maxOrdersInDay) * 100));
                              const parsedD = new Date(d.dateStr + 'T00:00:00');
                              const dayLabel = shortDaysBn[parsedD.getDay()] || '';

                              return (
                                <div key={idx} className="min-w-[48px] flex-1 flex flex-col items-center gap-2 h-full justify-end group relative cursor-pointer">
                                  {/* Tooltip on hover */}
                                  <div className="opacity-0 group-hover:opacity-100 transition-opacity absolute -top-14 bg-stone-900 text-amber-300 px-3 py-1.5 rounded-lg border border-amber-400/40 text-[10px] whitespace-nowrap shadow-xl z-20 pointer-events-none text-center">
                                    <div className="font-bold">{d.dateStr} ({dayLabel})</div>
                                    <div>মোট: {d.totalCount}টি • ডেলিভারি: {d.deliveredCount}টি</div>
                                    <div className="text-emerald-300 font-bold">আয়: ৳{d.deliveredRev.toLocaleString()}</div>
                                    {d.courierLoss > 0 && <div className="text-red-400">রিটার্ন লস: ৳{d.courierLoss}</div>}
                                  </div>

                                  <span className="text-[10px] font-mono font-extrabold text-amber-300">
                                    {d.totalCount}টি
                                  </span>

                                  <div 
                                    style={{ height: `${barHeight}%` }} 
                                    className="w-full bg-gradient-to-t from-rose-700 via-rose-500 to-amber-400 rounded-t-lg transition-all duration-300 shadow-sm group-hover:brightness-125"
                                  />

                                  <div className="text-center mt-1">
                                    <span className="text-[10px] text-stone-300 font-bold block">{dayLabel}</span>
                                    <span className="text-[9px] text-stone-500 font-mono block">{d.dateStr.slice(5)}</span>
                                  </div>
                                </div>
                              );
                            })}
                          </div>
                        </div>
                      )}

                      {/* Date-by-Date Accurate Breakdown Table */}
                      <div className="space-y-3">
                        <div className="flex items-center justify-between">
                          <h5 className="font-bold text-stone-800 text-xs flex items-center gap-1.5">
                            <span>📋</span>
                            <span>{lang === 'bn' ? 'তারিখ অনুযায়ী সেলস, ডেলিভারি ও রিটার্ন লসের হিসাব তালিকা:' : 'Daily Sales, Delivery & Return Loss Table:'}</span>
                          </h5>
                          <span className="text-[11px] text-stone-500">
                            মোট {dailyStats.length} দিনের ডাটা
                          </span>
                        </div>

                        <div className="overflow-x-auto rounded-2xl border border-stone-200">
                          <table className="w-full text-left text-xs">
                            <thead className="bg-stone-100 text-stone-700 font-bold border-b border-stone-200">
                              <tr>
                                <th className="p-3">তারিখ ও বার</th>
                                <th className="p-3 text-center">মোট অর্ডার</th>
                                <th className="p-3 text-center">ডেলিভারি সম্পন্ন</th>
                                <th className="p-3 text-right">ডেলিভারি বিক্রয় (আসল আয়)</th>
                                <th className="p-3 text-center">রিটার্ন অর্ডার</th>
                                <th className="p-3 text-right">রিটার্ন কুরিয়ার লস</th>
                                <th className="p-3 text-right">নিট ইনকাম</th>
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-stone-100">
                              {dailyStats.length === 0 ? (
                                <tr>
                                  <td colSpan={7} className="p-6 text-center text-stone-400">
                                    নির্বাচিত তারিখ বা মাসে কোনো অর্ডার রেকর্ড পাওয়া যায়নি।
                                  </td>
                                </tr>
                              ) : (
                                dailyStats.map((row, rIdx) => {
                                  const parsedD = new Date(row.dateStr + 'T00:00:00');
                                  const dayName = dayNamesBn[parsedD.getDay()] || '';
                                  const netGain = row.deliveredRev - row.courierLoss;

                                  return (
                                    <tr key={rIdx} className="hover:bg-stone-50 transition-colors">
                                      <td className="p-3">
                                        <div className="font-bold text-stone-900">{row.dateStr}</div>
                                        <div className="text-[10px] text-stone-500">{dayName}</div>
                                      </td>
                                      <td className="p-3 text-center">
                                        <span className="px-2.5 py-1 bg-amber-100 text-amber-950 font-mono font-extrabold rounded-lg border border-amber-300">
                                          {row.totalCount} টি
                                        </span>
                                      </td>
                                      <td className="p-3 text-center">
                                        <span className="px-2.5 py-1 bg-emerald-100 text-emerald-900 font-mono font-bold rounded-lg border border-emerald-300">
                                          {row.deliveredCount} টি
                                        </span>
                                      </td>
                                      <td className="p-3 text-right font-serif font-extrabold text-emerald-900 text-sm">
                                        ৳{row.deliveredRev.toLocaleString()}
                                      </td>
                                      <td className="p-3 text-center">
                                        <span className={`px-2 py-0.5 rounded-full font-bold text-[10px] ${
                                          row.returnCount > 0 ? 'bg-red-100 text-red-800' : 'bg-stone-100 text-stone-500'
                                        }`}>
                                          {row.returnCount} টি
                                        </span>
                                      </td>
                                      <td className="p-3 text-right font-mono font-bold text-red-700">
                                        {row.courierLoss > 0 ? `৳${row.courierLoss.toLocaleString()}` : '—'}
                                      </td>
                                      <td className="p-3 text-right font-serif font-black text-stone-900 text-sm">
                                        ৳{netGain.toLocaleString()}
                                      </td>
                                    </tr>
                                  );
                                })
                              )}
                            </tbody>
                          </table>
                        </div>
                      </div>

                      {/* Orders in this custom date range */}
                      <div className="pt-2 border-t border-stone-200/80 space-y-3">
                        <div className="flex items-center justify-between">
                          <h5 className="font-bold text-stone-800 text-xs flex items-center gap-1.5">
                            <span>📦</span>
                            <span>{lang === 'bn' ? 'নির্বাচিত সময়সীমার সকল অর্ডার তালিকা:' : 'Orders in Selected Date Range:'}</span>
                          </h5>
                          <span className="text-[11px] text-stone-500 font-mono">
                            মোট: {dateFilteredOrders.length} টি অর্ডার
                          </span>
                        </div>

                        <div className="overflow-x-auto rounded-2xl border border-stone-200">
                          <table className="w-full text-left text-xs">
                            <thead className="bg-stone-50 text-stone-700 font-bold border-b border-stone-200">
                              <tr>
                                <th className="p-2.5">অর্ডার আইডি</th>
                                <th className="p-2.5">গ্রাহক ও ফোন</th>
                                <th className="p-2.5">তারিখ</th>
                                <th className="p-2.5">টাকা</th>
                                <th className="p-2.5">পেমেন্ট</th>
                                <th className="p-2.5">স্ট্যাটাস</th>
                                <th className="p-2.5 text-right">একশন</th>
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-stone-100">
                              {dateFilteredOrders.slice(0, 50).map((o) => (
                                <tr key={o.id} className="hover:bg-stone-50">
                                  <td className="p-2.5 font-mono font-bold text-rose-950">#{o.id}</td>
                                  <td className="p-2.5">
                                    <div className="font-bold text-stone-900">{o.customerName}</div>
                                    <div className="text-[10px] text-stone-500 font-mono">{o.phone}</div>
                                  </td>
                                  <td className="p-2.5 text-stone-600 text-[11px]">
                                    {formatSafeDate(o.createdAt)}
                                  </td>
                                  <td className="p-2.5 font-bold font-serif text-stone-900">
                                    ৳{Number(o.totalAmount).toLocaleString()}
                                  </td>
                                  <td className="p-2.5 font-mono text-[11px]">
                                    <span className="px-2 py-0.5 rounded bg-stone-100 text-stone-800 font-bold uppercase">
                                      {o.paymentMethod || 'COD'}
                                    </span>
                                  </td>
                                  <td className="p-2.5">
                                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                                      o.status === 'delivered' ? 'bg-emerald-100 text-emerald-900' :
                                      o.status === 'cancelled' ? 'bg-red-100 text-red-900' :
                                      o.status === 'shipped' ? 'bg-purple-100 text-purple-900' :
                                      'bg-amber-100 text-amber-900'
                                    }`}>
                                      {o.status === 'delivered' ? '✅ ডেলিভারড' :
                                       o.status === 'cancelled' ? '❌ বাতিল' :
                                       o.status === 'shipped' ? '🚚 কুরিয়ারে' : '⏳ প্রসেসিং'}
                                    </span>
                                  </td>
                                  <td className="p-2.5 text-right">
                                    <button
                                      onClick={() => setSelectedOrderDetail(o)}
                                      className="px-2.5 py-1 bg-stone-100 hover:bg-stone-200 text-stone-800 rounded-lg font-bold text-[11px] cursor-pointer"
                                    >
                                      ভিউ
                                    </button>
                                  </td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })()}

              {/* MODULE 14: WEBSITE SETTINGS */}
              {(activeTab === 'website_settings') && (
                <div className="space-y-6 max-w-4xl mx-auto text-xs animate-fade-in">
                  <form onSubmit={(e) => {
                    e.preventDefault();
                    if (onUpdateStoreSettings) onUpdateStoreSettings(settingsForm);
                    alert(lang === 'bn' ? '✅ ওয়েবসাইট সেটিংস সফলভাবে সেভ করা হয়েছে!' : '✅ Website settings saved successfully!');
                  }} className="p-6 bg-white rounded-3xl border border-stone-200 shadow-sm space-y-4">
                    <div className="border-b border-stone-100 pb-3 flex items-center gap-2">
                      <Globe size={20} className="text-rose-950" />
                      <div>
                        <h4 className="font-serif font-bold text-base text-stone-900">
                          {lang === 'bn' ? 'ওয়েবসাইট সাধারণ ও কন্ট্যাক্ট সেটিংস' : 'General Website Settings & Contact Info'}
                        </h4>
                        <p className="text-[11px] text-stone-500">
                          {lang === 'bn' ? 'দোকানের নাম, ঠিকানা, হেল্পলাইন ও ফুটার ইনফরমেশন কনফিগার করুন' : 'Configure store identity, phone hotline and footer details'}
                        </p>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="block font-bold text-stone-800 mb-1">শপের নাম (বাংলা)</label>
                        <input type="text" value={settingsForm.storeNameBn} onChange={(e) => setSettingsForm({ ...settingsForm, storeNameBn: e.target.value })} className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl font-bold text-stone-900" />
                      </div>
                      <div>
                        <label className="block font-bold text-stone-800 mb-1">Store Name (English)</label>
                        <input type="text" value={settingsForm.storeNameEn} onChange={(e) => setSettingsForm({ ...settingsForm, storeNameEn: e.target.value })} className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl font-bold text-stone-900" />
                      </div>
                      <div>
                        <label className="block font-bold text-stone-800 mb-1">হটলাইন মোবাইল নম্বর</label>
                        <input type="text" value={settingsForm.phone} onChange={(e) => setSettingsForm({ ...settingsForm, phone: e.target.value })} className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl font-mono font-bold text-stone-900" />
                      </div>
                      <div>
                        <label className="block font-bold text-stone-800 mb-1">অফিসিয়াল ইমেইল</label>
                        <input type="email" value={settingsForm.email} onChange={(e) => setSettingsForm({ ...settingsForm, email: e.target.value })} className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl font-mono text-stone-900" />
                      </div>
                      <div className="sm:col-span-2">
                        <label className="block font-bold text-stone-800 mb-1">দোকান / ডিসপ্যাচ সেন্টারের ঠিকানা</label>
                        <input type="text" value={settingsForm.addressBn} onChange={(e) => setSettingsForm({ ...settingsForm, addressBn: e.target.value })} className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-stone-900" />
                      </div>
                    </div>

                    <div className="pt-2 flex justify-end">
                      <button type="submit" className="px-6 py-2.5 bg-rose-950 text-amber-300 font-extrabold text-xs rounded-xl shadow-md cursor-pointer flex items-center gap-1">
                        <CheckCircle2 size={16} />
                        <span>সেটিংস সেভ করুন</span>
                      </button>
                    </div>
                  </form>
                </div>
              )}

              {/* MODULE 15: APPEARANCE & THEMES */}
              {(activeTab === 'appearance') && (
                <div className="space-y-6 max-w-4xl mx-auto text-xs animate-fade-in">
                  <div className="p-6 bg-white rounded-3xl border border-stone-200 shadow-sm space-y-4">
                    <div className="border-b border-stone-100 pb-3 flex items-center gap-2">
                      <Palette size={20} className="text-amber-600" />
                      <div>
                        <h4 className="font-serif font-bold text-base text-stone-900">
                          {lang === 'bn' ? 'ওয়েবসাইট অ্যাপিয়ারেন্স ও থিম ডিজাইন' : 'Store Appearance & Color Themes'}
                        </h4>
                        <p className="text-[11px] text-stone-500">
                          {lang === 'bn' ? 'ওয়েবসাইটের রঙের প্যালেট, হেডার স্টাইল ও ফন্ট লেআউট পছন্দ করুন' : 'Customize brand color scheme and theme layout'}
                        </p>
                      </div>
                    </div>

                    <div className="space-y-4">
                      <div>
                        <label className="block font-bold text-stone-800 mb-2">ব্র্যান্ড কালার থিম নির্বাচন:</label>
                        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                          {[
                            { id: 'crimson', name: 'ক্রিমসন বুটিক (Crimson)', hex: '#881337', bg: 'bg-rose-900' },
                            { id: 'emerald', name: 'রয়েল এমারেল্ড (Emerald)', hex: '#065f46', bg: 'bg-emerald-800' },
                            { id: 'ochre', name: 'গোল্ডেন ওকার (Ochre)', hex: '#92400e', bg: 'bg-amber-800' },
                            { id: 'sapphire', name: 'মিডনাইট স্যাফায়ার (Sapphire)', hex: '#1e3a8a', bg: 'bg-blue-900' }
                          ].map((theme) => (
                            <button
                              key={theme.id}
                              type="button"
                              onClick={() => {
                                const newTheme = theme.id as any;
                                setThemeColor(newTheme);
                                setSettingsForm(prev => ({ ...prev, themeColor: newTheme }));
                                if (onUpdateStoreSettings) {
                                  onUpdateStoreSettings({ ...(storeSettings || {}), ...settingsForm, themeColor: newTheme });
                                }
                                localStorage.setItem('rr_theme_color', newTheme);
                                document.documentElement.setAttribute('data-theme', newTheme);
                                document.body.className = `theme-${newTheme}`;
                              }}
                              className={`p-3 rounded-2xl border-2 text-left space-y-1.5 cursor-pointer transition-all ${
                                themeColor === theme.id ? 'border-rose-950 bg-rose-50/50 shadow-sm ring-2 ring-amber-400' : 'border-stone-200 bg-stone-50'
                              }`}
                            >
                              <div className={`w-full h-6 rounded-lg ${theme.bg}`}></div>
                              <span className="font-bold text-stone-900 block text-[11px]">{theme.name}</span>
                            </button>
                          ))}
                        </div>
                      </div>

                      <div className="pt-3 border-t border-stone-100">
                        <label className="block font-bold text-stone-800 mb-2">হেডার ন্যাভিগেশন স্টাইল:</label>
                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                          {[
                            { id: 'classic', title: 'ক্লাসিক বুটিক হেডার', desc: 'লোগো মাঝে, দুইপাশে ন্যাভিগেশন' },
                            { id: 'modern', title: 'মডার্ন স্টোরফ্রন্ট', desc: 'সার্চ বার কেন্দ্রে, স্টিকি হেডার' },
                            { id: 'minimal', title: 'মিনিমালিস্ট ক্লিন', desc: 'কমপ্যাক্ট আইকন ও দ্রুত ব্রাউজিং' }
                          ].map((hdr) => (
                            <div
                              key={hdr.id}
                              onClick={() => setHeaderStyle(hdr.id as any)}
                              className={`p-3 rounded-2xl border-2 cursor-pointer ${
                                headerStyle === hdr.id ? 'border-rose-950 bg-rose-50/40' : 'border-stone-200'
                              }`}
                            >
                              <span className="font-bold text-stone-900 block">{hdr.title}</span>
                              <span className="text-[10px] text-stone-500">{hdr.desc}</span>
                            </div>
                          ))}
                        </div>
                      </div>

                      <div className="pt-2 flex justify-end">
                        <button 
                          type="button"
                          onClick={() => {
                            if (onUpdateStoreSettings) {
                              onUpdateStoreSettings({ ...(storeSettings || {}), ...settingsForm, themeColor });
                            }
                            localStorage.setItem('rr_theme_color', themeColor);
                            document.documentElement.setAttribute('data-theme', themeColor);
                            document.body.className = `theme-${themeColor}`;
                            alert(lang === 'bn' ? '✅ অ্যাপিয়ারেন্স ও থিম কালার সফলভাবে সেভ ও কার্যকর করা হয়েছে!' : '✅ Appearance & theme settings saved successfully!');
                          }} 
                          className="px-5 py-2.5 bg-rose-950 hover:bg-rose-900 text-amber-300 font-extrabold text-xs rounded-xl shadow-md cursor-pointer transition-all"
                        >
                          💾 থিম কনফিগারেশন সেভ করুন
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* MODULE 16: PAGES */}
              {(activeTab === 'pages') && (
                <div className="space-y-6 max-w-5xl mx-auto text-xs animate-fade-in">
                  <div className="p-6 bg-white rounded-3xl border border-stone-200 shadow-sm space-y-4">
                    <div className="flex items-center justify-between border-b border-stone-100 pb-3">
                      <div className="flex items-center gap-2">
                        <FileText size={20} className="text-rose-950" />
                        <div>
                          <h4 className="font-serif font-bold text-base text-stone-900">
                            {lang === 'bn' ? 'স্ট্যাটিক পলিসি পেজ ও কনটেন্ট ম্যানেজার' : 'Policy Pages & Content Editor'}
                          </h4>
                          <p className="text-[11px] text-stone-500">
                            {lang === 'bn' ? 'প্রাইভেসি পলিসি, শর্তাবলী, রিফান্ড পলিসি ও আমাদের সম্পর্কে পেজ এডিট করুন' : 'Edit Privacy, Terms, Refund Policy and About Us content'}
                          </p>
                        </div>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
                      <div className="space-y-2">
                        {Object.entries(pagesContent).map(([slug, pageData]) => {
                          const page = pageData as { title: string; contentBn: string; lastUpdated: string };
                          return (
                            <button
                              key={slug}
                              type="button"
                              onClick={() => setSelectedEditPage(slug)}
                              className={`w-full p-3 text-left rounded-xl font-bold transition-all cursor-pointer ${
                                selectedEditPage === slug ? 'bg-rose-950 text-amber-300 shadow-sm' : 'bg-stone-50 text-stone-700 hover:bg-stone-100'
                              }`}
                            >
                              {page?.title ? page.title.split(' (')[0] : slug}
                            </button>
                          );
                        })}
                      </div>

                      <div className="sm:col-span-3 p-4 bg-stone-50 rounded-2xl border border-stone-200 space-y-3">
                        <h5 className="font-bold text-stone-900 text-sm">
                          {pagesContent[selectedEditPage]?.title || selectedEditPage}
                        </h5>
                        <textarea
                          rows={6}
                          value={pagesContent[selectedEditPage]?.contentBn || ''}
                          onChange={(e) => {
                            const val = e.target.value;
                            setPagesContent(prev => {
                              const existing = prev[selectedEditPage] || { title: selectedEditPage, contentBn: '', lastUpdated: new Date().toISOString().split('T')[0] };
                              return {
                                ...prev,
                                [selectedEditPage]: { ...existing, contentBn: val }
                              };
                            });
                          }}
                          className="w-full p-3 bg-white border border-stone-300 rounded-xl text-stone-900 leading-relaxed font-sans"
                        />
                        <div className="flex justify-end">
                          <button onClick={() => alert('✅ পেজের কনটেন্ট আপডেট সম্পন্ন হয়েছে!')} className="px-5 py-2 bg-rose-950 text-amber-300 font-extrabold text-xs rounded-xl cursor-pointer">
                            পেজ কনটেন্ট সেভ করুন
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* MODULE 17: BLOG POSTS */}
              {(activeTab === 'blog_posts') && (
                <div className="space-y-6 max-w-5xl mx-auto text-xs animate-fade-in">
                  <div className="p-6 bg-white rounded-3xl border border-stone-200 shadow-sm space-y-4">
                    <div className="flex items-center justify-between border-b border-stone-100 pb-3">
                      <div className="flex items-center gap-2">
                        <BookOpen size={20} className="text-amber-700" />
                        <div>
                          <h4 className="font-serif font-bold text-base text-stone-900">
                            {lang === 'bn' ? 'ব্লগ পোস্ট ও ফ্যাশন আর্টিকেল' : 'Blog Posts & Articles'}
                          </h4>
                          <p className="text-[11px] text-stone-500">
                            {lang === 'bn' ? 'বাচ্চাদের ফ্যাশন টিপস ও অভিভাবক গাইড আর্টিকেল ম্যানেজ করুন' : 'Publish kids fashion tips and parenting articles'}
                          </p>
                        </div>
                      </div>
                      <button onClick={() => alert('নতুন ব্লগ লেখার ফর্ম প্রস্তুত!')} className="px-4 py-2 bg-rose-950 text-amber-300 font-bold rounded-xl flex items-center gap-1 cursor-pointer">
                        <Plus size={14} />
                        <span>+ নতুন ব্লগ লিখুন</span>
                      </button>
                    </div>

                    <div className="space-y-3">
                      {blogPostsList.map((blog) => (
                        <div key={blog.id} className="p-3 bg-stone-50 rounded-2xl border border-stone-200 flex items-center justify-between gap-3">
                          <div className="flex items-center gap-3">
                            <img src={blog.image} alt={blog.titleBn} className="w-12 h-12 object-cover rounded-xl border border-stone-200" />
                            <div>
                              <h5 className="font-bold text-stone-900 text-xs">{blog.titleBn}</h5>
                              <div className="text-[10px] text-stone-500 font-mono mt-0.5">
                                লেখক: {blog.author} • {blog.date} • {blog.reads} বার পঠিত
                              </div>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <span className="px-2 py-1 bg-emerald-100 text-emerald-800 font-bold text-[10px] rounded-lg">প্রকাশিত</span>
                            <button onClick={() => alert('পোস্ট সম্পাদনা মোড')} className="px-2.5 py-1 bg-stone-200 text-stone-800 font-bold text-[10px] rounded-lg cursor-pointer">
                              এডিট
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* MODULE 18: BANNERS & SLIDERS */}
              {(activeTab === 'banners') && (
                <div className="space-y-6 max-w-5xl mx-auto text-xs animate-fade-in">
                  <div className="p-6 bg-white rounded-3xl border border-stone-200 shadow-sm space-y-4">
                    <div className="flex items-center justify-between border-b border-stone-100 pb-3">
                      <div className="flex items-center gap-2">
                        <SlidersHorizontal size={20} className="text-rose-950" />
                        <div>
                          <h4 className="font-serif font-bold text-base text-stone-900">
                            {lang === 'bn' ? 'হোমপেজ ব্যানার ও স্লাইডার ম্যানেজার' : 'Hero Banners & Sliders'}
                          </h4>
                          <p className="text-[11px] text-stone-500">
                            {lang === 'bn' ? 'মূল হোমপেজের স্লাইডার ইমেজ, অফার ও হেডলাইন পরিবর্তন করুন' : 'Manage homepage banners, hero sliders and promotions'}
                          </p>
                        </div>
                      </div>
                      <button onClick={() => alert('নতুন ব্যানার আপলোড প্রস্তুত!')} className="px-4 py-2 bg-rose-950 text-amber-300 font-bold rounded-xl flex items-center gap-1 cursor-pointer">
                        <ImagePlus size={14} />
                        <span>+ ব্যানার যুক্ত করুন</span>
                      </button>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      {bannersList.map((bn) => (
                        <div key={bn.id} className="p-3 bg-stone-50 rounded-2xl border border-stone-200 space-y-2">
                          <img src={bn.image} alt={bn.title} className="w-full h-32 object-cover rounded-xl" />
                          <div className="flex items-center justify-between">
                            <div>
                              <h5 className="font-bold text-stone-900">{bn.title}</h5>
                              <p className="text-[10px] text-stone-500">{bn.subtitle}</p>
                            </div>
                            <span className="px-2 py-1 bg-emerald-100 text-emerald-800 text-[10px] font-bold rounded-lg">সক্রিয়</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* MODULE 19: SHIPPING & COURIER LOGISTICS SETTINGS */}
              {(activeTab === 'shipping') && (
                <div className="space-y-6 max-w-4xl mx-auto text-xs animate-fade-in">
                  <form onSubmit={(e) => {
                    e.preventDefault();
                    if (onUpdateStoreSettings) {
                      onUpdateStoreSettings(settingsForm);
                    }
                    alert('✅ শিপিং ও কুরিয়ার ডেলিভারি চার্জ সফলভাবে আপডেট করা হয়েছে!');
                  }} className="p-6 bg-white rounded-3xl border border-stone-200 shadow-sm space-y-5">
                    <div className="border-b border-stone-100 pb-3 flex items-center justify-between">
                      <div className="flex items-center gap-2.5">
                        <div className="p-2 bg-amber-100 text-rose-950 rounded-xl">
                          <Truck size={22} className="text-amber-800" />
                        </div>
                        <div>
                          <h4 className="font-serif font-bold text-base text-stone-900">
                            {lang === 'bn' ? 'শিপিং চার্জ ও কুরিয়ার ইন্টিগ্রেশন সেটিংস' : 'Shipping & Delivery Configuration'}
                          </h4>
                          <p className="text-[11px] text-stone-500">
                            {lang === 'bn' ? 'ঢাকার ভেতরে ও বাইরে ডেলিভারি ফি এবং কুরিয়ার এপিআই কনফিগারেশন' : 'Manage delivery rates and courier API credentials'}
                          </p>
                        </div>
                      </div>
                      <span className="px-3 py-1 bg-emerald-100 text-emerald-900 font-bold rounded-full text-[11px]">
                        সক্রিয় মেথড
                      </span>
                    </div>

                    {/* Standard Delivery Rates */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div className="p-4 bg-stone-50 rounded-2xl border border-stone-200 space-y-2">
                        <label className="block font-extrabold text-stone-900 text-xs flex items-center justify-between">
                          <span>🏙️ ঢাকা সিটির ভেতরে ডেলিভারি চার্জ (টাকা):</span>
                          <span className="text-rose-900 font-mono font-black">৳{settingsForm.shippingInsideDhaka}</span>
                        </label>
                        <input
                          type="number"
                          min={0}
                          step={5}
                          value={settingsForm.shippingInsideDhaka}
                          onChange={(e) => setSettingsForm({ ...settingsForm, shippingInsideDhaka: Number(e.target.value) })}
                          className="w-full px-3.5 py-2.5 bg-white border border-stone-300 rounded-xl font-mono text-sm font-bold text-stone-900 focus:outline-none focus:ring-2 focus:ring-amber-500"
                        />
                        <span className="text-[10px] text-stone-500 block">সাধারণত ২৪-৪৮ ঘণ্টার মধ্যে হোম ডেলিভারি</span>
                      </div>

                      <div className="p-4 bg-stone-50 rounded-2xl border border-stone-200 space-y-2">
                        <label className="block font-extrabold text-stone-900 text-xs flex items-center justify-between">
                          <span>🚚 ঢাকা সিটির বাইরে ডেলিভারি চার্জ (টাকা):</span>
                          <span className="text-rose-900 font-mono font-black">৳{settingsForm.shippingOutsideDhaka}</span>
                        </label>
                        <input
                          type="number"
                          min={0}
                          step={5}
                          value={settingsForm.shippingOutsideDhaka}
                          onChange={(e) => setSettingsForm({ ...settingsForm, shippingOutsideDhaka: Number(e.target.value) })}
                          className="w-full px-3.5 py-2.5 bg-white border border-stone-300 rounded-xl font-mono text-sm font-bold text-stone-900 focus:outline-none focus:ring-2 focus:ring-amber-500"
                        />
                        <span className="text-[10px] text-stone-500 block">সারা বাংলাদেশের ৬৪ জেলায় ২-৩ দিনের মধ্যে হোম ডেলিভারি</span>
                      </div>
                    </div>

                    {/* Courier Integrations */}
                    <div className="space-y-3 pt-2">
                      <h5 className="font-bold text-stone-900 text-xs uppercase tracking-wider text-rose-950">
                        📦 কুরিয়ার সার্ভিস ইন্টিগ্রেশন স্ট্যাটাস:
                      </h5>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div className="p-3.5 bg-white rounded-xl border-2 border-emerald-500/50 flex items-center justify-between shadow-2xs">
                          <div className="flex items-center gap-2.5">
                            <span className="w-3 h-3 rounded-full bg-emerald-500 animate-pulse"></span>
                            <div>
                              <span className="font-extrabold text-stone-900 block">Steadfast Courier API</span>
                              <span className="text-[10px] font-mono text-emerald-700 font-bold">Live Connected</span>
                            </div>
                          </div>
                          <span className="text-[10px] bg-emerald-100 text-emerald-900 font-black px-2 py-0.5 rounded-full">সক্রিয়</span>
                        </div>

                        <div className="p-3.5 bg-white rounded-xl border border-stone-200 flex items-center justify-between">
                          <div className="flex items-center gap-2.5">
                            <span className="w-3 h-3 rounded-full bg-amber-500"></span>
                            <div>
                              <span className="font-extrabold text-stone-900 block">Pathao / RedX Courier</span>
                              <span className="text-[10px] text-stone-500">ম্যানুয়াল বা কাস্টম বুকিং</span>
                            </div>
                          </div>
                          <span className="text-[10px] bg-stone-100 text-stone-700 font-bold px-2 py-0.5 rounded-full">স্ট্যান্ডবাই</span>
                        </div>
                      </div>
                    </div>

                    <div className="pt-3 border-t border-stone-100 flex justify-end">
                      <button
                        type="submit"
                        className="px-6 py-2.5 bg-rose-950 hover:bg-rose-900 text-amber-300 font-extrabold text-xs rounded-xl shadow-md cursor-pointer transition-all"
                      >
                        💾 শিপিং চার্জ পরিবর্তন সেভ করুন
                      </button>
                    </div>
                  </form>
                </div>
              )}

              {/* MODULE 20: TAX & VAT SETTINGS */}
              {(activeTab === 'tax_settings') && (
                <div className="space-y-6 max-w-4xl mx-auto text-xs animate-fade-in">
                  <form onSubmit={(e) => {
                    e.preventDefault();
                    alert('✅ ট্যাক্স ও ভ্যাট সেটিংস সফলভাবে সেভ করা হয়েছে!');
                  }} className="p-6 bg-white rounded-3xl border border-stone-200 shadow-sm space-y-4">
                    <div className="border-b border-stone-100 pb-3 flex items-center gap-2">
                      <DollarSign size={20} className="text-emerald-700" />
                      <div>
                        <h4 className="font-serif font-bold text-base text-stone-900">
                          {lang === 'bn' ? 'ট্যাক্স, ভ্যাট ও সরকারি বিআইএন (BIN) সেটিংস' : 'Tax & VAT Configuration'}
                        </h4>
                        <p className="text-[11px] text-stone-500">
                          {lang === 'bn' ? 'ভ্যাট রেট, ইনভয়েস ভ্যাট শো করা এবং ব্যবসায়িক ট্যাক্স আইডি' : 'Configure VAT rate, BIN registration number and invoice settings'}
                        </p>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="block font-bold text-stone-800 mb-1">ভ্যাট রেট (%)</label>
                        <input type="number" value={taxSettings.vatRate} onChange={(e) => setTaxSettings({ ...taxSettings, vatRate: Number(e.target.value) })} className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl font-mono font-bold text-stone-900" />
                        <span className="text-[10px] text-stone-500">সাধারণত ই-কমার্সে ০% বা ৫% প্রযোজ্য</span>
                      </div>

                      <div>
                        <label className="block font-bold text-stone-800 mb-1">BIN (Business Identification Number)</label>
                        <input type="text" value={taxSettings.binNumber} onChange={(e) => setTaxSettings({ ...taxSettings, binNumber: e.target.value })} className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl font-mono font-bold text-stone-900" />
                      </div>
                    </div>

                    <div className="space-y-2 pt-2 border-t border-stone-100">
                      <label className="flex items-center gap-2 font-bold text-stone-800">
                        <input type="checkbox" checked={taxSettings.isTaxInclusive} onChange={(e) => setTaxSettings({ ...taxSettings, isTaxInclusive: e.target.checked })} className="w-4 h-4 accent-rose-950 cursor-pointer" />
                        <span>পণ্যের মূল্যের সাথে ভ্যাট যুক্ত (Tax Inclusive Pricing)</span>
                      </label>
                      <label className="flex items-center gap-2 font-bold text-stone-800">
                        <input type="checkbox" checked={taxSettings.showBinOnInvoice} onChange={(e) => setTaxSettings({ ...taxSettings, showBinOnInvoice: e.target.checked })} className="w-4 h-4 accent-rose-950 cursor-pointer" />
                        <span>কাস্টমার মেমো ও ইনভয়েসে BIN নাম্বার প্রদর্শন করুন</span>
                      </label>
                    </div>

                    <div className="pt-2 flex justify-end">
                      <button type="submit" className="px-6 py-2.5 bg-rose-950 text-amber-300 font-extrabold text-xs rounded-xl shadow-md cursor-pointer">
                        ট্যাক্স সেটিংস সেভ করুন
                      </button>
                    </div>
                  </form>
                </div>
              )}

              {/* MODULE 20: SEO SETTINGS */}
              {(activeTab === 'seo_settings') && (
                <div className="space-y-6 max-w-4xl mx-auto text-xs animate-fade-in">
                  <form onSubmit={(e) => {
                    e.preventDefault();
                    alert('✅ এসইও মেটাডাটা ও গুগল সার্চ কনসোল সেটিংস আপডেট করা হয়েছে!');
                  }} className="p-6 bg-white rounded-3xl border border-stone-200 shadow-sm space-y-4">
                    <div className="border-b border-stone-100 pb-3 flex items-center gap-2">
                      <Globe size={20} className="text-blue-700" />
                      <div>
                        <h4 className="font-serif font-bold text-base text-stone-900">
                          {lang === 'bn' ? 'সার্চ ইঞ্জিন অপটিমাইজেশন (SEO) সেটিংস' : 'SEO & Meta Tags Configuration'}
                        </h4>
                        <p className="text-[11px] text-stone-500">
                          {lang === 'bn' ? 'গুগল সার্চ র‍্যাংকিং, মেটা টাইটেল, ডেসক্রিপশন ও সোশ্যাল শেয়ার ইমেজ' : 'Configure Google meta tags, OG cards and search indexing'}
                        </p>
                      </div>
                    </div>

                    <div className="space-y-3">
                      <div>
                        <label className="block font-bold text-stone-800 mb-1">হোমপেজ মেটা টাইটেল (Meta Title)</label>
                        <input type="text" value={seoConfig.metaTitle} onChange={(e) => setSeoConfig({ ...seoConfig, metaTitle: e.target.value })} className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl font-bold text-stone-900" />
                      </div>

                      <div>
                        <label className="block font-bold text-stone-800 mb-1">মেটা ডেসক্রিপশন (Meta Description)</label>
                        <textarea rows={2} value={seoConfig.metaDescription} onChange={(e) => setSeoConfig({ ...seoConfig, metaDescription: e.target.value })} className="w-full p-3 bg-stone-50 border border-stone-300 rounded-xl text-stone-900" />
                      </div>

                      <div>
                        <label className="block font-bold text-stone-800 mb-1">ফোকাস কিওয়ার্ডস (Focus Keywords)</label>
                        <input type="text" value={seoConfig.keywords} onChange={(e) => setSeoConfig({ ...seoConfig, keywords: e.target.value })} className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-stone-900 font-mono" />
                      </div>

                      <div>
                        <label className="block font-bold text-stone-800 mb-1">গুগল সার্চ কনসোল ভেরিফিকেশন কোড</label>
                        <input type="text" value={seoConfig.gscVerification} onChange={(e) => setSeoConfig({ ...seoConfig, gscVerification: e.target.value })} className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-stone-900 font-mono text-[11px]" />
                      </div>
                    </div>

                    <div className="pt-2 flex justify-end">
                      <button type="submit" className="px-6 py-2.5 bg-rose-950 text-amber-300 font-extrabold text-xs rounded-xl shadow-md cursor-pointer">
                        SEO মেটা সেভ করুন
                      </button>
                    </div>
                  </form>
                </div>
              )}

              {/* MODULE 21: ADMIN USERS */}
              {(activeTab === 'admin_users') && (
                <div className="space-y-6 max-w-4xl mx-auto text-xs animate-fade-in">
                  <div className="p-6 bg-white rounded-3xl border border-stone-200 shadow-sm space-y-4">
                    <div className="border-b border-stone-100 pb-3 flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Users size={20} className="text-rose-950" />
                        <div>
                          <h4 className="font-serif font-bold text-base text-stone-900">
                            {lang === 'bn' ? 'এডমিন ও স্টাফ ইউজার কন্ট্রোল' : 'Admin Staff & Team Management'}
                          </h4>
                          <p className="text-[11px] text-stone-500">
                            {lang === 'bn' ? 'দোকানের সুপার এডমিন, ম্যানেজার ও স্টাফ টিম তালিকা' : 'Manage registered store admins and staff accounts'}
                          </p>
                        </div>
                      </div>
                    </div>

                    {/* Add New Staff Form */}
                    <form onSubmit={handleAddAdminUser} className="p-4 bg-stone-50 rounded-2xl border border-stone-200 space-y-3">
                      <h5 className="font-bold text-stone-900 text-xs">{lang === 'bn' ? '+ নতুন এডমিন স্টাফ যুক্ত করুন:' : '+ Add New Admin User:'}</h5>
                      <div className="grid grid-cols-1 sm:grid-cols-4 gap-2">
                        <input
                          type="text"
                          required
                          placeholder="নাম (Name)"
                          value={newAdmin.name}
                          onChange={(e) => setNewAdmin({ ...newAdmin, name: e.target.value })}
                          className="px-3 py-2 bg-white border border-stone-300 rounded-xl text-xs text-stone-900"
                        />
                        <input
                          type="text"
                          required
                          placeholder="ফোন (Phone)"
                          value={newAdmin.phone}
                          onChange={(e) => setNewAdmin({ ...newAdmin, phone: e.target.value })}
                          className="px-3 py-2 bg-white border border-stone-300 rounded-xl text-xs text-stone-900 font-mono"
                        />
                        <input
                          type="email"
                          placeholder="ইমেইল (Email)"
                          value={newAdmin.email}
                          onChange={(e) => setNewAdmin({ ...newAdmin, email: e.target.value })}
                          className="px-3 py-2 bg-white border border-stone-300 rounded-xl text-xs text-stone-900 font-mono"
                        />
                        <select
                          value={newAdmin.role}
                          onChange={(e) => setNewAdmin({ ...newAdmin, role: e.target.value as any })}
                          className="px-3 py-2 bg-white border border-stone-300 rounded-xl text-xs font-bold text-stone-900"
                        >
                          <option value="Super Admin">Super Admin (পূর্ণ ক্ষমতা)</option>
                          <option value="Store Manager">Store Manager (ম্যানেজার)</option>
                          <option value="Order Specialist">Order Specialist (অর্ডার ও কুরিয়ার)</option>
                          <option value="Editor">Editor (স্টক ও পণ্য এডিটর)</option>
                        </select>
                      </div>
                      <div className="flex justify-end">
                        <button
                          type="submit"
                          className="px-4 py-2 bg-stone-900 hover:bg-stone-800 text-amber-300 font-bold text-xs rounded-xl cursor-pointer shadow-sm"
                        >
                          + স্টাফ যোগ করুন
                        </button>
                      </div>
                    </form>

                    {/* Staff List */}
                    <div className="space-y-2">
                      {adminUsers.map(u => {
                        const isOwner = u.id === 'u1' || (u.phone === OWNER_PHONE && (u.email.includes('ataur') || u.name.includes('Ataur') || u.name.includes('আতাউর')));
                        return (
                          <div key={u.id} className="p-3 bg-stone-50 rounded-2xl border border-stone-200 flex items-center justify-between gap-3 text-xs">
                            <div>
                              <div className="font-bold text-stone-900 flex items-center gap-2">
                                <span>{u.name}</span>
                                {isOwner && <span title="অনার / প্রধান এডমিন">👑</span>}
                                <span className="px-2 py-0.5 bg-rose-950 text-amber-300 text-[10px] rounded-full font-mono font-bold">
                                  {u.role}
                                </span>
                              </div>
                              <div className="text-[10px] text-stone-500 font-mono mt-0.5">
                                📞 {u.phone} • ✉️ {u.email} • লাস্ট লগইন: {u.lastLogin || 'সক্রিয়'}
                              </div>
                            </div>

                            <div className="flex items-center gap-2">
                              <span className="px-2.5 py-1 bg-emerald-100 text-emerald-900 text-[10px] font-extrabold rounded-lg border border-emerald-300">
                                {u.status}
                              </span>

                              {isOwner ? (
                                <span className="px-2.5 py-1 bg-amber-100 text-amber-900 border border-amber-300 text-[10px] font-bold rounded-lg flex items-center gap-1" title="প্রধান অনারকে রিমুভ করা নিষিদ্ধ">
                                  <Lock size={12} className="text-amber-700" />
                                  <span>প্রধান অনার</span>
                                </span>
                              ) : (
                                <button
                                  type="button"
                                  onClick={() => handleRemoveAdminUser(u.id, u.name)}
                                  className="px-3 py-1.5 bg-rose-100 hover:bg-rose-200 text-rose-900 text-xs font-bold rounded-lg cursor-pointer transition-colors shadow-2xs border border-rose-300 flex items-center gap-1"
                                >
                                  <Trash2 size={12} />
                                  <span>রিমুভ করুন</span>
                                </button>
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>
              )}

              {/* MODULE 22: ROLES & PERMISSIONS */}
              {(activeTab === 'roles_permissions') && (
                <div className="space-y-6 max-w-4xl mx-auto text-xs animate-fade-in">
                  <div className="p-6 bg-white rounded-3xl border border-stone-200 shadow-sm space-y-4">
                    <div className="border-b border-stone-100 pb-3 flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Shield size={20} className="text-rose-950" />
                        <div>
                          <h4 className="font-serif font-bold text-base text-stone-900">
                            {lang === 'bn' ? 'রোলস ও এক্সেস পারমিশন ম্যাট্রিক্স' : 'Role-Based Access Control (RBAC)'}
                          </h4>
                          <p className="text-[11px] text-stone-500">
                            {lang === 'bn' ? 'প্রতিটি পদের জন্য আলাদা ফিচার পারমিশন নির্ধারণ করুন' : 'Assign granular permissions to staff roles'}
                          </p>
                        </div>
                      </div>
                    </div>

                    <div className="space-y-3">
                      {rolesList.map((r) => (
                        <div key={r.id} className="p-4 bg-stone-50 rounded-2xl border border-stone-200 space-y-2">
                          <div className="flex items-center justify-between">
                            <div>
                              <h5 className="font-bold text-stone-900 text-sm">{r.name}</h5>
                              <p className="text-[11px] text-stone-500">{r.desc}</p>
                            </div>
                            <span className="px-2.5 py-1 bg-stone-200 text-stone-800 font-mono font-bold text-[10px] rounded-lg">
                              {r.permissions.length} পারমিশন সক্রিয়
                            </span>
                          </div>

                          <div className="flex flex-wrap gap-1.5 pt-2">
                            {r.permissions.map((perm) => (
                              <span key={perm} className="px-2 py-0.5 bg-rose-100 text-rose-900 text-[10px] font-mono font-bold rounded-md">
                                ✓ {perm}
                              </span>
                            ))}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* MODULE 23: NOTIFICATIONS */}
              {(activeTab === 'notifications') && (
                <div className="space-y-6 max-w-4xl mx-auto text-xs animate-fade-in">
                  <div className="p-6 bg-white rounded-3xl border border-stone-200 shadow-sm space-y-4">
                    <div className="border-b border-stone-100 pb-3 flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Bell size={20} className="text-rose-950" />
                        <div>
                          <h4 className="font-serif font-bold text-base text-stone-900">
                            {lang === 'bn' ? 'রিয়েলটাইম অর্ডার ও সিস্টেম নোটিফিকেশন' : 'System Notifications & Live Order Alerts'}
                          </h4>
                          <p className="text-[11px] text-stone-500">
                            {lang === 'bn' ? 'নতুন অর্ডারের নোটিফিকেশন ও সাউন্ড অ্যালার্ট' : 'Real-time notifications for incoming orders'}
                          </p>
                        </div>
                      </div>
                    </div>

                    <div className="space-y-2">
                      {orders.length === 0 ? (
                        <div className="p-8 text-center text-stone-500 font-mono">
                          কোনো নতুন নোটিফিকেশন পাওয়া যায়নি।
                        </div>
                      ) : (
                        orders.slice(0, 8).map((o) => (
                          <div key={o.id} className="p-3 bg-stone-50 rounded-2xl border border-stone-200 flex items-center justify-between">
                            <div className="flex items-center gap-3">
                              <div className="w-8 h-8 rounded-full bg-rose-100 text-rose-950 font-bold flex items-center justify-center font-mono">
                                🛍️
                              </div>
                              <div>
                                <h5 className="font-bold text-stone-900">নতুন অর্ডার #{o.id} - ৳{o.totalAmount}</h5>
                                <span className="text-[10px] text-stone-500">কাস্টমার: {o.customerName} ({o.phone}) • {o.createdAt}</span>
                              </div>
                            </div>
                            <button onClick={() => setActiveTab('orders')} className="px-3 py-1 bg-amber-500 hover:bg-amber-600 text-rose-950 font-extrabold text-[10px] rounded-lg cursor-pointer">
                              অর্ডার দেখুন
                            </button>
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                </div>
              )}

              {/* MODULE 24: SUPPORT / MESSAGES */}
              {(activeTab === 'messages') && (
                <div className="space-y-6 max-w-4xl mx-auto text-xs animate-fade-in">
                  <div className="p-6 bg-white rounded-3xl border border-stone-200 shadow-sm space-y-4">
                    <div className="border-b border-stone-100 pb-3 flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <MessageSquare size={20} className="text-emerald-700" />
                        <div>
                          <h4 className="font-serif font-bold text-base text-stone-900">
                            {lang === 'bn' ? 'সাপোর্ট ইনবক্স ও কাস্টমার মেসেজ' : 'Customer Support & Inquiries Inbox'}
                          </h4>
                          <p className="text-[11px] text-stone-500">
                            {lang === 'bn' ? 'হোয়াটসঅ্যাপ ও ওয়েবসাইট ফর্ম থেকে আসা কাস্টমার মেসেজ' : 'Direct customer messages and inquiries'}
                          </p>
                        </div>
                      </div>
                    </div>

                    <div className="space-y-3">
                      {supportMessages.map((msg) => (
                        <div key={msg.id} className="p-4 bg-stone-50 rounded-2xl border border-stone-200 space-y-2">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <span className="font-bold text-stone-900">{msg.name}</span>
                              <span className="text-[10px] text-stone-500 font-mono">({msg.phone})</span>
                              <span className="text-[10px] text-stone-400">• {msg.time}</span>
                            </div>
                            <span className={`px-2 py-0.5 rounded-full font-bold text-[9px] ${
                              msg.status === 'unread' ? 'bg-amber-100 text-amber-900' : 'bg-stone-200 text-stone-700'
                            }`}>
                              {msg.status === 'unread' ? 'নতুন বার্তা' : 'সমাধানকৃত'}
                            </span>
                          </div>

                          <p className="text-stone-800 text-[11px] bg-white p-3 rounded-xl border border-stone-100">
                            "{msg.message}"
                          </p>

                          <div className="flex justify-end gap-2 pt-1">
                            <a
                              href={`https://wa.me/88${msg.phone.replace(/[^0-9]/g, '')}?text=${encodeURIComponent('আসসালামু আলাইকুম ' + msg.name + ', রঙিলা রূপ থেকে আপনার মেসেজের উত্তরে যোগাযোগ করছি।')}`}
                              target="_blank"
                              rel="noreferrer"
                              className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl flex items-center gap-1 cursor-pointer"
                            >
                              <span>হোয়াটসঅ্যাপে উত্তর দিন 💬</span>
                            </a>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* MODULE 25: SYSTEM SETTINGS */}
              {(activeTab === 'system_settings') && (
                <div className="space-y-6 max-w-4xl mx-auto text-xs animate-fade-in">
                  <div className="p-6 bg-white rounded-3xl border border-stone-200 shadow-sm space-y-4">
                    <div className="border-b border-stone-100 pb-3 flex items-center gap-2">
                      <Settings size={20} className="text-stone-800" />
                      <div>
                        <h4 className="font-serif font-bold text-base text-stone-900">
                          {lang === 'bn' ? 'সিস্টেম পরিবেশ ও রক্ষণাবেক্ষণ সেটিংস' : 'System Environment & Maintenance'}
                        </h4>
                        <p className="text-[11px] text-stone-500">
                          {lang === 'bn' ? 'টাইমজোন, কারেন্সি সিম্বল, ক্যাশ ক্লিনার ও সিস্টেম ডায়াগনস্টিকস' : 'Configure timezones, currency, cache clearing and system diagnostic info'}
                        </p>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div className="p-4 bg-stone-50 rounded-2xl border border-stone-200 space-y-2">
                        <label className="block font-bold text-stone-800">ডিফল্ট মুদ্রা (Default Currency)</label>
                        <input type="text" disabled value="৳ BDT (টাকা)" className="w-full px-3 py-2 bg-stone-200/60 border border-stone-300 rounded-xl font-bold font-mono text-stone-900" />
                      </div>

                      <div className="p-4 bg-stone-50 rounded-2xl border border-stone-200 space-y-2">
                        <label className="block font-bold text-stone-800">টাইমজোন (Timezone)</label>
                        <input type="text" disabled value="Asia/Dhaka (GMT+6)" className="w-full px-3 py-2 bg-stone-200/60 border border-stone-300 rounded-xl font-mono text-stone-900" />
                      </div>
                    </div>

                    <div className="p-4 bg-stone-50 rounded-2xl border border-stone-200 space-y-3">
                      <h5 className="font-bold text-stone-900">ক্যাশ ও লোকাল স্টোরেজ অপ্টিমাইজেশন</h5>
                      <p className="text-[11px] text-stone-600">
                        ব্রাউজারের পুরানো ডাটা পরিষ্কার করতে বা নতুন আপডেট দ্রুত লোড করতে ক্যাশ রিসেট করুন।
                      </p>
                      <button onClick={() => {
                        alert('✅ সিস্টেম ব্রাউজার ক্যাশ ক্লিয়ার ও রিফ্রেশ সম্পন্ন হয়েছে!');
                      }} className="px-4 py-2 bg-stone-900 text-amber-300 font-bold rounded-xl cursor-pointer">
                        🧹 ক্যাশ ও মেমোরি ক্লিয়ার করুন
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* MODULE 26: BACKUP & RESTORE DATA */}
              {(activeTab === 'backup_restore') && (
                <div className="space-y-6 max-w-4xl mx-auto text-xs animate-fade-in">
                  <div className="p-6 bg-white rounded-3xl border border-stone-200 shadow-sm space-y-4">
                    <div className="border-b border-stone-100 pb-3 flex items-center gap-2">
                      <Database size={20} className="text-rose-950" />
                      <div>
                        <h4 className="font-serif font-bold text-base text-stone-900">
                          {lang === 'bn' ? 'ডাটাবেজ ব্যাকআপ, রিসেট ও রিস্টোর' : 'Database Export, Backup & Restore'}
                        </h4>
                        <p className="text-[11px] text-stone-500">
                          {lang === 'bn' ? 'শপের সকল প্রোডাক্ট, অর্ডার এবং কাস্টমার ডাটা নিরাপদে ব্যাকআপ ফাইল আকারে সংরক্ষণ করুন' : 'Download complete JSON database backup'}
                        </p>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                      <div className="p-5 bg-stone-50 rounded-2xl border border-stone-200 space-y-3">
                        <div className="font-bold text-stone-900 text-sm flex items-center gap-2">
                          <Download size={18} className="text-amber-700" />
                          <span>ডাটাবেজ ডাউনলোড (JSON)</span>
                        </div>
                        <p className="text-[11px] text-stone-600">
                          বর্তমান লাইভ প্রডাক্ট, অর্ডার এবং কাস্টমার তালিকার সকল ডাটা আপনার পিসিতে JSON ব্যাকআপ হিসেবে সেভ করুন।
                        </p>
                        <button onClick={() => {
                          const backupData = { products, orders, settings: storeSettings, exportDate: new Date().toISOString() };
                          const blob = new Blob([JSON.stringify(backupData, null, 2)], { type: 'application/json' });
                          const url = URL.createObjectURL(blob);
                          const a = document.createElement('a');
                          a.href = url;
                          a.download = `rongila_rup_backup_${Date.now()}.json`;
                          a.click();
                          alert('✅ ডাটাবেজ ব্যাকআপ ফাইল ডাউনলোড সম্পূর্ণ হয়েছে!');
                        }} className="px-4 py-2.5 bg-rose-950 text-amber-300 font-extrabold text-xs rounded-xl cursor-pointer shadow-sm w-full">
                          📥 ফুল ডাটা ব্যাকআপ ডাউনলোড
                        </button>
                      </div>

                      <div className="p-5 bg-amber-50/90 rounded-2xl border-2 border-amber-400 space-y-3 shadow-md">
                        <div className="font-bold text-rose-950 text-sm flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <HardDrive size={18} className="text-amber-700" />
                            <span>প্রজেক্ট সোর্স কোড (ZIP File)</span>
                          </div>
                          <span className="text-[10px] bg-amber-200 text-rose-900 font-black px-2 py-0.5 rounded-full">4.9 MB</span>
                        </div>
                        <p className="text-[11px] text-stone-700 leading-relaxed">
                          সম্পূর্ণ রঙিলা রূপ কিডস ওয়েবসাইটের ফুল সোর্স কোড, সব ফাইল এবং এসেট সংবলিত ZIP ফাইল এক ক্লিকে ডাউনলোড করুন।
                        </p>
                        <div className="flex flex-col gap-2 pt-1">
                          <button 
                            type="button"
                            onClick={async () => {
                              try {
                                const response = await fetch('/api/download-zip');
                                if (!response.ok) throw new Error('API download failed');
                                const blob = await response.blob();
                                const url = window.URL.createObjectURL(blob);
                                const a = document.createElement('a');
                                a.href = url;
                                a.download = 'rongila-rup-kids-source.zip';
                                document.body.appendChild(a);
                                a.click();
                                window.URL.revokeObjectURL(url);
                                document.body.removeChild(a);
                              } catch (e) {
                                window.open('/rongila-rup-kids-source.zip', '_blank');
                              }
                            }}
                            className="px-4 py-2.5 bg-gradient-to-r from-amber-500 via-rose-600 to-rose-700 hover:from-amber-400 hover:to-rose-600 text-white font-black text-xs rounded-xl cursor-pointer shadow-md w-full flex items-center justify-center gap-2 transition-all transform active:scale-95"
                          >
                            <Download size={15} />
                            <span>💾 এক ক্লিকে ZIP ডাউনলোড করুন</span>
                          </button>
                          <a 
                            href="/api/download-zip" 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="text-center text-[10px] text-stone-500 hover:text-rose-700 underline block"
                          >
                            বিকল্প লিঙ্ক: সরাসরি নতুন ট্যাবে ডাউনলোড করুন ↗
                          </a>
                        </div>
                      </div>

                      <div className="p-5 bg-stone-50 rounded-2xl border border-stone-200 space-y-3">
                        <div className="font-bold text-stone-900 text-sm flex items-center gap-2">
                          <RotateCcw size={18} className="text-rose-700" />
                          <span>ডাটাবেজ রিসেট (System Clean)</span>
                        </div>
                        <p className="text-[11px] text-stone-600">
                          প্রয়োজনে টেস্ট অর্ডার ডিলিট বা শপ পুনরায় নতুনভাবে ফ্রেশ ডাটা দিয়ে চালু করার অপশন।
                        </p>
                        <button onClick={() => {
                          if (confirm('আপনি কি নিশ্চিত যে টেস্ট ডাটা ক্লিয়ার করতে চান?')) {
                            alert('✅ ডাটাবেজ ক্লিন করা হয়েছে!');
                          }
                        }} className="px-4 py-2.5 bg-stone-200 hover:bg-stone-300 text-stone-800 font-bold text-xs rounded-xl cursor-pointer w-full">
                          🧹 টেস্ট অর্ডারের ডাটা ক্লিন করুন
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              )}

                </AdminErrorBoundary>
              </div>
            </div>
        </>
      )}

    </div>

      {/* STAFF OTP VERIFICATION MODAL */}
      {pendingStaffOtp && (
        <div className="fixed inset-0 z-60 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in">
          <div className="relative w-full max-w-md bg-white rounded-3xl shadow-2xl p-6 border border-amber-500/30 space-y-4">
            <div className="flex items-center justify-between border-b border-stone-200 pb-3">
              <div className="flex items-center gap-2 text-rose-950 font-serif font-bold text-base">
                <ShieldCheck className="text-amber-600" size={20} />
                <span>ম্যানেজার জি-মেইল OTP ভেরিফিকেশন</span>
              </div>
              <button onClick={() => setPendingStaffOtp(null)} className="p-1 hover:bg-stone-100 rounded-full text-stone-500">
                <X size={18} />
              </button>
            </div>

            <div className="p-3 bg-amber-50 border border-amber-200 rounded-2xl text-xs space-y-1">
              <div className="font-bold text-amber-950">
                নতুন স্টাফ: {pendingStaffOtp.newAdminData.name} ({pendingStaffOtp.newAdminData.role})
              </div>
              <div className="text-amber-800 font-mono">
                ✉️ ইমেইল: {pendingStaffOtp.newAdminData.email}
              </div>
            </div>

            <div className="p-3 bg-emerald-50 border border-emerald-300 rounded-2xl text-xs space-y-1 animate-pulse">
              <div className="font-bold text-emerald-950 flex justify-between">
                <span>✉️ জি-মেইলে পাঠানো সিমুলেটেড OTP</span>
                <span className="bg-emerald-700 text-white text-[9px] px-2 py-0.5 rounded-full font-mono font-bold">LIVE OTP</span>
              </div>
              <p className="text-emerald-800 text-[11px]">
                ভেরিফিকেশন OTP কোড: <strong className="font-mono text-base text-stone-900 underline">{pendingStaffOtp.generatedOtp}</strong>
              </p>
            </div>

            <form onSubmit={handleConfirmStaffOtp} className="space-y-3">
              <div>
                <label className="block text-[11px] font-bold text-stone-700 mb-1">
                  জি-মেইলে আসা ৬-ডিজিটের OTP কোড লিখুন:
                </label>
                <input
                  type="text"
                  required
                  maxLength={6}
                  value={staffOtpInput}
                  onChange={(e) => {
                    setStaffOtpInput(e.target.value);
                    setStaffOtpError('');
                  }}
                  placeholder="e.g. 592810"
                  className="w-full px-4 py-3 bg-stone-50 border border-stone-300 rounded-2xl text-center text-xl font-mono font-black text-rose-950 focus:outline-none focus:ring-2 focus:ring-amber-500"
                />
                {staffOtpError && (
                  <p className="text-[11px] font-bold text-red-600 mt-1">{staffOtpError}</p>
                )}
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setPendingStaffOtp(null)}
                  className="px-4 py-2 bg-stone-200 hover:bg-stone-300 text-stone-800 font-bold text-xs rounded-xl"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-rose-950 hover:bg-rose-900 text-amber-300 font-extrabold text-xs rounded-xl shadow-md cursor-pointer"
                >
                  ✓ ভেরিফাই ও অ্যাক্টিভ করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* STAFF ACTIVATION LINK SUCCESS MODAL */}
      {staffInviteModal && (
        <div className="fixed inset-0 z-60 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in">
          <div className="relative w-full max-w-md bg-white rounded-3xl shadow-2xl p-6 border border-amber-500/30 space-y-4">
            <div className="flex items-center justify-between border-b border-stone-200 pb-3">
              <div className="flex items-center gap-2 text-emerald-800 font-serif font-bold text-base">
                <CheckCircle2 size={22} className="text-emerald-600" />
                <span>ম্যানেজার অ্যাকাউন্ট সফলভাবে সক্রিয়!</span>
              </div>
              <button onClick={() => setStaffInviteModal(null)} className="p-1 hover:bg-stone-100 rounded-full text-stone-500">
                <X size={18} />
              </button>
            </div>

            <p className="text-xs text-stone-700 leading-relaxed">
              <strong>{staffInviteModal.name}</strong> ({staffInviteModal.email}) এর জি-মেইল ভেরিফাই করা হয়েছে। নিচের এক্সেস লিঙ্কটি কপি করে তাকে দিন যাতে সে সরাসরি ওয়েবসাইটে কাজ শুরু করতে পারে:
            </p>

            <div className="p-3 bg-stone-100 rounded-2xl border border-stone-300 font-mono text-[11px] text-stone-800 break-all select-all">
              {staffInviteModal.inviteLink}
            </div>

            <div className="flex justify-between items-center pt-2">
              <button
                onClick={() => {
                  navigator.clipboard.writeText(staffInviteModal.inviteLink);
                  alert('✅ ম্যানেজার এক্সেস লিঙ্ক কপি করা হয়েছে!');
                }}
                className="px-4 py-2 bg-amber-500 hover:bg-amber-600 text-rose-950 font-extrabold text-xs rounded-xl flex items-center gap-1.5 shadow-sm cursor-pointer"
              >
                <Copy size={14} />
                <span>লিঙ্ক কপি করুন</span>
              </button>

              <button
                onClick={() => setStaffInviteModal(null)}
                className="px-4 py-2 bg-rose-950 text-amber-300 font-bold text-xs rounded-xl cursor-pointer"
              >
                সম্পন্ন
              </button>
            </div>
          </div>
        </div>
      )}

      {/* COURIER AUTOMATED DISPATCH MODAL */}
      {dispatchingOrder && (
        <div className="fixed inset-0 z-60 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in">
          <div className="relative w-full max-w-md bg-white rounded-3xl shadow-2xl p-6 border border-amber-500/30 space-y-4">
            <div className="flex items-center justify-between border-b border-stone-200 pb-3">
              <div className="flex items-center gap-2 text-rose-950 font-serif font-bold text-base">
                <Truck className="text-amber-600" size={20} />
                <span>{lang === 'bn' ? 'কুরিয়ার অটো এন্ট্রি সিস্টেম' : 'Automated Courier Service Entry'}</span>
              </div>
              <button onClick={() => setDispatchingOrder(null)} className="p-1 hover:bg-stone-100 rounded-full text-stone-500">
                <X size={18} />
              </button>
            </div>

            <div className="p-3 bg-stone-50 rounded-xl border border-stone-200 space-y-1 text-xs">
              <div className="font-bold text-stone-900">
                অর্ডার আইডি: <span className="font-mono text-rose-950">{dispatchingOrder.id}</span>
              </div>
              <div className="text-stone-700">
                কাস্টমার: <strong>{dispatchingOrder.customerName}</strong> ({dispatchingOrder.phone})
              </div>
              <div className="text-stone-600">
                ঠিকানা: {dispatchingOrder.address}, {dispatchingOrder.city}
              </div>
              <div className="flex justify-between items-center text-stone-900 pt-1 border-t border-stone-200">
                <span>সর্বমোট বিল: <strong>৳{dispatchingOrder.totalAmount.toLocaleString()}</strong></span>
                <span className={dispatchCodAmount === 0 ? "text-emerald-700 font-bold" : "text-amber-900 font-bold"}>
                  {dispatchCodAmount === 0 ? "সম্পূর্ণ পেইড (COD ৳০)" : `কুরিয়ার আদায়: ৳${dispatchCodAmount}`}
                </span>
              </div>
            </div>

            {/* Editable COD Collection for Courier Dispatch */}
            <div className="p-3 bg-amber-50/80 rounded-2xl border-2 border-amber-300 space-y-2 text-xs">
              <div className="flex items-center justify-between">
                <label className="font-extrabold text-stone-900 block">
                  {lang === 'bn' ? '💵 কুরিয়ার আদায়যোগ্য টাকা (COD Amount):' : 'COD Amount to Collect:'}
                </label>
                <div className="flex gap-1">
                  <button
                    type="button"
                    onClick={() => setDispatchCodAmount(0)}
                    className={`px-2.5 py-1 text-[11px] font-extrabold rounded-lg transition-all cursor-pointer ${
                      dispatchCodAmount === 0
                        ? 'bg-emerald-700 text-white shadow-xs'
                        : 'bg-white border border-stone-300 text-stone-700 hover:bg-stone-100'
                    }`}
                  >
                    ৳০ (পেইড)
                  </button>
                  <button
                    type="button"
                    onClick={() => setDispatchCodAmount(dispatchingOrder.totalAmount)}
                    className={`px-2.5 py-1 text-[11px] font-bold rounded-lg transition-all cursor-pointer ${
                      dispatchCodAmount === dispatchingOrder.totalAmount
                        ? 'bg-rose-950 text-white shadow-xs'
                        : 'bg-white border border-stone-300 text-stone-700 hover:bg-stone-100'
                    }`}
                  >
                    ৳{dispatchingOrder.totalAmount} (ফুল COD)
                  </button>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <div className="relative flex-1">
                  <span className="absolute left-3 top-2 font-mono font-black text-rose-950 text-sm">৳</span>
                  <input
                    type="number"
                    min={0}
                    value={dispatchCodAmount}
                    onChange={(e) => setDispatchCodAmount(Number(e.target.value))}
                    className="w-full pl-7 pr-3 py-2 bg-white border-2 border-amber-400 rounded-xl font-mono font-black text-rose-950 text-base focus:ring-2 focus:ring-amber-500 focus:outline-none"
                  />
                </div>
              </div>

              {dispatchCodAmount === 0 ? (
                <p className="text-[11px] text-emerald-800 font-bold bg-emerald-100/70 p-1.5 rounded-lg">
                  ✅ কাস্টমার ইতিমধ্যে টাকা পরিশোধ করেছেন। কুরিয়ার রাইডার ডেলিভারির সময় কোনো টাকা নেবে না (COD = ৳০)।
                </p>
              ) : (
                <p className="text-[10px] text-stone-500">
                  *কুরিয়ার ডেলিভারি রাইডার কাস্টমারের কাছ থেকে ঠিক ৳{dispatchCodAmount.toLocaleString()} টাকা আদায় করবে।
                </p>
              )}
            </div>

            <div className="space-y-2 text-xs">
              <label className="block font-bold text-stone-800">
                {lang === 'bn' ? 'কুরিয়ার সার্ভিস নির্বাচন করুন:' : 'Select Courier Service:'}
              </label>

              <div className="grid grid-cols-2 gap-2">
                {[
                  { name: 'Steadfast Courier', desc: 'Fastest 24-48h Delivery' },
                  { name: 'Pathao Courier', desc: 'Nationwide Delivery' },
                  { name: 'RedX Logistics', desc: 'Doorstep Delivery' },
                  { name: 'Paperfly', desc: 'Home Delivery' }
                ].map(c => (
                  <button
                    key={c.name}
                    type="button"
                    onClick={() => setSelectedCourier(c.name as any)}
                    className={`p-3 rounded-2xl border text-left transition-all cursor-pointer ${
                      selectedCourier === c.name 
                        ? 'border-rose-950 bg-rose-50 ring-2 ring-rose-950/20 font-bold' 
                        : 'border-stone-200 hover:border-stone-300'
                    }`}
                  >
                    <div className="text-xs font-bold text-stone-900">{c.name}</div>
                    <div className="text-[10px] text-stone-500">{c.desc}</div>
                  </button>
                ))}
              </div>
            </div>

            {selectedCourier === 'Steadfast Courier' && (
              <div className="p-3 bg-amber-50/70 border border-amber-200 rounded-2xl space-y-2">
                <div className="text-[11px] font-bold text-amber-950 flex items-center justify-between">
                  <span>🔑 Steadfast API Credentials Configuration</span>
                  <span className="text-[9px] bg-amber-200 text-amber-900 px-1.5 py-0.5 rounded font-mono font-bold">Steadfast Live API</span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                  <div>
                    <label className="block text-[10px] font-medium text-stone-600 mb-0.5">Steadfast API Key</label>
                    <input
                      type="text"
                      value={sfApiKey}
                      onChange={(e) => handleUpdateSfApiKey(e.target.value)}
                      placeholder="Steadfast API Key"
                      className="w-full px-2.5 py-1.5 border border-stone-300 rounded-lg font-mono text-[11px] bg-white text-stone-900"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-medium text-stone-600 mb-0.5">Steadfast Secret Key (Console &gt; API Settings)</label>
                    <input
                      type="password"
                      value={sfSecretKey}
                      onChange={(e) => handleUpdateSfSecretKey(e.target.value)}
                      placeholder="Secret Key ইনপুট দিন"
                      className="w-full px-2.5 py-1.5 border border-stone-300 rounded-lg font-mono text-[11px] bg-white text-stone-900"
                    />
                  </div>
                </div>
                <p className="text-[10px] text-amber-800 leading-snug">
                  *আপনার Steadfast Merchant Portal (&gt; API Settings) থেকে API Key ও Secret Key ব্যবহার করে অর্ডার সরাসরি আপনার অ্যাকাউন্ট এন্ট্রি করা হবে।
                </p>
              </div>
            )}

            <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-[11px] text-emerald-900 font-medium space-y-1">
              <div className="flex items-center justify-between font-bold text-emerald-950">
                <span>✨ লাইভ এন্ট্রি তথ্য:</span>
                <span className="px-2 py-0.5 bg-emerald-700 text-white text-[9px] font-mono rounded-full font-bold">
                  Steadfast Live Mode
                </span>
              </div>
              <ul className="list-disc list-inside space-y-0.5">
                <li>সরাসরি স্টিডফাস্ট সার্ভারে পার্সেল বুকিং হবে।</li>
                <li>রেসপন্স ব্যর্থ হলে আসল কারণ ও মেসেজ দেখাবে।</li>
                <li>সফল হলে অরিজিনাল স্টিডফাস্ট ট্র্যাকিং কোড জেনারেট হবে।</li>
              </ul>
            </div>

            <div className="pt-2 flex justify-end gap-2">
              <button
                type="button"
                disabled={isSubmittingCourier}
                onClick={() => setDispatchingOrder(null)}
                className="px-4 py-2 bg-stone-200 text-stone-800 rounded-xl font-bold text-xs"
              >
                বাতিল
              </button>
              <button
                type="button"
                disabled={isSubmittingCourier}
                onClick={handleConfirmCourierEntry}
                className="px-5 py-2 bg-rose-950 hover:bg-rose-900 text-amber-300 rounded-xl font-extrabold text-xs flex items-center gap-1 shadow-md cursor-pointer disabled:opacity-50"
              >
                <Truck size={14} />
                <span>{isSubmittingCourier ? 'স্টিডফাস্ট API এন্ট্রি হচ্ছে...' : 'এন্ট্রি ও ট্র্যাকিং জেনারেট করুন'}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MANUAL ORDER CONFIRMATION & DELIVERY CHARGE CHANGE MODAL */}
      {confirmingOrder && (
        <div className="fixed inset-0 z-60 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in overflow-y-auto">
          <div className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl p-6 border border-amber-500/30 space-y-4 my-auto max-h-[95vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-stone-200 pb-3 sticky top-0 bg-white z-10">
              <div className="flex items-center gap-2 text-rose-950 font-serif font-bold text-base">
                <CheckCircle2 className="text-emerald-600" size={20} />
                <span>{lang === 'bn' ? 'অর্ডার কনফার্ম ও ডেলিভারি চার্জ নির্ধারণ' : 'Confirm Order & Edit Delivery Fee'}</span>
              </div>
              <button onClick={() => setConfirmingOrder(null)} className="p-1 hover:bg-stone-100 rounded-full text-stone-500 cursor-pointer">
                <X size={18} />
              </button>
            </div>

            {/* Order summary */}
            <div className="p-3.5 bg-stone-50 rounded-2xl border border-stone-200 space-y-1.5 text-xs">
              <div className="flex justify-between items-center">
                <span className="font-bold text-stone-900">অর্ডার নম্বর: <span className="font-mono text-rose-950">#{confirmingOrder.id}</span></span>
                <span className="bg-amber-100 text-amber-900 font-extrabold text-[10px] px-2 py-0.5 rounded-full">{confirmingOrder.items.length}টি আইটেম</span>
              </div>
              <div className="text-stone-700">
                কাস্টমার: <strong>{confirmingOrder.customerName}</strong> ({confirmingOrder.phone})
              </div>
              <div className="text-stone-600">
                📍 {confirmingOrder.address}, {confirmingOrder.city}
              </div>
              <div className="text-stone-500 text-[11px]">
                পণ্যের মূল্য (Subtotal): ৳{confirmingOrder.items.reduce((s, i) => s + (i?.product?.price || 0) * (i?.quantity || 1), 0).toLocaleString()}
              </div>
            </div>

            {/* Interactive Order Items List - Remove or Change Quantity */}
            <div className="p-3 bg-amber-50/50 rounded-2xl border border-amber-200 space-y-2 text-xs">
              <div className="flex items-center justify-between">
                <span className="font-bold text-stone-900 flex items-center gap-1.5">
                  <Package size={14} className="text-amber-700" />
                  <span>অর্ডারের পণ্যসমূহ ({confirmingOrder.items.length}টি):</span>
                </span>
                <span className="text-[10px] text-stone-500 font-medium">
                  {lang === 'bn' ? 'কোনো পণ্য বাদ দিতে 🗑️ চাপুন' : 'Click 🗑️ to remove item'}
                </span>
              </div>

              <div className="max-h-48 overflow-y-auto space-y-2 pr-1">
                {confirmingOrder.items.map((item, idx) => {
                  const p = item.product;
                  const pName = lang === 'bn' ? (p?.nameBn || p?.nameEn) : (p?.nameEn || p?.nameBn);
                  const pImg = p?.image || (p?.images && p?.images[0]) || '';
                  const itemTotal = (p?.price || 0) * item.quantity;

                  return (
                    <div key={idx} className="flex items-center gap-2.5 p-2 bg-white rounded-xl border border-stone-200 shadow-2xs">
                      {pImg && (
                        <img src={pImg} alt={pName} className="w-11 h-11 object-cover rounded-lg border border-stone-200 shrink-0" referrerPolicy="no-referrer" />
                      )}
                      <div className="flex-1 min-w-0">
                        <p className="font-bold text-stone-900 text-xs truncate" title={pName}>{pName}</p>
                        <div className="flex items-center gap-2 text-[11px] text-stone-600 mt-0.5">
                          {item.selectedSize && (
                            <span className="font-mono text-[10px] bg-rose-50 text-rose-950 px-1.5 py-0.5 rounded border border-rose-200 font-extrabold">
                              সাইজ: {item.selectedSize}
                            </span>
                          )}
                          <span>৳{p?.price} × {item.quantity} = <strong className="text-rose-950 font-black">৳{itemTotal.toLocaleString()}</strong></span>
                        </div>
                      </div>

                      {/* Quantity Controls */}
                      <div className="flex items-center gap-1 bg-stone-100 p-0.5 rounded-lg border border-stone-200 shrink-0">
                        <button
                          type="button"
                          disabled={item.quantity <= 1}
                          onClick={() => {
                            const newItems = confirmingOrder.items.map((it, i) => i === idx ? { ...it, quantity: it.quantity - 1 } : it);
                            setConfirmingOrder({ ...confirmingOrder, items: newItems });
                          }}
                          className="w-5 h-5 flex items-center justify-center bg-white hover:bg-stone-200 rounded text-stone-700 font-bold disabled:opacity-30 cursor-pointer text-xs"
                          title="পরিমাণ ১ কমান"
                        >
                          <Minus size={11} />
                        </button>
                        <span className="w-4 text-center font-mono font-bold text-xs">{item.quantity}</span>
                        <button
                          type="button"
                          onClick={() => {
                            const newItems = confirmingOrder.items.map((it, i) => i === idx ? { ...it, quantity: it.quantity + 1 } : it);
                            setConfirmingOrder({ ...confirmingOrder, items: newItems });
                          }}
                          className="w-5 h-5 flex items-center justify-center bg-white hover:bg-stone-200 rounded text-stone-700 font-bold cursor-pointer text-xs"
                          title="পরিমাণ ১ বাড়ান"
                        >
                          <Plus size={11} />
                        </button>
                      </div>

                      {/* Remove Item Button */}
                      <button
                        type="button"
                        onClick={() => {
                          if (confirmingOrder.items.length <= 1) {
                            alert(lang === 'bn' ? 'অর্ডারে কমপক্ষে একটি পণ্য থাকতে হবে। গ্রাহক কোনো পণ্যই না নিলে অর্ডারটি ক্যানসেল (Cancel) করুন।' : 'Order must have at least 1 item.');
                            return;
                          }
                          if (window.confirm(`কাস্টমার কি "${pName}" পণ্যটি বাদ দিতে চান? এই পণ্যটি বাদ দিলে বাকিগুলো নিয়ে অর্ডার কনফার্ম হবে।`)) {
                            const newItems = confirmingOrder.items.filter((_, i) => i !== idx);
                            setConfirmingOrder({ ...confirmingOrder, items: newItems });
                          }
                        }}
                        className="p-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 hover:text-rose-900 rounded-lg border border-rose-200 transition-colors cursor-pointer shrink-0"
                        title="এই পণ্যটি অর্ডার থেকে বাদ দিন"
                      >
                        <Trash2 size={13} />
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>

            <form onSubmit={(e) => {
              e.preventDefault();
              const subtotal = confirmingOrder.items.reduce((s, i) => s + i.product.price * i.quantity, 0);
              const updatedTotal = Math.max(0, subtotal - customDiscount + customShippingFee);
              
              const updatedOrder: Order = {
                ...confirmingOrder,
                status: 'confirmed',
                shippingFee: customShippingFee,
                discount: customDiscount,
                totalAmount: updatedTotal,
                paymentStatus: confirmIsPaid ? 'VERIFIED_PAID' : (confirmingOrder.paymentStatus || 'UNPAID'),
                amountPaid: confirmIsPaid ? updatedTotal : (confirmingOrder.amountPaid || 0),
                amountDue: confirmIsPaid ? 0 : updatedTotal
              };

              if (onUpdateFullOrder) {
                onUpdateFullOrder(updatedOrder);
              } else {
                onUpdateOrderStatus(confirmingOrder.id, 'confirmed');
              }

              // Switch filter to 'all' so the confirmed order is NEVER hidden from the admin
              setOrderFilter('all');
              setConfirmingOrder(null);
              alert(lang === 'bn' 
                ? `✅ অর্ডার #${confirmingOrder.id} কনফার্ম ও আপডেট হয়েছে!\nএটি সকল অর্ডার এবং 'কনফার্মড' ট্যাবে সংরক্ষিত রয়েছে।\nডেলিভারি চার্জ: ৳${customShippingFee}\n${confirmIsPaid ? 'ক্যাশ অন ডেলিভারি (COD): ৳০ (সম্পূর্ণ পেইড)' : `ক্যাশ অন ডেলিভারি (COD): ৳${updatedTotal}`}` 
                : `Order #${confirmingOrder.id} confirmed & updated! COD: ৳${confirmIsPaid ? 0 : updatedTotal}`);
            }} className="space-y-4 text-xs">
              
              <div className="space-y-1">
                <label className="block font-bold text-stone-800">
                  {lang === 'bn' ? '🚚 ডেলিভারি চার্জ পরিবর্তন / নির্ধারণ করুন (টাকা):' : 'Delivery Charge (BDT):'}
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="number"
                    min={0}
                    step={10}
                    required
                    value={customShippingFee}
                    onChange={(e) => setCustomShippingFee(Number(e.target.value))}
                    className="w-full px-3.5 py-2.5 bg-amber-50/60 border-2 border-amber-500/40 rounded-xl font-mono text-base font-extrabold text-rose-950 focus:ring-2 focus:ring-amber-500 focus:outline-none"
                  />
                  <div className="flex gap-1">
                    <button
                      type="button"
                      onClick={() => setCustomShippingFee(80)}
                      className="px-2.5 py-2 bg-stone-100 hover:bg-stone-200 text-stone-800 font-mono font-bold rounded-lg cursor-pointer text-[11px]"
                    >
                      ৳৮০
                    </button>
                    <button
                      type="button"
                      onClick={() => setCustomShippingFee(150)}
                      className="px-2.5 py-2 bg-stone-100 hover:bg-stone-200 text-stone-800 font-mono font-bold rounded-lg cursor-pointer text-[11px]"
                    >
                      ৳১৫০
                    </button>
                    <button
                      type="button"
                      onClick={() => setCustomShippingFee(200)}
                      className="px-2.5 py-2 bg-stone-100 hover:bg-stone-200 text-stone-800 font-mono font-bold rounded-lg cursor-pointer text-[11px]"
                      title="বেশি ওজনের পার্সেল"
                    >
                      ৳২০০
                    </button>
                  </div>
                </div>
                <p className="text-[10px] text-stone-500">
                  *একাধিক আইটেম (৪-৫টি ড্রেস) বা বিশেষ ওজনের পার্সেলের ক্ষেত্রে আপনার প্রয়োজন অনুযায়ী যেকোনো ডেলিভারি চার্জ নির্ধারণ করতে পারেন।
                </p>
              </div>

              {/* Total Calculation Preview */}
              <div className="p-3 bg-rose-50/80 rounded-xl border border-rose-200 flex items-center justify-between font-bold">
                <span className="text-stone-700">সর্বমোট প্রদেয় বিল (Total Payable):</span>
                <span className="text-base font-mono font-black text-rose-950">
                  ৳{(
                    confirmingOrder.items.reduce((s, i) => s + i.product.price * i.quantity, 0) - customDiscount + customShippingFee
                  ).toLocaleString()}
                </span>
              </div>

              {/* Advance Paid / COD 00 Toggle */}
              <div className="p-3 bg-emerald-50 border-2 border-emerald-300 rounded-xl space-y-1.5">
                <label className="flex items-center gap-2 cursor-pointer font-bold text-emerald-950">
                  <input
                    type="checkbox"
                    checked={confirmIsPaid}
                    onChange={(e) => setConfirmIsPaid(e.target.checked)}
                    className="w-4 h-4 text-emerald-700 rounded accent-emerald-700"
                  />
                  <span>{lang === 'bn' ? 'কাস্টমার ইতিমধ্যে টাকা পরিশোধ করেছেন (কুরিয়ার COD কালেকশন ৳০)' : 'Customer already paid in full (COD ৳0)'}</span>
                </label>
                {confirmIsPaid ? (
                  <p className="text-[11px] text-emerald-800 font-bold">
                    ✅ অর্ডারটি সম্পূর্ণ পরিশোধিত হিসেবে মার্ক হবে এবং কুরিয়ার ডেলিভারি রাইডার কাস্টমারের কাছ থেকে কোনো টাকা নেবে না (COD = ৳০)।
                  </p>
                ) : (
                  <p className="text-[10px] text-stone-500">
                    *কাস্টমার ক্যাশ অন ডেলিভারিতে পণ্য পাওয়ার সময় ৳{(confirmingOrder.items.reduce((s, i) => s + i.product.price * i.quantity, 0) - customDiscount + customShippingFee).toLocaleString()} প্রদান করবেন।
                  </p>
                )}
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setConfirmingOrder(null)}
                  className="px-4 py-2 bg-stone-200 hover:bg-stone-300 text-stone-800 font-bold rounded-xl cursor-pointer"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white font-extrabold rounded-xl shadow-md flex items-center gap-1.5 cursor-pointer"
                >
                  <CheckCircle2 size={16} />
                  <span>অর্ডার কনফার্ম করুন</span>
                </button>
              </div>
            </form>

          </div>
        </div>
      )}

      {/* EDIT PAYMENT & COD ADJUSTMENT MODAL */}
      {editingPaymentOrder && (
        <div className="fixed inset-0 z-60 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in">
          <div className="relative w-full max-w-md bg-white rounded-3xl shadow-2xl p-6 border border-amber-500/30 space-y-4">
            <div className="flex items-center justify-between border-b border-stone-200 pb-3">
              <div className="flex items-center gap-2 text-rose-950 font-serif font-bold text-base">
                <DollarSign className="text-emerald-600" size={20} />
                <span>{lang === 'bn' ? 'কাস্টমার পেমেন্ট ও COD সমন্বয়' : 'Customer Payment & COD Settlement'}</span>
              </div>
              <button 
                onClick={() => setEditingPaymentOrder(null)} 
                className="p-1 hover:bg-stone-100 rounded-full text-stone-500 cursor-pointer"
              >
                <X size={18} />
              </button>
            </div>

            {/* Order Brief */}
            <div className="p-3.5 bg-stone-50 rounded-2xl border border-stone-200 space-y-1.5 text-xs">
              <div className="flex justify-between items-center">
                <span className="font-bold text-stone-900">
                  অর্ডার আইডি: <span className="font-mono text-rose-950 font-black">#{editingPaymentOrder.id}</span>
                </span>
                <span className="px-2 py-0.5 bg-rose-100 text-rose-950 rounded-full font-bold text-[10px]">
                  সর্বমোট বিল: ৳{editingPaymentOrder.totalAmount.toLocaleString()}
                </span>
              </div>
              <div className="text-stone-700">
                কাস্টমার: <strong>{editingPaymentOrder.customerName}</strong> ({editingPaymentOrder.phone})
              </div>
            </div>

            <form onSubmit={(e) => {
              e.preventDefault();
              const paid = Math.max(0, Number(customPaidAmount));
              const due = Math.max(0, editingPaymentOrder.totalAmount - paid);
              const isPaid = due === 0;

              const updatedOrder: Order = {
                ...editingPaymentOrder,
                amountPaid: paid,
                amountDue: due,
                paymentMethod: customPaymentMethod,
                trxId: customPaymentTrxId || editingPaymentOrder.trxId,
                paymentStatus: isPaid ? 'VERIFIED_PAID' : (paid > 0 ? 'PARTIAL_PAID' as any : 'UNPAID'),
                adminNotes: `পেমেন্ট আপডেট: পেইড ৳${paid}, কুরিয়ার COD বাকি ৳${due} (${customPaymentMethod})`
              };

              if (onUpdateFullOrder) {
                onUpdateFullOrder(updatedOrder);
              }
              setEditingPaymentOrder(null);
              alert(lang === 'bn' 
                ? `✅ অর্ডার #${editingPaymentOrder.id} এর পেমেন্ট আপডেট হয়েছে!\nপেইড এমাউন্ট: ৳${paid}\nকুরিয়ার COD কালেকশন: ৳${due} ${isPaid ? '(সম্পূর্ণ পেইড - COD ৳০)' : ''}`
                : `Payment updated! COD Due: ৳${due}`);
            }} className="space-y-4 text-xs">

              {/* Quick One-Click Status Buttons */}
              <div className="space-y-1.5">
                <label className="block font-bold text-stone-800">
                  {lang === 'bn' ? '⚡ দ্রুত ১-ক্লিকে সেট করুন:' : 'Quick 1-Click Action:'}
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setCustomPaidAmount(editingPaymentOrder.totalAmount)}
                    className="p-2.5 bg-emerald-50 hover:bg-emerald-100 border border-emerald-300 text-emerald-950 font-bold rounded-xl text-left cursor-pointer transition-colors"
                  >
                    <div className="font-extrabold text-emerald-800 flex items-center gap-1">
                      <CheckCircle2 size={13} />
                      <span>সম্পূর্ণ পেইড (COD ৳০)</span>
                    </div>
                    <div className="text-[10px] text-stone-500">বাকি টাকা ৳০ হবে</div>
                  </button>

                  <button
                    type="button"
                    onClick={() => setCustomPaidAmount(editingPaymentOrder.shippingFee || 80)}
                    className="p-2.5 bg-amber-50 hover:bg-amber-100 border border-amber-300 text-amber-950 font-bold rounded-xl text-left cursor-pointer transition-colors"
                  >
                    <div className="font-extrabold text-amber-800 flex items-center gap-1">
                      <Truck size={13} />
                      <span>ডেলিভারি চার্জ পেইড</span>
                    </div>
                    <div className="text-[10px] text-stone-500">বাকি থাকবে ড্রেসের দাম</div>
                  </button>
                </div>
              </div>

              {/* Custom Paid Amount Input */}
              <div className="space-y-1">
                <label className="block font-bold text-stone-800">
                  {lang === 'bn' ? '💵 কাস্টমার কত টাকা পরিশোধ করেছেন? (টাকা):' : 'Amount Paid by Customer (BDT):'}
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-2.5 font-mono font-black text-rose-950 text-base">৳</span>
                  <input
                    type="number"
                    min={0}
                    max={editingPaymentOrder.totalAmount * 2}
                    required
                    value={customPaidAmount}
                    onChange={(e) => setCustomPaidAmount(Number(e.target.value))}
                    className="w-full pl-8 pr-3 py-2.5 bg-amber-50/70 border-2 border-amber-400 rounded-xl font-mono text-base font-black text-rose-950 focus:ring-2 focus:ring-amber-500 focus:outline-none"
                  />
                </div>
              </div>

              {/* Payment Method and Trx ID */}
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-bold text-stone-700 mb-1">পেমেন্ট মেথড</label>
                  <select
                    value={customPaymentMethod}
                    onChange={(e) => setCustomPaymentMethod(e.target.value as any)}
                    className="w-full p-2 bg-white border border-stone-300 rounded-xl font-bold text-xs"
                  >
                    <option value="bkash">বিকাশ (bKash)</option>
                    <option value="nagad">নগদ (Nagad)</option>
                    <option value="rocket">রকেট (Rocket)</option>
                    <option value="cod">ক্যাশ / ব্যাংক (Cash/Bank)</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-stone-700 mb-1">TrxID / রেফারেন্স (ঐচ্ছিক)</label>
                  <input
                    type="text"
                    value={customPaymentTrxId}
                    onChange={(e) => setCustomPaymentTrxId(e.target.value)}
                    placeholder="যেমন: 9J7X8..."
                    className="w-full p-2 bg-white border border-stone-300 rounded-xl font-mono text-xs"
                  />
                </div>
              </div>

              {/* Live Calculation Preview */}
              <div className="p-3.5 bg-rose-50/80 rounded-2xl border border-rose-200 space-y-1 text-xs">
                <div className="flex justify-between items-center text-stone-600">
                  <span>সর্বমোট বিল:</span>
                  <span className="font-bold">৳{editingPaymentOrder.totalAmount.toLocaleString()}</span>
                </div>
                <div className="flex justify-between items-center text-emerald-700 font-bold">
                  <span>কাস্টমার পরিশোধ করেছেন:</span>
                  <span>৳{customPaidAmount.toLocaleString()}</span>
                </div>
                <div className="flex justify-between items-center pt-1 border-t border-rose-200 font-extrabold text-sm text-rose-950">
                  <span>কুরিয়ার কালেকশন (Cash on Delivery Due):</span>
                  <span className="font-mono text-base">
                    ৳{Math.max(0, editingPaymentOrder.totalAmount - customPaidAmount).toLocaleString()}
                  </span>
                </div>
                {Math.max(0, editingPaymentOrder.totalAmount - customPaidAmount) === 0 ? (
                  <p className="text-[11px] text-emerald-800 font-bold pt-1 text-center bg-emerald-100 p-1.5 rounded-lg">
                    🎉 সম্পূর্ণ পেইড! কুরিয়ার পার্সেল COD ৳০ হিসেবে যাবে।
                  </p>
                ) : (
                  <p className="text-[10px] text-stone-500 pt-0.5">
                    *কুরিয়ার ডেলিভারি রাইডার কাস্টমার থেকে বাকি ৳{Math.max(0, editingPaymentOrder.totalAmount - customPaidAmount).toLocaleString()} আদায় করবে।
                  </p>
                )}
              </div>

              <div className="flex justify-end gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => setEditingPaymentOrder(null)}
                  className="px-4 py-2 bg-stone-200 hover:bg-stone-300 text-stone-800 font-bold rounded-xl cursor-pointer"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white font-extrabold rounded-xl shadow-md flex items-center gap-1.5 cursor-pointer"
                >
                  <CheckCircle2 size={16} />
                  <span>পেমেন্ট ও COD সংরক্ষণ করুন</span>
                </button>
              </div>
            </form>

          </div>
        </div>
      )}

      {/* PRINTABLE INVOICE & COURIER PARCEL STICKER MODAL */}
      {printingOrder && (() => {
        const isPaidInFull = (printingOrder.amountDue === 0) || (printingOrder.paymentStatus === 'VERIFIED_PAID');
        const codDue = isPaidInFull ? 0 : (printingOrder.amountDue !== undefined ? printingOrder.amountDue : printingOrder.totalAmount);

        return (
        <div className="fixed inset-0 z-60 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in overflow-y-auto">
          <div className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl p-6 border border-amber-500/30 space-y-6 my-auto">
            <div className="flex items-center justify-between border-b border-stone-200 pb-3 print:hidden no-print">
              <div className="flex items-center gap-2 text-rose-950 font-serif font-bold text-base">
                <Printer className="text-amber-600" size={20} />
                <span>{lang === 'bn' ? 'অর্ডার মেমো ও কুরিয়ার শিপিং লেবেল' : 'Printable Invoice & Courier Label'}</span>
              </div>
              <button onClick={() => setPrintingOrder(null)} className="p-1 hover:bg-stone-100 rounded-full text-stone-500">
                <X size={18} />
              </button>
            </div>

            {/* Print Area Preview */}
            <div id="printable-area" className="p-5 bg-amber-50/40 rounded-2xl border-2 border-dashed border-stone-300 space-y-4 text-xs font-sans">
              <div className="flex justify-between items-start border-b border-stone-200 pb-3">
                <div>
                  <h3 className="text-lg font-serif font-extrabold text-rose-950 tracking-wider">রঙিলা রূপ</h3>
                  <p className="text-[10px] text-stone-600">অনলাইন শপিং মোবাইল: 01792765693</p>
                  <p className="text-[10px] text-stone-500">ঢাকা, বাংলাদেশ</p>
                </div>
                <div className="text-right">
                  <span className="px-2 py-0.5 bg-rose-950 text-amber-300 font-mono font-bold text-[10px] rounded">
                    Invoice #{printingOrder.id}
                  </span>
                  <p className="text-[10px] text-stone-500 mt-1">{printingOrder.createdAt}</p>
                </div>
              </div>

              {/* Customer Box */}
              <div className="p-3 bg-white rounded-xl border border-stone-200 space-y-1">
                <span className="text-[10px] font-bold text-stone-400 uppercase tracking-wider block">Receiver / কাস্টমার তথ্য:</span>
                <div className="font-bold text-sm text-stone-900">{printingOrder.customerName}</div>
                <div className="font-mono font-bold text-rose-900 text-xs">📞 {printingOrder.phone}</div>
                <div className="text-stone-700">📍 {printingOrder.address}, {printingOrder.city}</div>
              </div>

              {/* Courier Barcode Snippet */}
              <div className="p-3 bg-stone-900 text-amber-50 rounded-xl flex items-center justify-between">
                <div>
                  <span className="text-[9px] uppercase tracking-wider text-amber-400 font-bold block">Courier COD Parcel Sticker</span>
                  <span className={`font-mono text-sm font-extrabold ${isPaidInFull ? 'text-emerald-400' : 'text-white'}`}>
                    COD Amount: {isPaidInFull ? '৳০ (সম্পূর্ণ পেইড - Full Paid)' : `৳${codDue.toLocaleString()}`}
                  </span>
                  {isPaidInFull ? (
                    <span className="text-[10px] text-emerald-300 block font-bold mt-0.5">
                      ⚠️ কুরিয়ার নির্দেশনা: কোনো টাকা আদায় করবেন না (Prepaid)
                    </span>
                  ) : (
                    printingOrder.courierTrackingId && (
                      <span className="text-[10px] text-amber-300 font-mono block mt-0.5">
                        {printingOrder.courierName}: {printingOrder.courierTrackingId}
                      </span>
                    )
                  )}
                </div>
                <div className="p-1 bg-white rounded-lg shrink-0">
                  {invoiceQrCodeUrl ? (
                    <img
                      src={invoiceQrCodeUrl}
                      alt="Order Verification QR"
                      className="w-14 h-14 object-contain rounded"
                    />
                  ) : (
                    <QrCode size={36} className="text-stone-900" />
                  )}
                </div>
              </div>

              {/* Items summary */}
              <table className="w-full text-left text-[11px] border-collapse">
                <thead>
                  <tr className="border-b border-stone-300 text-stone-500">
                    <th className="py-1">পণ্য</th>
                    <th className="py-1 text-center">পরিমাণ</th>
                    <th className="py-1 text-right">মূল্য</th>
                  </tr>
                </thead>
                <tbody>
                  {((printingOrder && printingOrder.items) || []).map((it, idx) => (
                    <tr key={idx} className="border-b border-stone-200">
                      <td className="py-1.5 font-bold text-stone-900">
                        {lang === 'bn' ? it.product.nameBn : it.product.nameEn}
                        {it.selectedSize && (
                          <span className="ml-1 text-[10px] font-mono text-rose-950 bg-amber-100 px-1.5 py-0.5 rounded border border-amber-300 font-extrabold">
                            (সাইজ: {it.selectedSize})
                          </span>
                        )}
                      </td>
                      <td className="py-1.5 text-center font-bold">{it.quantity}</td>
                      <td className="py-1.5 text-right font-bold">৳{(it.product.price * it.quantity).toLocaleString()}</td>
                    </tr>
                  ))}
                </tbody>
              </table>

              <div className="pt-2 border-t border-stone-300 space-y-1">
                <div className="flex justify-between items-center text-xs text-stone-600">
                  <span>সর্বমোট পণ্যের বিল (Total Bill):</span>
                  <span className="font-bold">৳{printingOrder.totalAmount.toLocaleString()}</span>
                </div>
                {isPaidInFull ? (
                  <>
                    <div className="flex justify-between items-center text-xs text-emerald-800 font-bold">
                      <span>পরিশোধিত অর্থ (Advance Paid):</span>
                      <span>৳{(printingOrder.amountPaid || printingOrder.totalAmount).toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between items-center text-xs font-black text-emerald-950 bg-emerald-100 p-2 rounded-lg border border-emerald-300">
                      <span>কুরিয়ার ক্যাশ অন ডেলিভারি (COD):</span>
                      <span className="font-mono text-sm font-black">৳০ (কোনো টাকা আদায় করবেন না)</span>
                    </div>
                  </>
                ) : (
                  <div className="flex justify-between items-center font-bold text-sm text-rose-950">
                    <span>ক্যাশ অন ডেলিভারি প্রদেয় (Total COD):</span>
                    <span className="text-base font-serif font-black">৳{codDue.toLocaleString()}</span>
                  </div>
                )}
              </div>
            </div>

            <div className="flex flex-wrap items-center justify-between gap-2 pt-2 print:hidden no-print border-t border-stone-200">
              <button
                type="button"
                onClick={() => setPrintingOrder(null)}
                className="px-4 py-2 bg-stone-200 hover:bg-stone-300 text-stone-800 rounded-xl font-bold text-xs cursor-pointer print:hidden no-print"
              >
                বন্ধ করুন
              </button>

              <div className="flex items-center gap-2 flex-wrap">
                {/* Download Offline HTML */}
                <button
                  type="button"
                  onClick={() => downloadInvoiceHtml('printable-area', `Invoice_${printingOrder.id}.html`)}
                  className="px-3.5 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded-xl font-bold text-xs flex items-center gap-1.5 border border-stone-300 cursor-pointer print:hidden no-print"
                  title="ইনভয়েস ফাইল হিসেবে ডাউনলোড করুন"
                >
                  <Download size={14} />
                  <span>HTML ডাউনলোড</span>
                </button>

                {/* Open in Clean New Tab */}
                <button
                  type="button"
                  onClick={() => openInvoiceInNewTab('printable-area')}
                  className="px-4 py-2 bg-amber-100 hover:bg-amber-200 text-amber-900 rounded-xl font-bold text-xs flex items-center gap-1.5 border border-amber-300 cursor-pointer print:hidden no-print"
                  title="নতুন ট্যাবে সম্পূর্ণ পেজ ইনভয়েস খুলুন ও ব্রাউজারের প্রিন্ট ডায়ালগ ব্যবহার করুন"
                >
                  <ExternalLink size={14} />
                  <span>নতুন ট্যাবে খুলুন</span>
                </button>

                {/* Direct Print Button */}
                <button
                  type="button"
                  onClick={() => printInvoiceElement('printable-area')}
                  className="px-5 py-2 bg-rose-950 hover:bg-rose-900 text-amber-300 rounded-xl font-extrabold text-xs flex items-center gap-1.5 shadow-md cursor-pointer print:hidden no-print"
                >
                  <Printer size={14} />
                  <span>ইনভয়েস ও স্টিকার প্রিন্ট</span>
                </button>
              </div>
            </div>
          </div>
        </div>
        );
      })()}

      {/* EDIT PRODUCT MODAL */}
      {editingProduct && (
        <div className="fixed inset-0 z-60 bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 animate-fade-in overflow-y-auto">
          <div className="relative w-full max-w-2xl bg-white rounded-3xl shadow-2xl p-6 border border-amber-500/30 my-auto space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-stone-200 pb-3">
              <div className="flex items-center gap-2 text-rose-950 font-serif font-bold text-base">
                <Edit3 className="text-amber-600" size={20} />
                <span>{lang === 'bn' ? 'প্রডাক্টের তথ্য ও ছবি এডিট করুন' : 'Edit Product & Photos'}</span>
              </div>
              <button 
                onClick={() => setEditingProduct(null)} 
                className="p-1 hover:bg-stone-100 rounded-full text-stone-500 cursor-pointer"
              >
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleSaveEditProduct} className="space-y-4 text-xs">
              {/* Direct Photo Upload Section in Edit Modal */}
              <div className="p-4 bg-amber-50/60 rounded-2xl border-2 border-dashed border-amber-300 space-y-3">
                <div className="flex items-center justify-between">
                  <label className="block font-bold text-stone-800 text-xs flex items-center gap-1.5">
                    <ImagePlus size={16} className="text-rose-900" />
                    <span>{lang === 'bn' ? '📸 প্রডাক্টের ছবি (ফোন বা গ্যালারি থেকে সরাসরী আপলোড করুন)' : '📸 Product Photos (Upload directly from device)'}</span>
                  </label>
                </div>

                <div className="flex flex-wrap gap-2 items-center">
                  <label className="px-3.5 py-2.5 bg-rose-950 hover:bg-rose-900 text-amber-300 font-bold rounded-xl cursor-pointer flex items-center gap-1.5 shadow-sm transition-all">
                    <Camera size={16} />
                    <span>{lang === 'bn' ? '+ নতুন ছবি তুলুন / সিলেক্ট করুন' : '+ Select / Capture New Photo'}</span>
                    <input
                      type="file"
                      accept="image/*"
                      multiple
                      onChange={(e) => handleImageFilesUpload(e, true)}
                      className="hidden"
                    />
                  </label>

                  {isUploadingImage && (
                    <span className="text-xs text-amber-800 font-bold flex items-center gap-1 animate-pulse">
                      <RefreshCw size={14} className="animate-spin text-rose-900" />
                      {lang === 'bn' ? 'ছবি প্রসেস হচ্ছে...' : 'Processing image...'}
                    </span>
                  )}
                </div>

                {/* Existing / Uploaded Photos list */}
                {editingProduct.images && editingProduct.images.length > 0 && (
                  <div className="space-y-1 pt-1">
                    <p className="text-[10px] text-stone-600 font-bold">
                      {lang === 'bn' ? 'বর্তমান ছবিসমূহ (কভার ফটো নির্বাচন করতে ছবিতে ক্লিক করুন):' : 'Current photos (Click to choose main cover photo):'}
                    </p>
                    <div className="grid grid-cols-4 sm:grid-cols-5 gap-2">
                      {editingProduct.images.map((imgSrc, idx) => (
                        <div key={idx} className={`relative group rounded-xl overflow-hidden border-2 aspect-square bg-stone-200 ${
                          editingProduct.image === imgSrc ? 'border-amber-500 ring-2 ring-amber-400' : 'border-stone-300'
                        }`}>
                          <img src={imgSrc} alt="" className="w-full h-full object-cover" />
                          {editingProduct.image === imgSrc && (
                            <span className="absolute top-1 left-1 bg-amber-500 text-rose-950 text-[9px] font-black px-1 rounded shadow-xs">
                              কভার
                            </span>
                          )}
                          <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 flex flex-col items-center justify-center gap-1 transition-opacity p-1">
                            {editingProduct.image !== imgSrc && (
                              <button
                                type="button"
                                onClick={() => setEditingProduct({ ...editingProduct, image: imgSrc })}
                                className="text-[9px] bg-amber-400 text-rose-950 font-bold px-1.5 py-0.5 rounded cursor-pointer"
                              >
                                কভার পিক
                              </button>
                            )}
                            <button
                              type="button"
                              onClick={() => {
                                const newImgs = editingProduct.images?.filter((_, i) => i !== idx) || [];
                                setEditingProduct({
                                  ...editingProduct,
                                  image: editingProduct.image === imgSrc ? (newImgs[0] || '') : editingProduct.image,
                                  images: newImgs
                                });
                              }}
                              className="text-red-400 hover:text-red-200 cursor-pointer"
                              title="মুছে ফেলুন"
                            >
                              <Trash2 size={14} />
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-stone-700 mb-1">{lang === 'bn' ? 'প্রডাক্টের নাম (বাংলা)' : 'Bengali Name'}</label>
                  <input
                    type="text"
                    required
                    value={editingProduct.nameBn}
                    onChange={(e) => setEditingProduct({ ...editingProduct, nameBn: e.target.value })}
                    className="w-full p-2.5 bg-stone-50 border border-stone-200 rounded-xl font-medium text-stone-900 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block font-bold text-stone-700 mb-1">{lang === 'bn' ? 'ক্যাটাগরি' : 'Category'}</label>
                  <select
                    value={editingProduct.category}
                    onChange={(e) => setEditingProduct({ ...editingProduct, category: e.target.value as CategoryId })}
                    className="w-full p-2.5 bg-stone-50 border border-stone-200 rounded-xl font-bold text-stone-800"
                  >
                    <option value="babydress">{lang === 'bn' ? '👗 বেবি ফ্রক ও ড্রেস (Baby Frocks)' : 'Baby Frocks & Dresses'}</option>
                    <option value="babyset">{lang === 'bn' ? '🍼 বেবি রোম্পার ও সেট (Romper & Sets)' : 'Baby Rompers & Sets'}</option>
                    <option value="frock">{lang === 'bn' ? '🎀 পার্টি ফ্রক ও গাউন (Party Frocks)' : 'Party Frocks & Gowns'}</option>
                    <option value="combo">{lang === 'bn' ? '🎁 মেগা কম্বো প্যাকেজ (Mega Combo Package)' : 'Mega Combo Package'}</option>
                    <option value="panjabi">{lang === 'bn' ? '👔 বয়েজ পাঞ্জাবি ও ফতুয়া (Boys Panjabi)' : 'Boys Panjabi & Fotua'}</option>
                    <option value="footwear">{lang === 'bn' ? '👟 কিউট জুতো ও স্যান্ডেল (Baby Shoes)' : 'Baby Shoes & Footwear'}</option>
                    <option value="accessories">{lang === 'bn' ? '👑 হেয়ার ব্যান্ড ও ক্রাউন (Accessories)' : 'Baby Accessories'}</option>
                    <option value="toys">{lang === 'bn' ? '🧸 খেলনা ও গিফট আইটেম (Toys & Gifts)' : 'Kids Toys & Gifts'}</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-stone-700 mb-1">{lang === 'bn' ? 'বিক্রয় মূল্য (টাকা)' : 'Price (BDT)'}</label>
                  <input
                    type="number"
                    required
                    value={editingProduct.price}
                    onChange={(e) => setEditingProduct({ ...editingProduct, price: Number(e.target.value) })}
                    className="w-full p-2.5 bg-stone-50 border border-stone-200 rounded-xl font-bold text-rose-950 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block font-bold text-stone-700 mb-1">{lang === 'bn' ? 'রেগুলার রেট (আগের প্রাইজ)' : 'Original Price'}</label>
                  <input
                    type="number"
                    value={editingProduct.originalPrice || ''}
                    onChange={(e) => setEditingProduct({ ...editingProduct, originalPrice: Number(e.target.value) })}
                    className="w-full p-2.5 bg-stone-50 border border-stone-200 rounded-xl focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block font-bold text-stone-700 mb-1">{lang === 'bn' ? 'ফেব্রিক / উপাদান' : 'Fabric'}</label>
                  <input
                    type="text"
                    value={editingProduct.fabricBn || ''}
                    onChange={(e) => setEditingProduct({ ...editingProduct, fabricBn: e.target.value })}
                    className="w-full p-2.5 bg-stone-50 border border-stone-200 rounded-xl focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block font-bold text-stone-700 mb-1">{lang === 'bn' ? 'স্টক স্ট্যাটাস' : 'Stock Status'}</label>
                  <select
                    value={editingProduct.inStock ? 'true' : 'false'}
                    onChange={(e) => setEditingProduct({ ...editingProduct, inStock: e.target.value === 'true' })}
                    className="w-full p-2.5 bg-stone-50 border border-stone-200 rounded-xl font-bold text-stone-800"
                  >
                    <option value="true">স্টকে আছে (In Stock)</option>
                    <option value="false">স্টক আউট (Out of Stock)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-bold text-stone-700 mb-1">{lang === 'bn' ? 'বিবরণ (Description)' : 'Description'}</label>
                <textarea
                  rows={2}
                  value={editingProduct.descriptionBn || ''}
                  onChange={(e) => setEditingProduct({ ...editingProduct, descriptionBn: e.target.value })}
                  className="w-full p-2.5 bg-stone-50 border border-stone-200 rounded-xl focus:outline-none"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setEditingProduct(null)}
                  className="px-4 py-2 bg-stone-200 hover:bg-stone-300 text-stone-800 font-bold rounded-xl cursor-pointer"
                >
                  {lang === 'bn' ? 'বাতিল' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-rose-950 hover:bg-rose-900 text-amber-300 font-bold rounded-xl flex items-center gap-1 cursor-pointer shadow-md"
                >
                  <CheckCircle2 size={16} />
                  <span>{lang === 'bn' ? 'সেভ করুন' : 'Save Changes'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ORDER DETAILS & ACTION MODAL */}
      {selectedOrderDetail && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in">
          <div className="relative w-full max-w-2xl bg-white rounded-3xl shadow-2xl p-6 border border-stone-200 space-y-4 max-h-[90vh] overflow-y-auto">
            {/* Header */}
            <div className="flex items-center justify-between border-b border-stone-100 pb-3">
              <div className="flex items-center gap-2">
                <span className="p-2 bg-amber-100 text-amber-900 rounded-xl">
                  <ShoppingBag size={20} />
                </span>
                <div>
                  <h3 className="font-serif font-bold text-stone-900 text-lg flex items-center gap-2">
                    <span>{lang === 'bn' ? 'অর্ডার বিস্তারিত' : 'Order Details'}</span>
                    <span className="font-mono text-xs bg-stone-100 text-stone-700 px-2 py-0.5 rounded font-extrabold">
                      #{selectedOrderDetail.id}
                    </span>
                  </h3>
                  <p className="text-[11px] text-stone-500">
                    {selectedOrderDetail.createdAt || 'Just now'} • {selectedOrderDetail.paymentMethod || 'COD'}
                  </p>
                </div>
              </div>

              <button
                onClick={() => setSelectedOrderDetail(null)}
                className="p-1.5 hover:bg-stone-100 rounded-full text-stone-400 hover:text-stone-700 transition-colors cursor-pointer"
              >
                <X size={20} />
              </button>
            </div>

            {/* Customer Info Card */}
            <div className="bg-stone-50 p-4 rounded-2xl border border-stone-200 space-y-2 text-xs">
              <div className="flex justify-between items-start flex-wrap gap-2">
                <div>
                  <span className="text-[10px] text-stone-400 uppercase font-bold tracking-wider block">গ্রাহকের নাম ও মোবাইল</span>
                  <p className="font-serif font-bold text-stone-900 text-sm mt-0.5">{selectedOrderDetail.customerName || 'Customer'}</p>
                  <p className="font-mono font-bold text-rose-900 text-xs mt-0.5">📞 {selectedOrderDetail.phone}</p>
                </div>
                <div className="flex items-center gap-2">
                  <a
                    href={`tel:${selectedOrderDetail.phone}`}
                    className="px-3 py-1.5 bg-emerald-100 hover:bg-emerald-200 text-emerald-900 font-bold rounded-xl flex items-center gap-1 text-xs transition-colors"
                  >
                    <PhoneCall size={12} />
                    <span>কল করুন</span>
                  </a>
                  <a
                    href={`https://wa.me/88${String(selectedOrderDetail.phone || '').replace(/[^0-9]/g, '')}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl flex items-center gap-1 text-xs transition-colors"
                  >
                    <Send size={12} />
                    <span>WhatsApp</span>
                  </a>
                </div>
              </div>

              <div className="pt-2 border-t border-stone-200/80">
                <span className="text-[10px] text-stone-400 uppercase font-bold tracking-wider block">ডেলিভারি ঠিকানা</span>
                <p className="font-medium text-stone-800 text-xs mt-0.5">
                  📍 {selectedOrderDetail.address || 'Address'}, {selectedOrderDetail.city || 'Dhaka'}
                </p>
                {selectedOrderDetail.notes && (
                  <p className="text-[11px] text-amber-800 bg-amber-50 p-2 rounded-lg border border-amber-200 mt-2 font-medium">
                    📝 নোট: {selectedOrderDetail.notes}
                  </p>
                )}
              </div>
            </div>

            {/* Order Items */}
            <div>
              <span className="text-xs font-bold text-stone-700 mb-2 block">{lang === 'bn' ? 'অর্ডারকৃত প্রোডাক্টসমূহ' : 'Ordered Products'}</span>
              <div className="space-y-2">
                {(selectedOrderDetail.items || []).map((item, idx) => {
                  const p = item.product;
                  const pName = lang === 'bn' ? (p?.nameBn || p?.nameEn) : (p?.nameEn || p?.nameBn);
                  const pImg = p?.image || (p?.images && p.images[0]) || 'https://images.unsplash.com/photo-1519689680058-324335c77eba?w=200';
                  const pPrice = Number(p?.price) || 0;
                  const pQty = Number(item.quantity) || 1;

                  return (
                    <div key={idx} className="flex items-center gap-3 p-3 bg-stone-50 rounded-2xl border border-stone-200">
                      <img src={pImg} alt={pName} className="w-14 h-14 object-cover rounded-xl border border-stone-200 shrink-0" referrerPolicy="no-referrer" />
                      <div className="flex-1 min-w-0">
                        <p className="font-bold text-stone-900 text-xs truncate">{pName}</p>
                        <div className="flex items-center gap-2 mt-1 flex-wrap">
                          <span className="text-xs text-stone-600 font-medium">
                            <strong className="text-stone-900 font-extrabold">{pQty} টি</strong> × ৳{pPrice.toLocaleString()} = <strong className="text-rose-950 font-bold">৳{(pQty * pPrice).toLocaleString()}</strong>
                          </span>
                          {item.selectedSize && (
                            <span className="px-2 py-0.5 bg-rose-950 text-amber-300 font-mono font-bold text-[11px] rounded-md shadow-2xs border border-amber-500/40">
                              সাইজ: {item.selectedSize}
                            </span>
                          )}
                        </div>
                      </div>

                      {/* Remove item option for admin if customer canceled this item */}
                      <button
                        type="button"
                        onClick={() => {
                          if ((selectedOrderDetail.items || []).length <= 1) {
                            alert(lang === 'bn' ? 'অর্ডারে অন্তত একটি পণ্য থাকতে হবে।' : 'Order must have at least 1 item.');
                            return;
                          }
                          if (window.confirm(`কাস্টমার কি "${pName}" পণ্যটি বাদ দিতে চান? এই পণ্যটি বাদ দিলে অর্ডারের সর্বমোট বিল স্বয়ংক্রিয়ভাবে হিসাব হয়ে সেভ হবে।`)) {
                            const newItems = (selectedOrderDetail.items || []).filter((_, i) => i !== idx);
                            const newSubtotal = newItems.reduce((sum, it) => sum + (Number(it?.product?.price) || 0) * (Number(it?.quantity) || 1), 0);
                            const ship = Number(selectedOrderDetail.shippingFee) || 80;
                            const disc = Number(selectedOrderDetail.discount) || 0;
                            const newTotal = Math.max(0, newSubtotal - disc + ship);
                            const isPaid = selectedOrderDetail.paymentStatus === 'VERIFIED_PAID' || selectedOrderDetail.paymentStatus === 'PAID';
                            const updatedOrder: Order = {
                              ...selectedOrderDetail,
                              items: newItems,
                              totalAmount: newTotal,
                              amountDue: isPaid ? 0 : Math.max(0, newTotal - (Number(selectedOrderDetail.amountPaid) || 0))
                            };
                            if (onUpdateFullOrder) {
                              onUpdateFullOrder(updatedOrder);
                            }
                            setSelectedOrderDetail(updatedOrder);
                            alert(`✅ "${pName}" পণ্যটি অর্ডার থেকে বাদ দেওয়া হয়েছে। নতুন মোট বিল: ৳${newTotal.toLocaleString()}`);
                          }
                        }}
                        className="p-2 bg-rose-50 hover:bg-rose-100 text-rose-700 hover:text-rose-900 rounded-xl border border-rose-200 transition-colors cursor-pointer shrink-0 flex items-center gap-1 text-[11px] font-bold"
                        title="এই পণ্যটি অর্ডার থেকে বাদ দিন"
                      >
                        <Trash2 size={13} />
                        <span className="hidden sm:inline">বাদ দিন</span>
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Comprehensive Payment & Verification Details in Modal */}
            {(() => {
              const isPaid = selectedOrderDetail.paymentStatus === 'VERIFIED_PAID' || selectedOrderDetail.paymentStatus === 'PAID';
              const isPending = selectedOrderDetail.paymentStatus === 'PENDING_VERIFICATION';
              const totalVal = Number(selectedOrderDetail.totalAmount) || 0;
              const paidVal = Number(selectedOrderDetail.amountPaid ?? (isPaid ? totalVal : 0));
              const dueVal = Number(selectedOrderDetail.amountDue ?? (isPaid ? 0 : Math.max(0, totalVal - paidVal)));
              const method = (selectedOrderDetail.paymentMethod || 'cod').toLowerCase();
              const sender = selectedOrderDetail.paymentSenderPhone || selectedOrderDetail.paymentPhone || '—';
              const receiver = selectedOrderDetail.paymentReceiverNumber || '01792765693';

              return (
                <div className="p-4 bg-gradient-to-br from-amber-50/70 via-stone-50 to-white rounded-2xl border border-amber-300 space-y-3 text-xs">
                  <div className="flex items-center justify-between flex-wrap gap-2 border-b border-amber-200 pb-2">
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] uppercase font-bold text-stone-500">পেমেন্ট মেথড:</span>
                      <span className={`px-2.5 py-0.5 rounded-lg font-mono font-black uppercase text-xs ${
                        method === 'bkash' ? 'bg-[#d12053] text-white' :
                        method === 'nagad' ? 'bg-[#f7941d] text-white' :
                        method === 'rocket' ? 'bg-[#8c3494] text-white' :
                        'bg-stone-800 text-amber-300'
                      }`}>
                        {selectedOrderDetail.paymentMethod || 'COD'}
                      </span>

                      <span className={`px-2.5 py-0.5 rounded-full font-bold text-xs ${
                        isPaid ? 'bg-emerald-100 text-emerald-900 border border-emerald-300' :
                        isPending ? 'bg-amber-100 text-amber-900 border border-amber-300 animate-pulse' :
                        'bg-stone-100 text-stone-700 border border-stone-300'
                      }`}>
                        {isPaid ? '✅ টাকা পাওয়া গেছে (Verified Paid)' : isPending ? '⏳ টাকা যাচাইকরণ বাকি' : '📦 ক্যাশ অন ডেলিভারি (বাকি)'}
                      </span>
                    </div>

                    <div className="text-[11px] text-stone-600">
                      <span>রিসিভার নম্বর:</span> <strong className="font-mono text-stone-900">{receiver}</strong>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div className="p-3 bg-white rounded-xl border border-stone-200 space-y-1">
                      <span className="text-[10px] text-stone-400 font-bold uppercase block">সেন্ডার ও TrxID</span>
                      <p className="font-mono font-bold text-rose-950">📞 সেন্ডার: {sender}</p>
                      <p className="font-mono font-extrabold text-pink-900 select-all">
                        TrxID: {selectedOrderDetail.trxId || 'দেওয়া হয়নি'}
                      </p>
                    </div>

                    <div className="p-3 bg-white rounded-xl border border-stone-200 space-y-1">
                      <span className="text-[10px] text-stone-400 font-bold uppercase block">টাকার হিসাব</span>
                      <div className="flex justify-between">
                        <span className="text-stone-500">পরিশোধিত:</span>
                        <span className="font-mono font-bold text-emerald-700">৳{paidVal.toLocaleString()}</span>
                      </div>
                      <div className="flex justify-between font-bold">
                        <span className="text-rose-900">বাকি (COD Due):</span>
                        <span className="font-serif font-black text-rose-950">৳{dueVal.toLocaleString()}</span>
                      </div>
                    </div>

                    <div className="p-3 bg-white rounded-xl border border-stone-200 flex items-center justify-between gap-2">
                      <div>
                        <span className="text-[10px] text-stone-400 font-bold uppercase block">পেমেন্ট স্ক্রিনশট</span>
                        {selectedOrderDetail.paymentScreenshot ? (
                          <button
                            type="button"
                            onClick={() => openScreenshotPreview(selectedOrderDetail.paymentScreenshot || '', selectedOrderDetail)}
                            className="mt-1 text-xs text-amber-900 font-bold hover:underline flex items-center gap-1 cursor-pointer"
                          >
                            <Eye size={12} />
                            <span>বড় করে দেখুন</span>
                          </button>
                        ) : (
                          <span className="text-[11px] text-stone-400 italic block mt-1">স্ক্রিনশট নেই</span>
                        )}
                      </div>
                      {selectedOrderDetail.paymentScreenshot && (
                        <img
                          src={selectedOrderDetail.paymentScreenshot}
                          alt="Screenshot Proof"
                          onClick={() => openScreenshotPreview(selectedOrderDetail.paymentScreenshot || '', selectedOrderDetail)}
                          className="w-12 h-12 object-cover rounded-lg border border-amber-300 cursor-pointer hover:opacity-80 transition-opacity shrink-0 shadow-2xs"
                        />
                      )}
                    </div>
                  </div>

                  {/* Quick Verification Status Buttons in Modal */}
                  <div className="flex items-center gap-2 pt-1 border-t border-amber-200/60 flex-wrap">
                    {!isPaid ? (
                      <button
                        type="button"
                        onClick={() => {
                          const updated = {
                            ...selectedOrderDetail,
                            paymentStatus: 'VERIFIED_PAID' as const,
                            amountPaid: totalVal,
                            amountDue: 0
                          };
                          if (onUpdateFullOrder) onUpdateFullOrder(updated);
                          setSelectedOrderDetail(updated);
                        }}
                        className="px-3.5 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl font-bold text-xs flex items-center gap-1 shadow-xs cursor-pointer"
                      >
                        <CheckCircle2 size={13} />
                        <span>✅ টাকা পেয়েছি হিসেবে কনফার্ম করুন (Mark Verified Paid)</span>
                      </button>
                    ) : (
                      <button
                        type="button"
                        onClick={() => {
                          const updated = {
                            ...selectedOrderDetail,
                            paymentStatus: 'UNPAID' as const,
                            amountPaid: 0,
                            amountDue: totalVal
                          };
                          if (onUpdateFullOrder) onUpdateFullOrder(updated);
                          setSelectedOrderDetail(updated);
                        }}
                        className="px-3 py-1.5 bg-stone-200 hover:bg-stone-300 text-stone-800 rounded-xl font-bold text-xs flex items-center gap-1 cursor-pointer"
                      >
                        <RotateCcw size={13} />
                        <span>টাকা পায়নি (Mark Unpaid)</span>
                      </button>
                    )}

                    <button
                      type="button"
                      onClick={() => {
                        setEditingPaymentOrder(selectedOrderDetail);
                        setCustomPaidAmount(paidVal);
                      }}
                      className="px-3 py-1.5 bg-amber-100 hover:bg-amber-200 text-amber-900 rounded-xl font-bold text-xs cursor-pointer ml-auto"
                    >
                      ✏️ পেইড এমাউন্ট কাস্টমাইজ করুন
                    </button>
                  </div>
                </div>
              );
            })()}

            {/* Financials Breakdown */}
            <div className="p-3.5 bg-amber-50/60 rounded-2xl border border-amber-200 text-xs space-y-1.5">
              <div className="flex justify-between text-stone-600 font-medium">
                <span>পণ্যগুলোর মোট মূল্য (Subtotal):</span>
                <span className="font-mono">৳{(selectedOrderDetail.items || []).reduce((sum, i) => sum + (Number(i?.product?.price) || 0) * (Number(i?.quantity) || 1), 0).toLocaleString()}</span>
              </div>
              <div className="flex justify-between text-stone-600 font-medium">
                <span>ডেলিভারি চার্জ (Shipping Fee):</span>
                <span className="font-mono">৳{(Number(selectedOrderDetail.shippingFee) || 80).toLocaleString()}</span>
              </div>
              {(Number(selectedOrderDetail.discount) || 0) > 0 && (
                <div className="flex justify-between text-rose-600 font-medium">
                  <span>ডিসকাউন্ট / অফার ছাড়:</span>
                  <span className="font-mono">-৳{Number(selectedOrderDetail.discount).toLocaleString()}</span>
                </div>
              )}
              <div className="flex justify-between text-stone-900 font-bold text-sm pt-2 border-t border-amber-300">
                <span>সর্বমোট প্রদেয় টাকা (Grand Total):</span>
                <span className="font-serif font-extrabold text-rose-950 text-base">৳{(Number(selectedOrderDetail.totalAmount) || 0).toLocaleString()}</span>
              </div>
            </div>

            {/* Status Changer & Direct Actions inside Modal */}
            <div className="pt-2 flex flex-wrap items-center justify-between gap-2 border-t border-stone-200">
              <div className="flex items-center gap-2 flex-wrap">
                <button
                  onClick={() => {
                    onUpdateOrderStatus(selectedOrderDetail.id, 'confirmed');
                    setSelectedOrderDetail({ ...selectedOrderDetail, status: 'confirmed' });
                  }}
                  className={`px-3 py-1.5 rounded-xl font-bold text-xs flex items-center gap-1 cursor-pointer transition-colors ${
                    selectedOrderDetail.status === 'confirmed' ? 'bg-emerald-700 text-white shadow-xs' : 'bg-emerald-100 text-emerald-900 hover:bg-emerald-200'
                  }`}
                >
                  <CheckCircle2 size={13} />
                  <span>কনফার্মড</span>
                </button>

                <button
                  onClick={() => {
                    onUpdateOrderStatus(selectedOrderDetail.id, 'shipped');
                    setSelectedOrderDetail({ ...selectedOrderDetail, status: 'shipped' });
                  }}
                  className={`px-3 py-1.5 rounded-xl font-bold text-xs flex items-center gap-1 cursor-pointer transition-colors ${
                    selectedOrderDetail.status === 'shipped' ? 'bg-purple-700 text-white shadow-xs' : 'bg-purple-100 text-purple-900 hover:bg-purple-200'
                  }`}
                >
                  <Truck size={13} />
                  <span>কুরিয়ারে প্রেরিত</span>
                </button>

                <button
                  onClick={() => {
                    onUpdateOrderStatus(selectedOrderDetail.id, 'delivered');
                    setSelectedOrderDetail({ ...selectedOrderDetail, status: 'delivered' });
                  }}
                  className={`px-3 py-1.5 rounded-xl font-bold text-xs flex items-center gap-1 cursor-pointer transition-colors ${
                    selectedOrderDetail.status === 'delivered' ? 'bg-blue-700 text-white shadow-xs' : 'bg-blue-100 text-blue-900 hover:bg-blue-200'
                  }`}
                >
                  <CheckCircle2 size={13} />
                  <span>ডেলিভারড</span>
                </button>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => {
                    setPrintingOrder(selectedOrderDetail);
                  }}
                  className="px-3.5 py-1.5 bg-stone-200 hover:bg-stone-300 text-stone-800 font-bold rounded-xl text-xs flex items-center gap-1 cursor-pointer"
                >
                  <Printer size={13} />
                  <span>প্রিন্ট ইনভয়েস</span>
                </button>
                <button
                  onClick={() => setSelectedOrderDetail(null)}
                  className="px-4 py-1.5 bg-rose-950 hover:bg-rose-900 text-amber-300 font-bold rounded-xl text-xs cursor-pointer shadow-xs"
                >
                  বন্ধ করুন (Close)
                </button>
              </div>
            </div>

          </div>
        </div>
      )}

      {/* PAYMENT SCREENSHOT INSPECTION LIGHTBOX MODAL */}
      {previewScreenshotUrl && (
        <div className="fixed inset-0 z-[60] bg-black/90 backdrop-blur-md flex flex-col p-2 sm:p-4 animate-fade-in text-white">
          {/* Lightbox Top Control Bar */}
          <div className="flex items-center justify-between gap-3 bg-stone-900/90 border border-stone-800 p-3 rounded-2xl shrink-0 shadow-lg">
            <div className="flex items-center gap-2 min-w-0">
              <span className="p-1.5 bg-amber-400 text-rose-950 rounded-xl font-bold">
                <Search size={16} />
              </span>
              <div>
                <h4 className="font-serif font-bold text-sm text-amber-300 truncate">
                  {lang === 'bn' ? '🔍 পেমেন্ট স্ক্রিনশট বড় করে যাচাই করুন' : 'Inspect Payment Screenshot'}
                </h4>
                <p className="text-[10px] text-stone-400 truncate">
                  {previewScreenshotOrder ? `#${previewScreenshotOrder.id} • ${previewScreenshotOrder.customerName}` : 'জুম ও রোটেট করে আসল না ফেক যাচাই করুন'}
                </p>
              </div>
            </div>

            {/* Zoom, Rotate, Download & Close Controls */}
            <div className="flex items-center gap-1.5 sm:gap-2 flex-wrap justify-end">
              <button
                type="button"
                onClick={() => setScreenshotZoom(prev => Math.max(0.4, Number((prev - 0.25).toFixed(2))))}
                className="p-2 bg-stone-800 hover:bg-stone-700 text-stone-200 rounded-xl transition-colors cursor-pointer"
                title="ছোট করুন (Zoom Out)"
              >
                <ZoomOut size={16} />
              </button>

              <span className="px-2.5 py-1 bg-stone-950 border border-stone-800 rounded-xl text-xs font-mono font-bold text-amber-300 min-w-[50px] text-center">
                {Math.round(screenshotZoom * 100)}%
              </span>

              <button
                type="button"
                onClick={() => setScreenshotZoom(prev => Math.min(4, Number((prev + 0.25).toFixed(2))))}
                className="p-2 bg-stone-800 hover:bg-stone-700 text-stone-200 rounded-xl transition-colors cursor-pointer"
                title="বড় করুন (Zoom In)"
              >
                <ZoomIn size={16} />
              </button>

              <button
                type="button"
                onClick={() => {
                  setScreenshotZoom(1);
                  setScreenshotRotation(0);
                }}
                className="px-2.5 py-1.5 bg-stone-800 hover:bg-stone-700 text-stone-300 rounded-xl text-xs font-bold transition-colors cursor-pointer"
                title="রিসেট (Reset Zoom)"
              >
                100%
              </button>

              <button
                type="button"
                onClick={() => setScreenshotRotation(prev => (prev + 90) % 360)}
                className="p-2 bg-stone-800 hover:bg-stone-700 text-stone-200 rounded-xl transition-colors cursor-pointer"
                title="ঘোরান (Rotate 90°)"
              >
                <RotateCw size={16} />
              </button>

              <a
                href={previewScreenshotUrl}
                download="payment_proof_full.png"
                target="_blank"
                rel="noreferrer"
                className="p-2 bg-amber-400/20 hover:bg-amber-400 text-amber-300 hover:text-rose-950 border border-amber-400/40 rounded-xl transition-all cursor-pointer"
                title="মূল ইমেজ ডাউনলোড করুন"
              >
                <Download size={16} />
              </a>

              <button
                type="button"
                onClick={closeScreenshotPreview}
                className="p-2 bg-red-600 hover:bg-red-700 text-white rounded-xl transition-colors cursor-pointer ml-1"
                title="বন্ধ করুন (Close)"
              >
                <X size={18} />
              </button>
            </div>
          </div>

          {/* Main Inspection Viewport & Order Details Panel */}
          <div className="flex-1 min-h-0 grid grid-cols-1 lg:grid-cols-12 gap-3 mt-3 overflow-hidden">
            {/* Image Stage Container */}
            <div className={`overflow-auto flex items-center justify-center p-4 bg-stone-950/80 rounded-2xl border border-stone-800/80 relative select-none ${
              previewScreenshotOrder ? 'lg:col-span-8' : 'lg:col-span-12'
            }`}>
              <div className="flex items-center justify-center min-w-full min-h-full">
                <img
                  src={previewScreenshotUrl}
                  alt="Payment Proof Verification"
                  style={{
                    transform: `scale(${screenshotZoom}) rotate(${screenshotRotation}deg)`,
                    transformOrigin: 'center center',
                    transition: 'transform 0.15s ease-out',
                    maxHeight: screenshotZoom <= 1 ? '75vh' : 'none',
                    maxWidth: screenshotZoom <= 1 ? '100%' : 'none'
                  }}
                  className="rounded-xl shadow-2xl object-contain cursor-grab active:cursor-grabbing border border-stone-700/50"
                />
              </div>

              {/* Floating Quick Zoom Hint */}
              <div className="absolute bottom-3 left-3 bg-black/60 backdrop-blur-sm text-stone-300 text-[10px] px-2.5 py-1 rounded-lg border border-white/10 pointer-events-none">
                💡 ট্রানজেকশন নম্বর ও সময় বড় করে দেখতে Zoom In (+) বাটনে চাপুন
              </div>
            </div>

            {/* Side Verification & Action Panel (When order info exists) */}
            {previewScreenshotOrder && (
              <div className="lg:col-span-4 bg-stone-900 border border-stone-800 rounded-2xl p-4 flex flex-col justify-between overflow-y-auto space-y-3">
                <div className="space-y-3 text-xs">
                  <div className="border-b border-stone-800 pb-2">
                    <span className="text-[10px] uppercase font-bold text-amber-400 tracking-wider">অর্ডার বিবরণী</span>
                    <h5 className="font-serif font-bold text-base text-white mt-0.5">
                      #{previewScreenshotOrder.id}
                    </h5>
                    <p className="text-stone-300 font-bold mt-0.5">
                      👤 {previewScreenshotOrder.customerName}
                    </p>
                    <p className="font-mono text-rose-300 font-bold">
                      📞 {previewScreenshotOrder.phone}
                    </p>
                  </div>

                  {/* Payment Info Card */}
                  <div className="bg-stone-950/80 p-3 rounded-xl border border-stone-800 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-stone-400 text-[11px]">পেমেন্ট মেথড:</span>
                      <span className="px-2 py-0.5 rounded font-mono font-black text-xs uppercase bg-rose-950 text-amber-300 border border-amber-400/40">
                        {previewScreenshotOrder.paymentMethod || 'bKash'}
                      </span>
                    </div>

                    <div className="flex items-center justify-between">
                      <span className="text-stone-400 text-[11px]">সেন্ডার মোবাইল:</span>
                      <span className="font-mono font-bold text-white">
                        {previewScreenshotOrder.paymentSenderPhone || previewScreenshotOrder.paymentPhone || previewScreenshotOrder.phone}
                      </span>
                    </div>

                    {previewScreenshotOrder.trxId && (
                      <div className="p-2 bg-pink-950/40 rounded-lg border border-pink-500/30 space-y-1">
                        <span className="text-[10px] text-pink-300 font-bold block uppercase">ট্রানজেকশন আইডি (TrxID)</span>
                        <div className="flex items-center justify-between gap-1">
                          <span className="font-mono font-black text-amber-300 text-sm select-all">
                            {previewScreenshotOrder.trxId}
                          </span>
                          <button
                            type="button"
                            onClick={() => {
                              navigator.clipboard.writeText(previewScreenshotOrder.trxId || '');
                              alert('✅ TrxID কপি করা হয়েছে: ' + previewScreenshotOrder.trxId);
                            }}
                            className="px-2 py-1 bg-white/10 hover:bg-white/20 text-stone-200 rounded text-[10px] font-bold cursor-pointer"
                          >
                            কপি
                          </button>
                        </div>
                      </div>
                    )}

                    <div className="flex items-center justify-between pt-1 border-t border-stone-800">
                      <span className="text-stone-400 text-[11px]">অর্ডার মোট মূল্য:</span>
                      <span className="font-serif font-extrabold text-amber-300 text-sm">
                        ৳{Number(previewScreenshotOrder.totalAmount).toLocaleString()}
                      </span>
                    </div>
                  </div>

                  {/* Anti-Fraud Inspection Checklist */}
                  <div className="bg-amber-950/20 border border-amber-500/30 p-3 rounded-xl space-y-1.5 text-[11px] text-amber-200/90">
                    <span className="font-bold text-amber-300 flex items-center gap-1">
                      <ShieldCheck size={14} />
                      <span>আসল না ফেক স্ক্রিনশট যাচাইকরণ গাইড:</span>
                    </span>
                    <ul className="list-disc list-inside space-y-1 text-[10px] text-stone-300">
                      <li>বিকাশ/নগদ স্টেটমেন্টে TrxID হুবহু মিলিয়ে নিন।</li>
                      <li>স্ক্রিনশটে টেক্সট বা ফন্টে কোনো কাটাকাটি বা ব্লার আছে কি না জুম করে দেখুন।</li>
                      <li>টাকা পাঠানোর সময় ও তারিখের সাথে অর্ডারের সময় মিলিয়ে নিন।</li>
                    </ul>
                  </div>
                </div>

                {/* Quick Action Verification Buttons */}
                <div className="pt-2 border-t border-stone-800 space-y-2">
                  <button
                    type="button"
                    onClick={() => {
                      const updated = {
                        ...previewScreenshotOrder,
                        paymentStatus: 'VERIFIED_PAID' as const,
                        amountPaid: Number(previewScreenshotOrder.totalAmount) || 0,
                        amountDue: 0
                      };
                      if (onUpdateFullOrder) onUpdateFullOrder(updated);
                      if (selectedOrderDetail && selectedOrderDetail.id === previewScreenshotOrder.id) {
                        setSelectedOrderDetail(updated);
                      }
                      alert(`✅ অর্ডার #${previewScreenshotOrder.id}-এর পেমেন্ট সফলভাবে 'VERIFIED PAID' কনফার্ম করা হয়েছে!`);
                      closeScreenshotPreview();
                    }}
                    className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold rounded-xl shadow-lg flex items-center justify-center gap-2 cursor-pointer transition-colors"
                  >
                    <CheckCircle2 size={16} />
                    <span>✅ পেমেন্ট আসল ও সঠিক (Mark Verified Paid)</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      const updated = {
                        ...previewScreenshotOrder,
                        paymentStatus: 'FAILED' as const,
                        notes: (previewScreenshotOrder.notes || '') + ' [পেমেন্ট স্ক্রিনশট ফেক বা বাতিল চিহ্নিত]'
                      };
                      if (onUpdateFullOrder) onUpdateFullOrder(updated);
                      if (selectedOrderDetail && selectedOrderDetail.id === previewScreenshotOrder.id) {
                        setSelectedOrderDetail(updated);
                      }
                      alert(`⚠️ অর্ডার #${previewScreenshotOrder.id}-এর পেমেন্ট ফেক/অসম্পূর্ণ চিহ্নিত করা হয়েছে।`);
                      closeScreenshotPreview();
                    }}
                    className="w-full py-2 bg-red-900/60 hover:bg-red-800 text-red-200 border border-red-700/50 font-bold rounded-xl flex items-center justify-center gap-1.5 cursor-pointer transition-colors text-xs"
                  >
                    <AlertTriangle size={14} />
                    <span>❌ ফেক বা ত্রুটিপূর্ণ স্ক্রিনশট (Reject Proof)</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Clear All Orders / Reset History Confirmation Modal */}
      {isClearHistoryModalOpen && (
        <div className="fixed inset-0 z-70 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-white rounded-3xl p-6 max-w-md w-full shadow-2xl border-2 border-rose-300 space-y-4">
            <div className="flex items-center justify-between border-b border-rose-100 pb-3">
              <div className="flex items-center gap-2 text-rose-800">
                <div className="p-2 bg-rose-100 rounded-xl">
                  <Trash2 size={20} className="text-rose-700" />
                </div>
                <div>
                  <h3 className="font-serif font-bold text-base text-rose-950">
                    {lang === 'bn' ? 'অর্ডার হিস্ট্রি ক্লিয়ার ও রিসেট' : 'Clear Order History'}
                  </h3>
                  <span className="text-[10px] text-stone-500 font-mono">
                    বর্তমান সংরক্ষিত অর্ডার: {orders.length}টি
                  </span>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsClearHistoryModalOpen(false)}
                className="p-1 text-stone-400 hover:text-stone-600 rounded-lg cursor-pointer"
              >
                <X size={18} />
              </button>
            </div>

            <div className="p-3.5 bg-rose-50 rounded-2xl border border-rose-200 text-xs text-rose-950 space-y-2">
              <p className="font-bold flex items-center gap-1.5 text-rose-800">
                <AlertTriangle size={15} />
                <span>আপনি কি নিশ্চিত যে সমস্ত অর্ডার মুছে ফেলতে চান?</span>
              </p>
              <p className="text-stone-700 leading-relaxed text-[11px]">
                এটি কনফার্ম করলে ড্যাশবোর্ডের পূর্বের সকল পরীক্ষামূলক সেলস এবং অর্ডারের তালিকা মুছে সম্পূর্ণ খালি (০) হয়ে যাবে।
              </p>
              <p className="text-emerald-800 font-semibold text-[11px] bg-emerald-50 p-2 rounded-xl border border-emerald-200">
                ✅ এরপর ওয়েবসাইট থেকে নতুন কোনো কাস্টমার অর্ডার করলে সেটি আবার ১, ২, ৩ করে ক্রমান্বয়ে স্বয়ংক্রিয়ভাবে নতুন তালিকায় যুক্ত হতে থাকবে।
              </p>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setIsClearHistoryModalOpen(false)}
                disabled={isClearingHistory}
                className="px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded-xl text-xs font-bold cursor-pointer"
              >
                {lang === 'bn' ? 'ফিরে যান' : 'Cancel'}
              </button>

              <button
                type="button"
                onClick={handleConfirmClearOrders}
                disabled={isClearingHistory}
                className="px-5 py-2 bg-rose-700 hover:bg-rose-800 text-white rounded-xl text-xs font-extrabold flex items-center gap-1.5 shadow-md cursor-pointer transition-all disabled:opacity-50"
              >
                <Trash2 size={14} />
                <span>{isClearingHistory ? 'মুছে ফেলা হচ্ছে...' : (lang === 'bn' ? 'হ্যাঁ, সব ক্লিয়ার করুন' : 'Confirm Clear')}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Ads Manager Modal for Product Boosting */}
      <AdsManagerModal
        isOpen={isAdsManagerOpen}
        onClose={() => setIsAdsManagerOpen(false)}
        lang={lang}
        product={boostModalProduct}
        allProducts={products}
        onLaunchCampaign={(updatedProd) => {
          onUpdateProduct(updatedProd);
          setBoostedProducts(prev => Array.from(new Set([...prev, updatedProd.id])));
        }}
      />

    </div>
  );
};
